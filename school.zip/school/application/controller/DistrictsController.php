<?php
require_once "application/controller/Controller.php"; 

class DistrictsController extends Controller
{
	
	
	/*
		add new district
	*/
	public function postdistrict()
	{
		$table = "district";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$redirect = "districts.php";
		
		$columns = "districtName, districtDescription";
		$values = "'$name', '$desc'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update district
	*/
	public function updatedistrict($id)
	{
		$table = "district";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$redirect = "districts.php";
		
		$column_value = "districtName = '$name', districtDescription = '$desc'";
		
		$data = $this->model->update($table, $column_value, "districtId", $id, $redirect);
		
		return $data;
	}
}
?>