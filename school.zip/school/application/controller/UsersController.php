<?php
require_once "application/controller/Controller.php"; 

class UsersController extends Controller
{
	
	/*
		add new user
	*/
	public function postuser()
	{
		$table = "users";
		$fname = mysqli_real_escape_string($this->model->mysqli, $_POST['fname']);
		$lname = mysqli_real_escape_string($this->model->mysqli, $_POST['lname']);
		$gender = mysqli_real_escape_string($this->model->mysqli, $_POST['gender']);
		$phone = mysqli_real_escape_string($this->model->mysqli, $_POST['phone']);
		$email = mysqli_real_escape_string($this->model->mysqli, $_POST['email']);
		$dob = mysqli_real_escape_string($this->model->mysqli, $_POST['dob']);
		$address = mysqli_real_escape_string($this->model->mysqli, $_POST['address']);
		$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);
		$path = "";
		$username = mysqli_real_escape_string($this->model->mysqli, $_POST['username']);
		$password = mysqli_real_escape_string($this->model->mysqli, $_POST['password']);
		$password = md5($password);
		
		if(!empty($_FILES['pic']['name']) ){
			$pic = $_FILES['pic'];
			$pic_name = $pic['name'];
			$pic_name = mysqli_real_escape_string($this->model->mysqli,$pic_name);
			$pic_name = str_replace(' ','-',$pic_name);
			$pic_tmp = $pic['tmp_name'];
			$path = "uploads/".$pic_name;
			move_uploaded_file($pic_tmp,$path);
		}else{
			$path = '';
		}
							
							
		$date = date("Y-m-d");
		$redirect = "users.php";
		
		$columns = "fname, lname, gender, email, address, phoneNo, role, birthday, username, password, photo";
		
		$values = "'$fname', '$lname', '$gender', '$email', '$address', '$phone', '$level', '$dob', '$username', '$password', '$path' ";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update users
	*/
	public function updateusers($id, $redirect)
	{
		$table = "users";
		$fname = mysqli_real_escape_string($this->model->mysqli, $_POST['fname']);
		$lname = mysqli_real_escape_string($this->model->mysqli, $_POST['lname']);
		$gender = mysqli_real_escape_string($this->model->mysqli, $_POST['gender']);
		$phone = mysqli_real_escape_string($this->model->mysqli, $_POST['phone']);
		$email = mysqli_real_escape_string($this->model->mysqli, $_POST['email']);
		$dob = mysqli_real_escape_string($this->model->mysqli, $_POST['dob']);
		$address = mysqli_real_escape_string($this->model->mysqli, $_POST['address']);
		
		$username = mysqli_real_escape_string($this->model->mysqli, $_POST['username']);
		
		if(!empty($_FILES['pic']['name']) ){
			$pic = $_FILES['pic'];
			$pic_name = $pic['name'];
			$pic_name = mysqli_real_escape_string($this->model->mysqli,$pic_name);
			$pic_name = str_replace(' ','-',$pic_name);
			$pic_tmp = $pic['tmp_name'];
			$path = "uploads/".$pic_name;
			move_uploaded_file($pic_tmp,$path);
			
			$clm_val = "photo = '$path'";
			
			$this->model->updateimg($table, $clm_val, "userid", $id);
			
		}
							
		//$redirect = "users.php";
		if(isset($_POST['level']))
		{
			$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);
			$column_value = "fname = '$fname', lname = '$lname', gender = '$gender', email = '$email', address = '$address', phoneNo = '$phone', role = '$level', birthday = '$dob', username = '$username'";
		}
		else
		{
			$column_value = "fname = '$fname', lname = '$lname', gender = '$gender', email = '$email', address = '$address', phoneNo = '$phone', birthday = '$dob', username = '$username'";
		}
		
		$data = $this->model->update($table, $column_value, "userid", $id, $redirect);
		
		return $data;
	}
	
	/*
		update users
	*/
	public function updatepassword($id, $redirect)
	{
		$table = "users";
		$curpass = mysqli_real_escape_string($this->model->mysqli, $_POST['curpass']);
		$pass = mysqli_real_escape_string($this->model->mysqli, $_POST['pass']);
		$cpass = mysqli_real_escape_string($this->model->mysqli, $_POST['cpass']);
		
		$checkpas = $this->getcustomdata("select * from users where password = '". md5($curpass) ."'");
		
		if(count($checkpas) < 1)
		{
			$this->model->Alert("alert-danger", "Sorry the system failed to recognize your current password, please try again");
			
			$this->model->Redirect("2", $redirect);
			
			exit();
		}
		
		if($pass != $cpass)
		{
			$this->model->Alert("alert-danger", "Sorry your new passwords did not match");
			
			exit();
			
			$this->model->Redirect("2", $redirect);
		}
		
		$column_value = "password = '". md5($pass) ."'";
		
		$data = $this->model->update($table, $column_value, "userid", $id, "logout.php");
		
		return $data;
	}
}
?>