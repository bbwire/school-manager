<?php
require_once "application/controller/Controller.php"; 

class GradeController extends Controller
{
	
	
	/*
		add new grade
	*/
	public function postgrade()
	{
		$table = "grades";
		$grade = mysqli_real_escape_string($this->model->mysqli, $_POST['grade']);
		$min = mysqli_real_escape_string($this->model->mysqli, $_POST['min']);
		$max = mysqli_real_escape_string($this->model->mysqli, $_POST['max']);
		$comm = mysqli_real_escape_string($this->model->mysqli, $_POST['comm']);
		$redirect = "grades.php";
		
		$columns = "grade, markFrom, markTo, comment";
		$values = "'$grade', '$min', '$max', '$comm'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update grade
	*/
	public function updategrade($id)
	{
		$table = "grades";
		$grade = mysqli_real_escape_string($this->model->mysqli, $_POST['grade']);
		$min = mysqli_real_escape_string($this->model->mysqli, $_POST['min']);
		$max = mysqli_real_escape_string($this->model->mysqli, $_POST['max']);
		$comm = mysqli_real_escape_string($this->model->mysqli, $_POST['comm']);
		$redirect = "grades.php";
		
		$column_value = "grade = '$grade', markFrom = '$min', markTo = '$max', comment = '$comm'";
		
		$data = $this->model->update($table, $column_value, "gradeId", $id, $redirect);
		
		return $data;
	}
	
	/*
		add new grade
	*/
	public function postagrade()
	{
		$table = "alevelgrades";
		$bestpaper = mysqli_real_escape_string($this->model->mysqli, $_POST['bestpaper']);
		$secondbestpaper = mysqli_real_escape_string($this->model->mysqli, $_POST['secondbestpaper']);
		$thirdbestpaper = mysqli_real_escape_string($this->model->mysqli, $_POST['thirdbestpaper']);
		$papertype = mysqli_real_escape_string($this->model->mysqli, $_POST['papertype']);
		$grade = mysqli_real_escape_string($this->model->mysqli, $_POST['grade']);
		$points = mysqli_real_escape_string($this->model->mysqli, $_POST['points']);
		$comm = mysqli_real_escape_string($this->model->mysqli, $_POST['comm']);
		$redirect = "alevel-grades.php";
		
		$columns = "bestPaper, secondBestPaper, thirdBestPaper, paperType, grade, points, comment";
		$values = "'$bestpaper', '$secondbestpaper', '$thirdbestpaper', '$papertype', '$grade', '$points', '$comm'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update grade
	*/
	public function updateagrade($id)
	{
		$table = "alevelgrades";
		$bestpaper = mysqli_real_escape_string($this->model->mysqli, $_POST['bestpaper']);
		$secondbestpaper = mysqli_real_escape_string($this->model->mysqli, $_POST['secondbestpaper']);
		$thirdbestpaper = mysqli_real_escape_string($this->model->mysqli, $_POST['thirdbestpaper']);
		$papertype = mysqli_real_escape_string($this->model->mysqli, $_POST['papertype']);
		$grade = mysqli_real_escape_string($this->model->mysqli, $_POST['grade']);
		$points = mysqli_real_escape_string($this->model->mysqli, $_POST['points']);
		$comm = mysqli_real_escape_string($this->model->mysqli, $_POST['comm']);
		$redirect = "alevel-grades.php";
		
		$column_value = "bestPaper = '$bestpaper', secondBestPaper = '$secondbestpaper', thirdBestPaper = '$thirdbestpaper', paperType = '$papertype', grade = '$grade', points = '$points', comment = '$comm'";
		
		$data = $this->model->update($table, $column_value, "gradeId", $id, $redirect);
		
		return $data;
	}
}
?>