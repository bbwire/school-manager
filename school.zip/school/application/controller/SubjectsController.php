<?php
require_once "application/controller/Controller.php"; 

class SubjectsController extends Controller
{
	
	/*
		add new subject
	*/
	public function postsubject()
	{
		$table = "subject";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$code = mysqli_real_escape_string($this->model->mysqli, $_POST['code']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);

		$redirect = "subjects.php";
		
		$columns = "subjectTitle, subjectDescription, subjectType, subjectLevel, subjectCode";
		$values = "'$name', '$desc', '$type', '$level', '$code'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update subject
	*/
	public function updatesubject($id)
	{
		$table = "subject";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$code = mysqli_real_escape_string($this->model->mysqli, $_POST['code']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);

		$redirect = "subjects.php";
		
		$column_value = "subjectTitle = '$name', subjectDescription = '$desc', subjectType = '$type', subjectLevel = '$level', subjectCode = '$code'";
		
		$data = $this->model->update($table, $column_value, "id", $id, $redirect);
		
		return $data;
	}
	/*
		add new subject
	*/
	public function postpaper()
	{
		$table = "subjectpaper";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);

		$redirect = "subject-papers.php";
		
		$columns = "paperTitle, paperParent";
		$values = "'$name', '$subject'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	/*
		update subject paper
	*/
	public function updatepaper($id)
	{
		$table = "subjectpaper";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
		$redirect = "subject-papers.php";
		
		$column_value = "paperTitle = '$name', paperParent = '$subject'";
		
		$data = $this->model->update($table, $column_value, "paperId", $id, $redirect);
		
		return $data;
	}
	
	/*
		Upload from excel sheet
	*/
	public function uploadfromexcel($table, $redirect)
	{
		
		if(isset($_FILES['file']['name'])){
			
			$filename = $_FILES["file"]["tmp_name"];
	 
	 
			 if($_FILES["file"]["size"] > 0)
			 {
	 
				$file = fopen($filename, "r");
				
				 while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
				 {
	 
					  $title = $emapData[0];
					  $desc = $emapData[1];
					  $columns = "subjectTitle, subjectDescription";
					  $values = "'$title', '$desc'";
								  
	 				  $data = $this->model->save($table, $columns, $values, $redirect);		
		
				 }
				 
				 fclose($file);
				 
			 }
		}
		
		return $data;
	}
	/*
		add new subject teacher
	*/
	public function postsubjectteacher()
	{
		$table = "subjectteacher";
		$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
		$teacher = mysqli_real_escape_string($this->model->mysqli, $_POST['teacher']);

		$redirect = "subject-teachers.php";
		
		$columns = "level, classId, subjectId, teacher";
		$values = "'$level', '$class', '$subject', '$teacher'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	/*
		update subject teacher
	*/
	public function updatesubjectteacher($id)
	{
		$table = "subjectteacher";
		$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
		$teacher = mysqli_real_escape_string($this->model->mysqli, $_POST['teacher']);

		$redirect = "subject-teachers.php";
		
		$column_value = "level = '$level', classId = '$class', subjectId = '$subject', teacher = '$teacher'";
		
		$data = $this->model->update($table, $column_value, "teacherId", $id, $redirect);
		
		return $data;
	}
}
?>