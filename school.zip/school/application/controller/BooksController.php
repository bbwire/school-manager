<?php
require_once "application/controller/Controller.php"; 

class BooksController extends Controller
{
	
	
	/*
		add new book
	*/
	public function postbook()
	{
		$table = "booklibrary";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$author = mysqli_real_escape_string($this->model->mysqli, $_POST['author']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$price = mysqli_real_escape_string($this->model->mysqli, $_POST['price']);
		$state = "Available";
		$redirect = "library.php";
		
		$columns = "bookName, bookDescription, bookAuthor, bookType, bookPrice, bookState";
		$values = "'$name', '$desc', '$author', '$type', '$price', '$state'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update book info
	*/
	public function updatebook($id)
	{
		$table = "booklibrary";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$author = mysqli_real_escape_string($this->model->mysqli, $_POST['author']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$price = mysqli_real_escape_string($this->model->mysqli, $_POST['price']);
		$state = mysqli_real_escape_string($this->model->mysqli, $_POST['state']);
		$redirect = "library.php";
		
		$column_value = "bookName = '$name', bookDescription = '$desc', bookAuthor = '$author', bookType = '$type', bookPrice = '$price', bookState = '$state'";
		
		$data = $this->model->update($table, $column_value, "id", $id, $redirect);
		
		return $data;
	}
}
?>