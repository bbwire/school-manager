<?php
require_once "application/controller/Controller.php"; 

class CountyController extends Controller
{
	
	
	/*
		add new county
	*/
	public function postcounty()
	{
		$table = "county";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$district = mysqli_real_escape_string($this->model->mysqli, $_POST['district']);
		$redirect = "counties.php";
		
		$columns = "countyName, countyDescription, districtId";
		$values = "'$name', '$desc', '$district'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update county
	*/
	public function updatecounty($id)
	{
		$table = "county";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$desc = mysqli_real_escape_string($this->model->mysqli, $_POST['desc']);
		$district = mysqli_real_escape_string($this->model->mysqli, $_POST['district']);
		$redirect = "counties.php";
		
		$column_value = "countyName = '$name', countyDescription = '$desc', districtId = '$district'";
		
		$data = $this->model->update($table, $column_value, "countyId", $id, $redirect);
		
		return $data;
	}
}
?>