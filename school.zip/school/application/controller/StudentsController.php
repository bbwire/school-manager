<?php
require_once "application/controller/Controller.php"; 

class StudentsController extends Controller
{
	/*
		add new student
	*/
	public function poststudent()
	{
		$table = "students";
		$level = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);
		$fname = mysqli_real_escape_string($this->model->mysqli, $_POST['fname']);
		$lname = mysqli_real_escape_string($this->model->mysqli, $_POST['lname']);
		$gender = mysqli_real_escape_string($this->model->mysqli, $_POST['gender']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$stream = mysqli_real_escape_string($this->model->mysqli, $_POST['stream']);
		$stdno = mysqli_real_escape_string($this->model->mysqli, $_POST['stdno']);
		$aggregate = mysqli_real_escape_string($this->model->mysqli, $_POST['aggregate']);
		$dob = mysqli_real_escape_string($this->model->mysqli, $_POST['dob']);
		$religion = mysqli_real_escape_string($this->model->mysqli, $_POST['religion']);
		$combination = '';
		$ps1 = '';
		$ps2 = '';
		$ps3 = '';
		$sub = '';
		if(isset($_POST['combination']))
		{
			$combination = mysqli_real_escape_string($this->model->mysqli, $_POST['combination']);
			$ps1 = mysqli_real_escape_string($this->model->mysqli, $_POST['ps1']);
			$ps2 = mysqli_real_escape_string($this->model->mysqli, $_POST['ps2']);
			$ps3 = mysqli_real_escape_string($this->model->mysqli, $_POST['ps3']);
			$sub = mysqli_real_escape_string($this->model->mysqli, $_POST['sub']);
		}
		$path = '';
		$parent = mysqli_real_escape_string($this->model->mysqli, $_POST['parent']);
		$contact = mysqli_real_escape_string($this->model->mysqli, $_POST['contact']);
		$district = mysqli_real_escape_string($this->model->mysqli, $_POST['district']);
		$county = mysqli_real_escape_string($this->model->mysqli, $_POST['county']);
		$receipt = mysqli_real_escape_string($this->model->mysqli, $_POST['receipt']);
		$date = date("Y-m-d");
		$redirect = "students.php";
		
		if(!empty($_FILES['pic']['name']) ){
			$pic = $_FILES['pic'];
			$pic_name = $pic['name'];
			$pic_name = mysqli_real_escape_string($this->model->mysqli,$pic_name);
			$pic_name = str_replace(' ','-',$pic_name);
			$pic_tmp = $pic['tmp_name'];
			$path = "uploads/".$pic_name;
			move_uploaded_file($pic_tmp,$path);
		}else{
			$path = $path;
		}
		
		$columns = "studyLevel, fname, lname, gender, class, stream, studentNumber, aggregate, dateOfBirth, religion, parent, contact, county, receiptNumber, principOne, principTwo, principThree, subsid, combination, date, photo";
		
		$values = "'$level', '$fname', '$lname', '$gender', '$class', '$stream', '$stdno', '$aggregate', '$dob', '$religion', '$parent', '$contact', '$county', '$receipt', '$ps1', '$ps2', '$ps3', '$sub', '$combination', '$date', '$path'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		add new student
	*/
	public function updatestudent($id)
	{
		$table = "students";
		$fname = mysqli_real_escape_string($this->model->mysqli, $_POST['fname']);
		$lname = mysqli_real_escape_string($this->model->mysqli, $_POST['lname']);
		$gender = mysqli_real_escape_string($this->model->mysqli, $_POST['gender']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$stream = mysqli_real_escape_string($this->model->mysqli, $_POST['stream']);
		$aggregate = mysqli_real_escape_string($this->model->mysqli, $_POST['aggregate']);
		$dob = mysqli_real_escape_string($this->model->mysqli, $_POST['dob']);
		$religion = mysqli_real_escape_string($this->model->mysqli, $_POST['religion']);
		$combination = '';
		$ps1 = '';
		$ps2 = '';
		$ps3 = '';
		$sub = '';
		if(isset($_POST['combination']))
		{
			$combination = mysqli_real_escape_string($this->model->mysqli, $_POST['combination']);
			$ps1 = mysqli_real_escape_string($this->model->mysqli, $_POST['ps1']);
			$ps2 = mysqli_real_escape_string($this->model->mysqli, $_POST['ps2']);
			$ps3 = mysqli_real_escape_string($this->model->mysqli, $_POST['ps3']);
			$sub = mysqli_real_escape_string($this->model->mysqli, $_POST['sub']);
		}
		$parent = mysqli_real_escape_string($this->model->mysqli, $_POST['parent']);
		$contact = mysqli_real_escape_string($this->model->mysqli, $_POST['contact']);
		$district = mysqli_real_escape_string($this->model->mysqli, $_POST['district']);
		$county = mysqli_real_escape_string($this->model->mysqli, $_POST['county']);
		$receipt = mysqli_real_escape_string($this->model->mysqli, $_POST['receipt']);
		$date = date("Y-m-d");
		$redirect = "students.php";
		
		if(!empty($_FILES['pic']['name']) ){
			$pic = $_FILES['pic'];
			$pic_name = $pic['name'];
			$pic_name = mysqli_real_escape_string($this->model->mysqli, $pic_name);
			$pic_name = str_replace(' ','-',$pic_name);
			$pic_tmp = $pic['tmp_name'];
			$path = "uploads/".$pic_name;
			move_uploaded_file($pic_tmp, $path);
			
			$clm_val = "photo = '$path'";
			
			$this->model->UpdateImg($table, $clm_val, "studentId", $id);
			
		}
		
		$column_value = "fname = '$fname', lname = '$lname', gender = '$gender', class = '$class', stream = '$stream', aggregate = '$aggregate', dateOfBirth = '$dob', religion = '$religion', parent = '$parent', contact = '$contact', district = '$district', county = '$county', receiptNumber = '$receipt', principOne = '$ps1', principTwo = '$ps2', principThree = '$ps3', subsid = '$sub', combination = '$combination'";
		
		
		$data = $this->model->update($table, $column_value, "studentId", $id, $redirect);
		
		return $data;
	}
	
	
	
	/*
		Upload from excel sheet
	*/
	public function uploadfromexcel($table, $redirect)
	{
		
		if(isset($_FILES['file']['name']))
		{
			$levelx = mysqli_real_escape_string($this->model->mysqli, $_POST['level']);
			$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
			$date = date("Y-m-d");
			$filename = $_FILES["file"]["tmp_name"];
	 
	 
			 if($_FILES["file"]["size"] > 0)
			 {
	 
				$file = fopen($filename, "r");
				
				$row = 0;
				
				 while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
				 {
					 $row++;
					 
					 if($row == 1){}
	 				  else
					  {
						  $fname = $emapData[0];
						  $lname = $emapData[1];
						  $gender = $emapData[2];
						  $stream = $emapData[3];
						  $stdno = $emapData[4];
						  $aggregate = $emapData[5];
						  $dob = $emapData[6];
						  $religion = $emapData[7];
						  $parent = $emapData[8];
						  $contact = $emapData[9];
						  $receipt = $emapData[10];
						  $columns = "studyLevel, fname, lname, gender, class, stream, studentNumber, aggregate, dateOfBirth, religion, parent, contact, receiptNumber, date";
			
			$values = "'$levelx', '$fname', '$lname', '$gender', '$class', '$stream', '$stdno', '$aggregate', '$dob', '$religion', '$parent', '$contact','$receipt', '$date'";
									  
						  $data = $this->model->saveexcel($table, $columns, $values, $redirect);	
					  }
		
				 }
				 
				 fclose($file);
				 
				 $this->model->Alert("alert-success", "Data has been uploaded successfully!");
				 
			 }
		}
		
		return $data;
	}
	
	/*****
		Gets the subject score
	*****/
	public function getTheScore($table, $student, $subject, $type, $year, $term, $markstype)
	
	{
		$score = $this->model->getscore($table, $student, $subject, $type, $year, $term, $markstype);
		
		if($score != '')
		{
			if($type == 'BOT Test' or $type == 'EOT Test')
				$score = $score;
			else
				$score = $score*0.7;
		}
		
		return $score;
	}
	
	/*****
		Gets subject grade taking subject average mark as the parameter
	*****/
	public function getGrade($mark)
	{
		$grade = $this->model->getgrade($mark);
		
		return $grade;
	}
	
	/*****
		Gets subject grade taking subject average mark as the parameter
	*****/
	public function getAlevelGrade($mark, $type)
	{
		$grade = $this->model->getagrade($mark, $type);
		
		return $grade;
	}
	
	/*****
		Gets grade comment taking subject average mark as the parameter
	*****/
	public function getComment($table, $mark)
	{
		$comment = $this->model->getcomment($table, $mark);
		
		return $comment;
	}
	
	
	
	/*****
		Gets grade comment taking subject average mark as the parameter
	*****/
	public function getaComment($mark, $type)
	{
		$comment = $this->model->getacomment($mark, $type);
		
		return $comment;
	}
	
	/*****
		Get points
	*****/
	public function getPoints($grade){
		$points = 0;
		if($grade != '-')
		{
			if($grade == 'A')
				$points = 6;
			else if($grade == 'B')
				$points = 5;
			else if($grade == 'C')
				$points = 4;
			else if($grade == 'D')
				$points = 3;
			else if($grade == 'E')
				$points = 2;
			else if($grade == 'O')
				$points = 1;
			else if($grade == 'F')
				$points = 0;
		}
		
		return $points;
		
	}
	
	public function compare_core($x, $y)
	{
		if($x['average'] == $y['average'])
			return 0;
		else if($x['average'] < $y['average'])
			return 1;
		else
			return -1;
	}
	
	public function compare_averages($x, $y)
	{
		if($x['avrgmrk'] == $y['avrgmrk'])
			return 0;
		else if($x['avrgmrk'] < $y['avrgmrk'])
			return 1;
		else
			return -1;
	}
	
	public static function compare($x, $y)
	{
		if($x['average'] == $y['average'])
			return 0;
		else if($x['average'] < $y['average'])
			return 1;
		else
			return -1;
	}
	
	/*****
		Gets performance supplied a multi-dimensional array with grades, average marks, subject id
	*****/
	public function getPerformance($stored, $stored_core)
	{
		$data['storeddata'] = array();
		$result = 0;
		$x = null;
		$y = null;
		
		
			
		//$this->compare_core($x, $y);
		
		$cores_totl = 0;
		$cores_agg = 0;
		$core_max = 2;
		
		$i = 1;	
		
		$data['coresubjects'] = array();
		$coresubject = array();
		
		foreach($stored_core as $cores):
			$subid = $cores['subject'];			
			$cores_totl = $cores_totl+$cores['average'];
			$grade = $cores['grade'];
			$grade = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
			
			$cores_agg = ($cores_agg)+($grade[1]);
				
			$subdat = $this->getindividual("subject", "id", $subid);
			
			foreach($subdat as $sbdat):
				$coresubject['sid'] = $sbdat->id;
				$coresubject['sname'] = $sbdat->subjectTitle;
				$coresubject['grade'] = $grade[1];
				
				array_push($data['coresubjects'], $coresubject);
			endforeach;
				
				
			//echo $cores['average']. ' '. $cores['grade'] .'<br>';
			
			//if($i++ == $core_max) break;
		endforeach;
		
		$totl = 0;
		$aggregate = 0;
		
		$max = 6;
		
		
		//$this->compare($x, $y);
		
		usort($stored, array($this, "compare"));
		
		
		foreach($stored as $perform):
		
			$subject = $perform['subject'];
			
			$totl = $totl+$perform['average'];
			$grade = $perform['grade'];
			$grade = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
			
			$aggregate = ($aggregate)+($grade[1]);
			
			//echo $perform['average']. ' '. $subject . ' ' . $perform['grade'] .'<br>';
			
			
			if($i++ == $max) break;
			
		endforeach;
		
		
		$aggr = $aggregate+$cores_agg;
		
		$coresubs = $data['coresubjects'];
		
		foreach($coresubs as $scores):
			if(strcasecmp($scores['sname'], "English Language") == 0 or strcasecmp($scores['sname'], "English") == 0)
			{
				if($scores['grade'] <= 6 and $aggr <= 32)
				{
					$result = 1;
				}
				
				if($scores['grade'] == '')
				{
					$result = 7;
					$aggr = 'Ungraded';
				}
				
				if($scores['grade'] > 6 and $scores['grade'] < 9 and $aggr <= 32)
				{
					$result = 2;
				}
				
				if($scores['grade'] <= 8 and $aggr > 32 and $aggr <= 45)
				{
					$result = 2;
				}
				
				if(($scores['grade'] == 9 and $aggr <= 32) or ($aggr > 45 and $aggr <= 58) and count($stored) > 5 and count($stored_core) > 1)
				{
					$result = 3;
				}
				
				if( $aggr > 58 and $aggr <= 68)
				{
					$result = 4;
				}
				
				if($aggr >= 69)
				{
					$result = 9;
				}
			}
			
			if(strcasecmp($scores['sname'], "Mathematics") == 0)
			{
				if($scores['grade'] == '')
				{
					$result = 7;
					$aggr = 'Ungraded';
				}
			}
		endforeach;
		
		if(count($stored) < 6 or count($stored_core) < 2) { $result = 7; $aggr = 'Ungraded';}
		
		$average_mark = ($cores_totl+$totl)/8;
		
		$onedata = array();
		
		$onedata['totalmark'] = $cores_totl+$totl;
		$onedata['averagemark'] = $average_mark;
		$onedata['aggregate'] = $aggr;
		$onedata['result'] = $result;
		$onedata['cores'] = count($stored_core);
		
		array_push($data['storeddata'], $onedata);
		
		return $data['storeddata'];
		
		//echo count($stored_core);
	}
	
	public function getPosition($data, $stid)
	{
		try
		{
			$x = 0;
			$y = 0;
			$count = 0;
			//$this->compare_averages($x, $y);
			
			usort($data, array($this, "compare_averages"));
			foreach($data as $dt):
				$count++;
				$dataid = $dt['student'];
				
				if($stid == $dataid){
					$position = $count;
				}
			endforeach;
		}
		catch(Exception $e)
		{
			$this->model->Alert("alert-danger", $e->getMessage());
		}
		
		return $position;
	}
	
	public function getPositionGeneral($data)
	{
		try
		{
			$x = 0;
			$y = 14;
			$count = 0;
			//$this->compare_averages($x, $y);
			
			usort($data, array($this, "compare_averages"));
			foreach($data as $dt):
				
				if($dt['result'] == 1){
					$count++;
					echo 'Student: '.$dt['student'].'<br>';
					echo 'Average Mark: '.$dt['avrgmrk'].'<br>';
					echo 'Result: '.$dt['result'].'<br><br>';
				}
				
			endforeach;
		}
		catch(Exception $e)
		{
			$this->model->Alert("alert-danger", $e->getMessage());
		}
		
		return $count;
	}
	
	public function getSubjectPerformance($data)
	{
		try
		{
			$store['subperforms'] = array();
			$perfs = array();
			$position = 0;
			//$this->compare_averages($x, $y);
			
			usort($data, array($this, "compare"));
			foreach($data as $dt):
				$position++;
				
				$perfs['student'] = $dt['student'];
				$perfs['average'] = $dt['average'];
				$perfs['position'] = $position;
				
				array_push($store['subperforms'], $perfs);
			endforeach;
		}
		catch(Exception $e)
		{
			$this->model->Alert("alert-danger", $e->getMessage());
		}
		
		return $store['subperforms'];
	}
	
	/*****
		Gets student division taking subject average mark as the parameter
	*****/
	public function getDivision($aggregate)
	{
		$division = $this->model->getdivision($aggregate);
		
		return $division;
	}	
	
	/*****
		Get teacher initials
	*****/
	public function getInitials($class, $subject)
	{
		$data = $this->model->getinitials($class, $subject);
		
		$words = explode(" ", $data);
		$initials = "";
		
		foreach ($words as $w) {
		  $initials .= $w[0];
		}
		return $initials;
	}	
	
	/*****
		Count students
	*****/
	public function countStudents($classid)
	{
		$data = $this->model->countstudents($classid);
		
		return $data;
	}
}
?>