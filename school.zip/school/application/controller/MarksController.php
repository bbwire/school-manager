<?php
require_once "application/controller/Controller.php"; 

class MarksController extends Controller
{
	
	/*
		add new subject
	*/
	public function postmarks()
	{
		$table = "marks";
		$year = mysqli_real_escape_string($this->model->mysqli, $_POST['year']);
		$term = mysqli_real_escape_string($this->model->mysqli, $_POST['term']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$stdno = mysqli_real_escape_string($this->model->mysqli, $_POST['stdno']);
		$marks = mysqli_real_escape_string($this->model->mysqli, $_POST['marks']);

		$redirect = "marks.php";
		
		$columns = "testExamType, studentNumber, studentMark, subjectId, year, term, classId";
		$values = "'$type', '$stdno', '$marks', '$subject', '$year', '$term', '$class'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update subject
	*/
	public function updatemarks($id)
	{
		$table = "marks";
		$year = mysqli_real_escape_string($this->model->mysqli, $_POST['year']);
		$term = mysqli_real_escape_string($this->model->mysqli, $_POST['term']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$stdno = mysqli_real_escape_string($this->model->mysqli, $_POST['stdno']);
		$marks = mysqli_real_escape_string($this->model->mysqli, $_POST['marks']);

		$redirect = "marks.php";
		
		$column_value = "testExamType = '$type', studentNumber = '$stdno', studentMark = '$marks', subjectId = '$subject', year = '$year', term = '$term', classId = '$class'";
		
		$data = $this->model->update($table, $column_value, "marksId", $id, $redirect);
		
		return $data;
	}
	
	/*
		add new subject
	*/
	public function postamarks()
	{
		$table = "amarks";
		$year = mysqli_real_escape_string($this->model->mysqli, $_POST['year']);
		$term = mysqli_real_escape_string($this->model->mysqli, $_POST['term']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$stdno = mysqli_real_escape_string($this->model->mysqli, $_POST['stdno']);
		$marks = mysqli_real_escape_string($this->model->mysqli, $_POST['marks']);
		$paper = mysqli_real_escape_string($this->model->mysqli, $_POST['paper']);
		
		if($paper == 'no')
		{
			$subject = $subject;
			$mtype = 'subject';
		}
		else
		{
			$subject = $paper;
			$mtype = 'paper';
		}

		$redirect = "alevel-marks.php";
		
		$columns = "testExamType, studentNumber, studentMark, subjectId, year, term, classId, mtype";
		$values = "'$type', '$stdno', '$marks', '$subject', '$year', '$term', '$class', '$mtype'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update subject
	*/
	public function updateamarks($id)
	{
		$table = "amarks";
		$year = mysqli_real_escape_string($this->model->mysqli, $_POST['year']);
		$term = mysqli_real_escape_string($this->model->mysqli, $_POST['term']);
		$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
		$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
		$stdno = mysqli_real_escape_string($this->model->mysqli, $_POST['stdno']);
		$marks = mysqli_real_escape_string($this->model->mysqli, $_POST['marks']);

		$redirect = "alevel-marks.php";
		
		$column_value = "testExamType = '$type', studentNumber = '$stdno', studentMark = '$marks', year = '$year', term = '$term', classId = '$class'";
		
		$data = $this->model->update($table, $column_value, "marksId", $id, $redirect);
		
		return $data;
	}
	
	/*
		Upload from excel sheet
	*/
	public function uploadfromexcel($table, $redirect)
	{
		
		if(isset($_FILES['file']['name'])){
			
			$year = mysqli_real_escape_string($this->model->mysqli, $_POST['yearex']);
			$term = mysqli_real_escape_string($this->model->mysqli, $_POST['term']);			
			$class = mysqli_real_escape_string($this->model->mysqli, $_POST['class']);
			$subject = mysqli_real_escape_string($this->model->mysqli, $_POST['subject']);
			$type = mysqli_real_escape_string($this->model->mysqli, $_POST['type']);
			
			if($table == 'amarks'){
				$paper = mysqli_real_escape_string($this->model->mysqli, $_POST['paper']);
			
				if($paper == 'no')
				{
					$subject = $subject;
					$mtype = 'subject';
				}
				else
				{
					$subject = $paper;
					$mtype = 'paper';
				}
			}
			$filename = $_FILES["file"]["tmp_name"];
	 
	 
			 if($_FILES["file"]["size"] > 0)
			 {
	 
				$file = fopen($filename, "r");
				
				$data = '';
				
				//if(count($file) > 1){
					$row = 0;
					 while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE)
					 {
						$row++;
						 
						 if($row == 1){}
						  else
						  {
						  $stdno = $emapData[0];
						  $mark = $emapData[1];
						  
						  if($table == 'amarks')
							$check = $this->getcustomdata("SELECT * FROM $table WHERE subjectId = '$subject' and testExamType = '$type' and year = '$year' and term = '$term' and studentNumber = '$stdno' and mtype = '$mtype'");
						  else
							  $check = $this->getcustomdata("SELECT * FROM $table WHERE subjectId = '$subject' and testExamType = '$type' and year = '$year' and term = '$term' and studentNumber = '$stdno'");
						  
						  if(count($check) > 0)
						  {
							  if($table == 'amarks'){
								  $colums = "studentMark = '$mark'";
								  
								  $where = "subjectId = '$subject' and testExamType = '$type' and year = '$year' and term = '$term' and studentNumber = '$stdno' and mtype = '$mtype'";
								  
								  $data = $this->model->updateexcel($table, $colums, $where, $redirect);
							  }else{
								  $colums = "studentMark = '$mark'";
								  
								  $where = "subjectId = '$subject' and testExamType = '$type' and year = '$year' and term = '$term' and studentNumber = '$stdno'";
								  
								  $data = $this->model->updateexcel($table, $colums, $where, $redirect);

							  }
						  }
						  else
						  {
							  if($table == 'amarks'){
								  $columns = "subjectId, testExamType, studentNumber, studentMark, year, term, classId, mtype";
								  $values = "'$subject', '$type', '$stdno', '$mark', '$year', '$term', '$class', '$mtype'";
											  
								  $data = $this->model->saveexcel($table, $columns, $values, $redirect);
							  }else{
								  $columns = "subjectId, testExamType, studentNumber, studentMark, year, term, classId";
								  $values = "'$subject', '$type', '$stdno', '$mark', '$year', '$term', '$class'";
											  
								  $data = $this->model->saveexcel($table, $columns, $values, $redirect);

							  }
						  }
						  }		
			
					 }
				
				 
					 fclose($file);
					 
					 $this->model->Alert("alert-success", "Marks have been uploaded successfully!");
				 /*}
				else
				{
					$this->model->Alert("alert-danger","There was no data in the file");
				}*/
			 }
		}
		
		return $data;
	}
}
?>