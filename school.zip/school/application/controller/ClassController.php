<?php
require_once "application/controller/Controller.php"; 

class ClassController extends Controller
{
	
	
	/*
		add new class
	*/
	public function postclass()
	{
		$table = "classes";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$teacher = mysqli_real_escape_string($this->model->mysqli, $_POST['teacher']);
		$redirect = "classes.php";
		
		$columns = "className, classTeacher";
		$values = "'$name', '$teacher'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update class
	*/
	public function updateclass($id)
	{
		$table = "classes";
		$name = mysqli_real_escape_string($this->model->mysqli, $_POST['name']);
		$teacher = mysqli_real_escape_string($this->model->mysqli, $_POST['teacher']);
		$redirect = "classes.php";
		
		$column_value = "className = '$name', classTeacher = '$teacher'";
		
		$data = $this->model->update($table, $column_value, "id", $id, $redirect);
		
		return $data;
	}
}
?>