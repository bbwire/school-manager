<?php
require_once "application/controller/Controller.php"; 

class DivisionController extends Controller
{
	
	
	/*
		add new grade
	*/
	public function postdivision()
	{
		$table = "divisions";
		$division = mysqli_real_escape_string($this->model->mysqli, $_POST['division']);
		$min = mysqli_real_escape_string($this->model->mysqli, $_POST['min']);
		$max = mysqli_real_escape_string($this->model->mysqli, $_POST['max']);
		$redirect = "divisions.php";
		
		$columns = "division, minimumAggregate, maximumAggregate";
		$values = "'$division', '$min', '$max'";
		
		$data = $this->model->save($table, $columns, $values, $redirect);
		
		return $data;
	}
	
	/*
		update grade
	*/
	public function updatedivision($id)
	{
		$table = "divisions";
		$division = mysqli_real_escape_string($this->model->mysqli, $_POST['division']);
		$min = mysqli_real_escape_string($this->model->mysqli, $_POST['min']);
		$max = mysqli_real_escape_string($this->model->mysqli, $_POST['max']);
		$redirect = "divisions.php";
		
		$column_value = "division = '$division', minimumAggregate = '$min', maximumAggregate = '$max'";
		
		$data = $this->model->update($table, $column_value, "divisionId", $id, $redirect);
		
		return $data;
	}
}
?>