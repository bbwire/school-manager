<?php

class Model{
	
	public $mysqli;
	private $config;
	private $getall;
	
	public function __construct($base){
		
		require_once $base ."Config.php";
		
		$this->config = new Config();
		
		$this->mysqli = $this->config->Connection();
	}
	
	/*
		Redirect function
	*/
	public function Redirect($time, $url)
	{
		
		try
		{
			
			header("refresh:". $time ."; url = ". $url);
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
	}
	
	public function startSession(){
		
		session_start();
	}
	
	public function destroySession(){
		
		session_destroy();
		
	}
	
	public function getSessionId(){
		
		$usid = null;
		
		try{
			
			if(isset($_SESSION['user'])){
				
				$usid = $_SESSION['user'];
				
				//return true;
				
			}else{
				
				return false;
			}
			
		}catch(Exception $e){
			
			throw new Exception($e->getMessage());
		}
		
		return $usid;
	}
	
	public function getIP(){
		
		try{
			
			$ip = $_SERVER['REMOTE_ADDR'];
			
		}catch(Exception $e){
			
			throw new Exception($e->getMessage());
		}
		
		return $ip;
	}
	
	public function getSessionName(){
		
		$usname = null;
		
		try{
			
			if(isset($_SESSION['name'])){
				
				$usname = $_SESSION['name'];
				
				//return true;
				
			}else{
				
				return false;
			}
			
		}catch(Exception $e){
			
			throw new Exception($e->getMessage());
		}
		
		return $usname;
	}
	
	/*
		Create new user session
	*/
	public function newUserSession($userid,$name){
		
		try
		{
			$_SESSION['user'] = $userid;
			$_SESSION['name'] = $name;
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
	}
	
	/*
		Alert function (for messages after action)
	*/
	public function Alert($alert_type, $message)
	{
		
		try
		{
			
			?>
            <div class="alert <?php echo $alert_type;?> alert-dismissible fade in" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
                </button>
                <i class="fa fa-check"></i> <strong><?php echo $message;?></strong>
            </div>
            <?php
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
	}
	
	public function DoLogin($username, $password, $fredirect_url, $redirect_url){
		
		
		try{
			
			$res = $this->mysqli->query("SELECT * FROM users where username = '". $username ."' and password='". $password ."'");
			
			if($res){
				
				if($res->num_rows > 0){
					
					$row = $res->fetch_assoc();
					
					$id = $row['userid'];
					$name = $row['username'];
					
					$this->newUserSession($id, $name);
					
					$this->Alert("alert-success", "Hi, ". $name .", you have logged in successfully! ");
					
					$this->Redirect("1", $redirect_url);
					
				}else{
					
					$this->Alert("alert-danger", "Username or password is wrong... ");
					
					$this->Redirect("1", $fredirect_url);
				}
				
			}else{
				
				$this->Alert("alert-danger","Sorry, we encountered an issue! ".$this->mysqli->error);
				
				$this->Redirect("1", $fredirect_url);
			}			
			
		}catch(Exception $e){
			
			throw new Exception($e->getMessage());
		}
		
		return $res;
	}
	
	/*
		General delete function
	*/
	public function delete($table, $primary_key, $key_value, $redirect_url)
	{
		try
		{
			
			$take = $this->mysqli->query("DELETE FROM $table where $primary_key = '". $key_value ."'");
			
			if($take)
			{
				$this->Alert("alert-success", "Record has been deleted!");
				
				$this->Redirect("1", $redirect_url);
			}
			else
			{
				$this->Alert("alert-danger", "Sorry! We encountered an error, ". $this->mysqli->error ."");
				
				$this->Redirect("1", $redirect_url);
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	/*
		General delete multiple function
	*/
	public function deleteMultiple($table, $primary_key, $key_value, $redirect_url)
	{
		try
		{
			
			$take = $this->mysqli->query("DELETE FROM $table where $primary_key = '". $key_value ."'");
			
			if($take)
			{
				
				$this->Redirect("1", $redirect_url);
			}
			else
			{
				$this->Alert("alert-danger", "Sorry! We encountered an error, ". $this->mysqli->error ."");
				
				$this->Redirect("1", $redirect_url);
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	/*
		Select all function
	*/
	public function SelectAll($table, $primary, $order)
	{
		$data = array();
		
		try
		{			
			
			$this->getall = $this->mysqli->query("SELECT * FROM ". $table ." ORDER BY ". $primary ." ". $order);
			
			while($object = $this->getall->fetch_object())
			{
				$data[] = $object;
			}
						
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $data;
		
	}
	
	/*
		Select all function with a custom query
	*/
	public function SelectCustom($query)
	{
		$data = array();
		
		try
		{			
			
			$this->getall = $this->mysqli->query($query);
			
			while($object = $this->getall->fetch_object())
			{
				$data[] = $object;
			}
						
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $data;
		
	}
	
	/*
		Select all function
	*/
	public function SelectIndividual($table, $key, $value)
	{
		$data = array();
		
		try
		{			
			
			$getind = $this->mysqli->query("SELECT * FROM ". $table ." WHERE ". $key ." = '". $value ."'");
			
			while($object = $getind->fetch_object())
			{
				$data[] = $object;
			}
						
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $data;
		
	}
	
	/*
		Select user details
	*/
	public function getUserDetails($user)
	{
		$data = array();
		
		try
		{			
			
			$this->getall = $this->mysqli->query("SELECT * FROM users where userid = '". $user ."'");
			
			while($object = $this->getall->fetch_object())
			{
				$data[] = $object;
			}
						
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $data;
		
	}
	
	/*
		Select multiple function
	*/
	public function SelectMultiple($table1, $table2, $keyfield)
	{
		$data = array();
		
		try
		{			
			
			$this->getall = $this->mysqli->query("SELECT * FROM ". $table1 ." a, ". $table2 ." b where a.". $keyfield ." = b.". $keyfield);
			
			while($object = $this->getall->fetch_object())
			{
				$data[] = $object;
			}
						
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $data;
		
	}
	
	/*
		General save function
	*/
	public function save($table, $columns, $values, $redirect)
	{
		try
		{
			
			$take = $this->mysqli->query("INSERT INTO $table ($columns) values($values)");
			
			if($take)
			{
				$this->Alert("alert-success", "Data has been saved!");
				
				$this->Redirect("2", $redirect);
			}
			else
			{
				$this->Alert("alert-danger", "Sorry! We encountered an error, ". $this->mysqli->error ."");
				
				$this->Redirect("2", $redirect);
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	/*
		General excel save function
	*/
	public function saveexcel($table, $columns, $values, $redirect)
	{
		try
		{
			
			$take = $this->mysqli->query("INSERT INTO $table ($columns) values($values)");
			
			if($take)
			{
				
				$this->Redirect("2", $redirect);
			}
			else
			{
				
				$this->Redirect("2", $redirect);
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	/*
		General update function
	*/
	public function update($table, $column_value, $primary_key, $key_value, $redirect)
	{
		try
		{
			
			$take = $this->mysqli->query("UPDATE $table SET $column_value WHERE $primary_key = '". $key_value ."'");
			
			if($take)
			{
				$this->Alert("alert-success", "Changes have been saved!");
				
				$this->Redirect("2", $redirect);
			}
			else
			{
				$this->Alert("alert-danger", "Sorry! We encountered an error, ". $this->mysqli->error ."");
				
				$this->Redirect("2", $redirect);
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	/*
		General update function
	*/
	public function updateexcel($table, $column_value, $where, $redirect)
	{
		try
		{
			
			$take = $this->mysqli->query("UPDATE $table SET $column_value WHERE ". $where ."");
			
			if($take)
			{
				
				//$this->Redirect("2", $redirect);
			}
			else
			{
				
				//$this->Redirect("2", $redirect);
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	public function UpdateImg($table, $column_value, $primary_key, $key_value)
	{
		try
		{
			
			$take = $this->mysqli->query("UPDATE $table SET $column_value WHERE $primary_key = '". $key_value ."'");
			
			if($take)
			{
				
				//$this->Redirect("2", $redirect);
			}
			else
			{
				$this->Alert("alert-danger", "Sorry! We encountered an error, ". $this->mysqli->error ."");
				
				
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
	}
	
	public function getscore($table, $student, $subject, $type, $year, $term, $marktype)
	{
		$score = '';
		
		try
		{
			if($table == 'amarks')
				$get = $this->mysqli->query("SELECT studentMark, marksId, subjectId, testExamType, studentNumber, year, term FROM ". $table ." WHERE studentNumber = '$student' AND subjectId = '$subject' AND testExamType = '$type' AND year = '$year' AND term = '$term' AND mtype = '$marktype'");
			else
				$get = $this->mysqli->query("SELECT studentMark, marksId, subjectId, testExamType, studentNumber, year, term FROM ". $table ." WHERE studentNumber = '$student' AND subjectId = '$subject' AND testExamType = '$type' AND year = '$year' AND term = '$term'");
			
			if($get->num_rows > 0)
			{
				$row = $get->fetch_assoc();
				
				$score = $row['studentMark'];
				
			}
			else
			{
				$score = $score;
			}
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $score;
	}
	
	/***
		The function that gets the grade
	***/
	public function getgrade($mark)
	{
		try
		{
			$get_grade = $this->mysqli->query("SELECT markFrom, markTo, grade FROM grades");
			
			$grade = 'Ungraded';
			
			while($row = $get_grade->fetch_assoc())
			{
				$min = $row['markFrom'];
				$max = $row['markTo'];
				
				if($min <= $mark && $mark <= $max)
				{
					$grade = $row['grade'];
				}
				else
				{
					$grade = $grade;
				}
			}
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $grade;
	}
	
	/***
		The function that gets the grade
	***/
	public function getagrade($mark, $type)
	{
		try
		{
			if($type == 'single')
			{
				$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mark' and paperType = 'single'");
			}
			else
			{
				if($type == 'double')
				{
					
					sort($mark);
					if($mark[1] != '' and $mark[0] != '')
					{
						$fst = $mark[0];
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$scnd' and paperType = 'double'");
					}
					else if($mark[1] == '' and $mark[0] != '')
					{
						$scnd = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$scnd' and paperType = 'single'");
					
					}
					else if($mark[1] != '' and $mark[0] == '')
					{
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$scnd' and paperType = 'single'");
					}
					else
					{
						$mrk = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'sinle'");
					}
					
					
				}
				
				if($type == 'triple')
				{
					$fst = 0;
					$scnd = 0;
					$thrd = 0;
					sort($mark);
					if(count($mark) == 3 and $mark[2] != '' and $mark[1] != '' and $mark[0] != '' )
					{
						$mrk = $mark[2];
						$fst = $mark[0];
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$scnd' and thirdBestPaper = '$mrk' and paperType = 'triple'");
					}
					elseif(count($mark) == 3 and $mark[0] != '' and $mark[1] != '' and $mark[2] == '' )
					{
						$fst = $mark[0];
						$mrk = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$mrk' and paperType = 'double'");
					}
					elseif(count($mark) == 3 and $mark[2] == '' and $mark[1] == '' and $mark[0] != '' )
					{
						$mrk = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'single'");
					}
					elseif(count($mark) == 3 and $mark[0] != '' and $mark[1] == '' and $mark[2] != '' )
					{
						$fst = $mark[0];
						$mrk = $mark[2];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$mrk' and paperType = 'double'");
					}
					elseif(count($mark) == 3 and $mark[0] == '' and $mark[1] != '' and $mark[2] != '' )
					{
						$fst = $mark[1];
						$mrk = $mark[2];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$mrk' and paperType = 'double'");
					}
					elseif(count($mark) == 3 and $mark[2] != '' and $mark[1] == '' and $mark[0] == '' )
					{
						$mrk = $mark[2];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'single'");
					}
					elseif(count($mark) == 3 and $mark[2] == '' and $mark[1] != '' and $mark[0] == '' )
					{
						$mrk = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'single'");
					}
					else if(count($mark) == 4 and $mark[0] != '' and $mark[1] != '' and $mark[2] != '' and $mark[3] != '' )
					{
						$mrk = $mark[2];
						$fst = $mark[0];
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$scnd' and thirdBestPaper = '$mrk' and paperType = 'triple'");
					}
					else if(count($mark) == 4 and $mark[0] != '' and $mark[1] != '' and $mark[2] != '' and $mark[3] == '' )
					{
						$mrk = $mark[2];
						$fst = $mark[0];
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$scnd' and thirdBestPaper = '$mrk' and paperType = 'triple'");
					}
					else if(count($mark) == 4 and $mark[0] != '' and $mark[1] != '' and $mark[2] == '' and $mark[3] == '' )
					{
						$fst = $mark[0];
						$mrk = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$mrk' and paperType = 'double'");
					}
					else if(count($mark) == 4 and $mark[0] != '' and $mark[1] == '' and $mark[2] == '' and $mark[3] == '' )
					{
						$mrk = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'single'");
					}
					else if(count($mark) == 4 and $mark[0] == '' and $mark[1] != '' and $mark[2] != '' and $mark[3] != '' )
					{
						$mrk = $mark[3];
						$fst = $mark[1];
						$scnd = $mark[2];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$scnd' and thirdBestPaper = '$mrk' and paperType = 'triple'");
					}
					else if(count($mark) == 4 and $mark[0] == '' and $mark[1] == '' and $mark[2] != '' and $mark[3] != '' )
					{
						$fst = $mark[2];
						$mrk = $mark[3];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$fst' and secondBestPaper = '$mrk' and paperType = 'double'");
					}
					else if(count($mark) == 4 and $mark[0] == '' and $mark[1] == '' and $mark[2] == '' and $mark[3] != '' )
					{
						$mrk = $mark[3];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'single'");
					}
					else if(count($mark) == 4 and $mark[0] != '' and $mark[1] != '' and $mark[2] == '' and $mark[3] != '' )
					{
						$mrk = $mark[3];
						$fst = $mark[0];
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where  bestPaper = '$fst' and secondBestPaper = '$scnd' and thirdBestPaper = '$mrk' and paperType = 'triple'");
					}
					else{
						
						$mrk = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'single'");
					}
						
				}
			}
			
			$grade = '';
			
			while($row = $get_grade->fetch_assoc())
			{
				$grade = $row['grade'];
			}
			
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $grade;
	}
	
	/***
		The function that gets the grade
	***/
	public function getcomment($table, $mark)
	{
		try
		{
			$get_grade = $this->mysqli->query("SELECT markFrom, markTo, comment FROM ". $table);
			
			$comment = '-';
			
			while($row = $get_grade->fetch_assoc())
			{
				$min = $row['markFrom'];
				$max = $row['markTo'];
				
				if($min <= $mark && $mark <= $max)
				{
					$comment = $row['comment'];
				}
				else
				{
					$comment = $comment;
				}
			}
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $comment;
	}
	
	/***
		The function that gets the grade
	***/
	public function getacomment($mark, $type)
	{
		try
		{
			if($type == 'single')
			{
				$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mark' and paperType = 'single'");
			}
			else
			{
				if($type == 'double')
				{
					
					sort($mark);
					if(count($mark) > 1){
						$scnd = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where secondBestPaper = '$scnd' and paperType = 'double'");
					}else if(count($mark) == 1 and $mark[0] != ''){
						$scnd = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$scnd' and paperType = 'double'");
					
					}
				}
				
				if($type == 'triple')
				{
					sort($mark);
					if(count($mark) > 2 and $mark[2] != '' and $mark[1] != '' ){
						$mrk = $mark[2];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where thirdBestPaper = '$mrk' and paperType = 'triple'");
					}else if(count($mark) == 2 and $mark[1] != ''){
						$mrk = $mark[1];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where secondBestPaper = '$mrk' and paperType = 'triple'");
					}else{
						
						$mrk = $mark[0];
						$get_grade = $this->mysqli->query("SELECT * FROM alevelgrades where bestPaper = '$mrk' and paperType = 'triple'");
					}
				}
			}
			
			$comment = '';
			
			while($row = $get_grade->fetch_assoc())
			{
				$comment = $row['comment'];
			}
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $comment;
	}
	
	/***
		The function that gets the grade
	***/
	public function getdivision($aggregate)
	{
		try
		{
			$get_division = $this->mysqli->query("SELECT minimumAggregate, maximumAggregate, division FROM divisions");
			
			$division = 'No Division';
			
			while($row = $get_division->fetch_assoc())
			{
				$min = $row['minimumAggregate'];
				$max = $row['maximumAggregate'];
				
				if($min <= $aggregate && $aggregate <= $max)
				{
					$division = $row['division'];
				}
				else
				{
					$division = $division;
				}
			}
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $division;
	}
	
	/***
		The function that gets the initials
	***/
	public function getinitials($class, $subject)
	{
		try
		{
			$get_initials = $this->mysqli->query("SELECT teacher, classId, subjectId FROM subjectteacher WHERE classId = '". $class ."' and subjectId = '". $subject ."'");
			
			$teacher = 'Not / Available';
			
			while($row = $get_initials->fetch_assoc())
			{
				$teacher = $row['teacher'];
			}
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $teacher;
	}
	
	/***
		Count students
	***/
	public function countstudents($classid)
	{
		try
		{
			$data = $this->mysqli->query("SELECT * FROM students WHERE class = '". $classid ."'");
			
			$count = $data->num_rows;						
		}
		catch(Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		
		return $count;
	}
}

?>