<?php
error_reporting(0);
session_start();
if(isset($_SESSION['user'])){
	header("location:./");
}
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Create Database </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://colorlib.com/polygon/gentelella/css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.css" rel="stylesheet">
	
	<script src="vendors/jquery/dist/jquery.min.js"></script>
	
	<script>
		$("#import").click(function(){
			var file = $("#sqlfile").val();
			
			if(file == '')
			{
				$("div.output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please choose file to upload</div>'); 
				return false; 
			}
		});
	</script>
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
          	<?php
			
			include 'database-backup.php';
			
			if(isset($_POST['create']))
			{
				
				$dbname = htmlspecialchars($_POST['name']);
				
				create($dbname);
			}
			
			
			if(isset($_POST['import'])){
				
				$path = '';
				if(!empty($_FILES['sqlfile']['name']) ){
					$pic = $_FILES['sqlfile'];
					$pic_name = $pic['name'];
					$pic_name = htmlentities($pic_name);
					$pic_tmp = $pic['tmp_name'];
					
					$path = $_FILES['sqlfile']['tmp_name'];
				}
				
				$import = IMPORT_TABLES($servername,$username,$password,"dbschoolmanager", $path);
				
				if($import){
					?>
					<div class="alert <?php echo $alert_type;?> alert-dismissible fade in" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span>
						</button>
						<i class="fa fa-check"></i> <strong>Database has been imported successfully</strong>
					</div>
					<div class="alert alert-success alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Database has been imported successfully</div>
					<?php
					header("refresh:1; url=login.php");
				}
			}
			?>
			
			<?php
			if(!isset($_GET['success'])){
			?>
            <form action="" method="post">
              <h1>Create Database</h1>
              <div>
                <input type="text" class="form-control" placeholder="dbschoolmanager" name="name" value="dbschoolmanager" readonly required="" />
              </div>
              <div>
                <input type="submit" class="btn btn-primary pull-left" name="create" value="Create">
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                

                <div class="clearfix"></div>
                <br />

                <div>
                  <p>© <?php echo date("Y");?> All Rights Reserved. </p>
                </div>
              </div>
            </form>
			<?php
			}else{
				?>
				<form action="" method="post" enctype="multipart/form-data">
				  <h1>Import database file</h1>
				  <div class="output"></div>
				  <div>
					<input type="file" name="sqlfile" id="sqlfile" required="" />
				  </div>
				  <hr>
				  <div>
					<input type="submit" class="btn btn-primary pull-left" id="import" name="import" value="Import">
				  </div>

				  <div class="clearfix"></div>

				  <div class="separator">
					

					<div class="clearfix"></div>
					<br />

					<div>
					  <p>© <?php echo date("Y");?> All Rights Reserved. </p>
					</div>
				  </div>
				</form>
				<?php
				
			}
			?>
          </section>
        </div>

        
      </div>
    </div>
  </body>
</html>
