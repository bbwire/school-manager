		<?php
		require_once ("inc/essentials.php");
		
		$class = "MarksController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Marks </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
						if(isset($_POST['postnew']))
						{
							$controller->postamarks();
						}
						
						if(isset($_POST['upload']))
						{
							$controller->uploadfromexcel("amarks", "alevel-marks.php");
						}
						
					if(isset($_GET['new'])){
						
						?>
                        <form class="form-horizontal form-label-left" method="post" id="demo-form2" data-parsley-validate>

                          <span class="section"><i class="fa fa-plus"></i> Add marks</span>
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="year">Year <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="year" class="form-control" name="year" placeholder="Select year" required="required" type="text">
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="term">Select term <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$terms = array('Term 1', 'Term 2', 'Term 3');
								?>
                              <select id="term" class="form-control" name="term" required>
                              	<option value="">Select term</option>
                                <?php
								foreach($terms as $term):
								?>
                                	<option><?php echo $term;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="class">Class <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$classes = $controller->getcustomdata("SELECT * FROM classes where classlevel = 'A Level'");
								?>
                              <select id="class" class="class form-control" name="class" required>
                              	<option value="">Select class</option>
                              	<?php
								foreach($classes as $class):
								?>
                                
                                <option value="<?php echo $class->id;?>"><?php echo $class->className;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="plainadd">Subject <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$sql_query = "select * from subject where subjectLevel = 'A Level'";
								$subjects = $controller->getcustomdata($sql_query);
								?>
                              <select id="plainadd" class="subject form-control sub" name="subject" required>
                              	<option value="">Select student number</option>
                              	<?php
								foreach($subjects as $subject):
								?>
                                
                                <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="paper">Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	
                              	<select class="form-control" name="paper" id="paper" required>
                                	                                
                                </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="type">Select type <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$types = array('BOT Test', 'EOT Test', 'BOT Exam', 'EOT Exam');
								?>
                              <select id="type" class="form-control" name="type" required>
                              	<option value="">Select type</option>
                                <?php
								foreach($types as $type):
								?>
                                	<option><?php echo $type;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="stdno">Student Number <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$students = $controller->getcustomdata("SELECT * FROM students WHERE studyLevel = 'A Level'");
								?>
                              <select id="stdno" class="stdno form-control" name="stdno" required>
                              	<option value="">Select student number</option>
                              	<?php
								foreach($students as $student):
								?>
                                
                                <option value="<?php echo $student->studentNumber;?>"><?php echo $student->studentNumber;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="marks">Marks <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="marks" class="form-control" name="marks" placeholder="Student marks" required="required" type="text">
                            </div>
                          </div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" class="btn btn-success" name="postnew"><i class="fa fa-check"></i> Save marks</button>
                            </div>
                          </div>
                        </form>
                        <div class="clearfix"></div>
                        <hr>
                        <h3>Upload from excel(csv) file</h3>
						<div class="output"></div>
                        <form class="form-horizontal form-label-left xmarks" method="post" id="demo-form2" data-parsley-validate enctype="multipart/form-data">
                        	 <div class="item form-group">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="yearex">Year <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <input id="yearex" class="form-control" name="yearex" placeholder="Select year" required="required" type="text">
                                </div>
                              </div>
                              
                              <div class="item form-group">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="term">Select term <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $terms = array('Term 1', 'Term 2', 'Term 3');
                                    ?>
                                  <select id="term" class="form-control" name="term" required>
                                    <option value="">Select term</option>
                                    <?php
                                    foreach($terms as $term):
                                    ?>
                                        <option><?php echo $term;?></option>                                
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="class">Class <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'A Level'");
								?>
                              <select id="class" class="class form-control" name="class" required>
                              	<option value="">Select class</option>
                              	<?php
								foreach($classes as $class):
								?>
                                
                                <option value="<?php echo $class->id;?>"><?php echo $class->className;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                        	
                        	<div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="subject">Subject <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $sql_query = "select * from subject where subjectLevel = 'A Level'";
									$subjects = $controller->getcustomdata($sql_query);
                                    ?>
                                  <select id="subject" class="subject form-control xsub" name="subject" required>
                                    <option value="">Select student number</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                          
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="paper1">Paper <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    
                                    <select class="form-control" name="paper" id="paper1" required>
                                                                        
                                    </select>
                                </div>
                              </div>
                              <div class="item form-group">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="type">Select type <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $types = array('BOT Test', 'EOT Test', 'BOT Exam', 'EOT Exam');
                                    ?>
                                  <select id="type" class="form-control" name="type" required>
                                    <option value="">Select type</option>
                                    <?php
                                    foreach($types as $type):
                                    ?>
                                        <option><?php echo $type;?></option>                                
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              
                        	<div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pic">Choose the csv file to upload <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="filexmarks" name="file" type="file">
                            </div>
                          </div>
                          <div class="clearfix"></div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="sendxmarks" type="submit" class="btn btn-success" name="upload"><i class="fa fa-upload"></i> Upload marks file</button>
                            </div>
                          </div>
                          
                        </form>
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updateamarks($updateid);
						}
						
						$updatedatas = $controller->getindividual("amarks", "marksId", $updateid);
						
						foreach($updatedatas as $data):
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                      
                          <span class="section">Update Info</span>
    
    					  
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="year">Year <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="year" class="form-control" name="year" placeholder="Select year" value="<?php echo $data->year;?>" required="required" type="text">
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="term">Select term <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$terms = array('Term 1', 'Term 2', 'Term 3');
								?>
                              <select id="term" class="form-control" name="term" required>
                              	<option value="">Select term</option>
                                <?php
								foreach($terms as $term):
								?>
                                	<option <?php if($data->term == $term) echo "Selected";?>><?php echo $term;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="class">Class <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'A Level'");
								?>
                              <select id="class" class="class form-control" name="class" required>
                              	<option value="">Select class</option>
                              	<?php
								foreach($classes as $class):
								?>
                                
                                <option value="<?php echo $class->id;?>" <?php if($class->id == $data->classId) echo "Selected";?>><?php echo $class->className;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="subject">Subject <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$sql_query = "select * from subject where subjectLevel = 'A Level'";
								$subjects = $controller->getcustomdata($sql_query);
								?>
                              <select id="subject" class="subject form-control" name="subject" required>
                              	<option value="">Select student number</option>
                              	<?php
								foreach($subjects as $subject):
								?>
                                
                                <option value="<?php echo $subject->id;?>" <?php if($subject->id == $data->subjectId) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="type">Select type <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$types = array('BOT Test', 'EOT Test', 'BOT Exam', 'EOT Exam');
								?>
                              <select id="type" class="form-control" name="type" required>
                              	<option value="">Select type</option>
                                <?php
								foreach($types as $type):
								?>
                                	<option <?php if($type == $data->testExamType) echo "Selected";?>><?php echo $type;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="stdno">Student Number <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$students = $controller->getcustomdata("SELECT * FROM students WHERE studyLevel = 'A Level'");
								?>
                              <select id="stdno" class="stdno form-control" name="stdno" required>
                              	<option value="">Select student number</option>
                              	<?php
								foreach($students as $student):
								?>
                                
                                <option value="<?php echo $student->studentNumber;?>" <?php if($student->studentNumber == $data->studentNumber) echo "Selected";?>><?php echo $student->studentNumber;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="marks">Marks <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="marks" class="form-control" name="marks" placeholder="Student marks" value="<?php echo $data->studentMark;?>" required="required" type="text">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "amarks";
						$primary_key = "marksId";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'amarks';
							$url = basename($_SERVER['PHP_SELF']);
							$pk = 'marksId';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count records have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
					
					
					$myear = '';
					$mterm = '';
					$msubject = '';
					$mclass = '';
					$haspaper = null;
					if(isset($_GET['year']) and isset($_GET['term']) and isset($_GET['class']))
				  	{
					  $myear = $_GET['year'];
					  $mterm = $_GET['term'];
					  $msubject = $_GET['subject'];
					  $mclass = $_GET['class'];
					  
					  
					  if($msubject != ''){
						  
						  $check = $controller->getcustomdata("select * from subjectpaper where paperParent = '$msubject'");
						  
						  if(count($check) > 0){
							  $haspaper = 'true';
							  $sql = "SELECT * FROM subject s WHERE s.id = '$msubject' AND s.subjectLevel = 'A Level' ORDER BY s.id DESC";
						  }
						  else{
							  $haspaper = 'false';
							$sql = "SELECT * FROM amarks m, subject s, students st WHERE m.studentNumber = st.studentNumber AND m.subjectId = s.id AND m.year = '$myear' AND m.term = '$mterm' AND m.subjectId = '$msubject' AND classId = '$mclass' and m.mtype = 'subject' ORDER BY marksId DESC";
						  }
					  }else{
						$sql = "SELECT * FROM amarks m, subject s, students st WHERE m.studentNumber = st.studentNumber AND m.subjectId = s.id AND m.year = '$myear' AND m.term = '$mterm' AND classId = '$mclass' and m.mtype = 'subject' ORDER BY marksId DESC";
					  }
					}
				  	else
				  	{
						$sql = "SELECT * FROM amarks m, subject s, students st WHERE m.studentNumber = st.studentNumber AND m.subjectId = s.id ORDER BY marksId DESC";
				  	}
                 	?>
                    <div class="info"></div>
                    <div class="col-lg-10 col-sm-12">
                    	<p class="text-muted font-13 m-b-30">
                            <div class="row">
                                <form action="" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>
                                    <div class="col-lg-1">
                                        <h4>Filter</h4>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="text" id="year" name="year" value="<?php echo $myear;?>" placeholder="Select year" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                      <div class="item form-group">
                                            <?php
                                            $terms = array('Term 1', 'Term 2', 'Term 3');
                                            ?>
                                          <select id="term" class="form-control" name="term" required>
                                            <option value="">Select term</option>
                                            <?php
                                            foreach($terms as $term):
                                            ?>
                                                <option <?php if($term == $mterm) echo "Selected";?>><?php echo $term;?></option>                                
                                            <?php
                                            endforeach;
                                            ?>
                                          </select>
                                      </div>
                                    </div>
									
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'A Level'");
										?>
									  <select id="class" class="class form-control" name="class" required>
										<option value="">Select class</option>
										<?php
										foreach($classes as $class):
										?>
										
										<option value="<?php echo $class->id;?>" <?php if($class->id == $mclass) echo "Selected";?>><?php echo $class->className;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$sql_query = "select * from subject where subjectLevel = 'A Level'";
										$subjects = $controller->getcustomdata($sql_query);
										?>
									  <select id="subject" class="subject form-control" name="subject">
										<option value="">Select student number</option>
										<?php
										foreach($subjects as $subject):
										?>
										
										<option value="<?php echo $subject->id;?>" <?php if($subject->id == $msubject) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                    	<div class="btn-group">
                                    		<input type="submit" name="action" value="Filter marks" class="btn btn-primary">
                                            <?php
											if(isset($_GET['year'])){
											?>
                                            <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger"><span class="fa fa-times"></span> Cancel filter</a>
											<?php
											}
											?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </p>
                    </div>
                    <div class="col-lg-2 col-sm-12">
                    <p class="text-muted font-13 m-b-30">
                    	
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add marks</a>
                      <div class="clearfix"></div>
                    </p>
                    </div>
                    <div class="clearfix"></div>
                    <hr>
					<?php
					if(isset($_GET['year']) and isset($_GET['term']) and isset($_GET['class']))
				  	{
						
							if($haspaper == 'true'){
								?>
								<form action="" method="post" name="form1" onSubmit="return delete_confirm();">
								<table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
								  <thead>
									<tr>
									  <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
									  <th>Year</th>
									  <th>Term</th>
									  <th>Subject</th>
									  <th>Type</th>
									  <th>Student Name</th>
									  <th>Student Number</th>
									  <th>Marks</th>
									  <th>Operations</th>
									</tr>
								  </thead>

								  <tbody>
								  <?php
								  
								  $datas = $controller->getcustomdata($sql);
								  
								  $count = 0;
								  foreach($datas as $data):
									$msubid = $data->id;
									$count++;
									
									$subpaper = $controller->getcustomdata("SELECT * FROM amarks m, students st, subjectpaper sp WHERE m.studentNumber = st.studentNumber AND 
							  m.subjectId = sp.paperId  AND m.year = '$myear' AND m.term = '$mterm' AND m.classId = '$mclass' and m.mtype = 'paper' AND sp.paperParent = '$msubject' ORDER BY m.marksId DESC");
								  echo count($subpaper);
								  foreach($subpaper as $paper):
								  ?>
									<tr>
									  <td><input type="checkbox" name="ids[]" value="<?php echo $paper->marksId;?>" class="table_records flat "></td>
									  <td><?php echo $paper->year;?></td>
									  <td><?php echo $paper->term;?></td>
									  <td><?php echo $data->subjectTitle.' '.$paper->paperTitle;?></td>
									  <td><?php echo $paper->testExamType;?></td>
									  <td><?php echo $paper->fname. ' ' .$paper->lname;?></td>
									  <td><?php echo $paper->studentNumber;?></td>
									  <td><?php echo $paper->studentMark;?></td>
									  <td><a href="?update=<?php echo $paper->marksId;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $paper->marksId;?>"><i class="fa fa-trash"></i> Delete</button></td>
									</tr>
									
									<div class="modal fade" id="confirm-delete<?php echo $paper->marksId;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
											</div>
											<div class="modal-body">
												Are you sure you want to delete this record?
											</div>
											<div class="modal-footer">
												<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
												<a href="?delete=<?php echo $paper->marksId;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
											</div>
										</div>
									</div>
								</div>
								  <?php
								  endforeach;
								  endforeach;
								  ?>
									
								  </tbody>
								</table>
								
								<div class="clearfix"></div>
								<hr>
								<button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
								</form>
								
								<?php
							}else{
						
					?>
							<form action="" method="post" name="form1" onSubmit="return delete_confirm();">
							<table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
							  <thead>
								<tr>
								  <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
								  <th>Year</th>
								  <th>Term</th>
								  <th>Subject</th>
								  <th>Type</th>
								  <th>Student Name</th>
								  <th>Student Number</th>
								  <th>Marks</th>
								  <th>Operations</th>
								</tr>
							  </thead>

							  <tbody>
							  <?php
							  
							  $datas = $controller->getcustomdata($sql);
							  
							  $count = 0;
							  foreach($datas as $data):
							  
								$count++;
							  ?>
								<tr>
								  <td><input type="checkbox" name="ids[]" value="<?php echo $data->marksId;?>" class="table_records flat "></td>
								  <td><?php echo $data->year;?></td>
								  <td><?php echo $data->term;?></td>
								  <td><?php echo $data->subjectTitle;?></td>
								  <td><?php echo $data->testExamType;?></td>
								  <td><?php echo $data->fname. ' ' .$data->lname;?></td>
								  <td><?php echo $data->studentNumber;?></td>
								  <td><?php echo $data->studentMark;?></td>
								  <td><a href="?update=<?php echo $data->marksId;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $data->marksId;?>"><i class="fa fa-trash"></i> Delete</button></td>
								</tr>
								
								<div class="modal fade" id="confirm-delete<?php echo $data->marksId;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
										</div>
										<div class="modal-body">
											Are you sure you want to delete this record?
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
											<a href="?delete=<?php echo $data->marksId;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
										</div>
									</div>
								</div>
							</div>
							  <?php
							  endforeach;
							  ?>
								
							  </tbody>
							</table>
							
							<div class="clearfix"></div>
							<hr>
							<button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
							</form>
					
                    <?php 
							}
					}
					}?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>