-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2017 at 02:33 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbschoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(250) NOT NULL,
  `classId` text NOT NULL,
  `subjectId` int(250) NOT NULL,
  `teacherId` int(250) NOT NULL,
  `AssignTitle` varchar(250) NOT NULL,
  `AssignDescription` text NOT NULL,
  `AssignFile` varchar(250) NOT NULL,
  `AssignDeadLine` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(250) NOT NULL,
  `classId` int(250) NOT NULL,
  `subjectId` int(250) NOT NULL,
  `date` varchar(250) NOT NULL,
  `studentId` int(250) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `booklibrary`
--

CREATE TABLE `booklibrary` (
  `id` int(250) NOT NULL,
  `bookName` varchar(250) NOT NULL,
  `bookDescription` text NOT NULL,
  `bookAuthor` varchar(250) NOT NULL,
  `bookType` varchar(20) NOT NULL,
  `bookPrice` varchar(250) DEFAULT NULL,
  `bookFile` varchar(250) DEFAULT NULL,
  `bookState` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(250) NOT NULL,
  `className` varchar(250) NOT NULL,
  `classTeacher` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(250) NOT NULL,
  `eventTitle` varchar(250) NOT NULL,
  `eventDescription` text,
  `eventFor` varchar(10) DEFAULT NULL,
  `enentPlace` varchar(250) DEFAULT NULL,
  `eventDate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exammarks`
--

CREATE TABLE `exammarks` (
  `id` int(250) NOT NULL,
  `examId` int(250) NOT NULL,
  `classId` int(250) NOT NULL,
  `subjectId` int(250) NOT NULL,
  `studentId` int(250) NOT NULL,
  `examMark` varchar(250) NOT NULL,
  `attendanceMark` varchar(250) NOT NULL,
  `markComments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `examslist`
--

CREATE TABLE `examslist` (
  `id` int(250) NOT NULL,
  `examTitle` varchar(250) NOT NULL,
  `examDescription` text,
  `examDate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gradelevels`
--

CREATE TABLE `gradelevels` (
  `id` int(250) NOT NULL,
  `gradeName` varchar(250) NOT NULL,
  `gradeDescription` text,
  `gradePoints` varchar(250) NOT NULL,
  `gradeFrom` varchar(250) NOT NULL,
  `gradeTo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(250) NOT NULL,
  `messageId` int(250) NOT NULL,
  `userId` int(250) NOT NULL,
  `fromId` int(250) NOT NULL,
  `toId` int(250) NOT NULL,
  `messageText` text NOT NULL,
  `dateSent` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messageslist`
--

CREATE TABLE `messageslist` (
  `id` int(250) NOT NULL,
  `userId` int(250) NOT NULL,
  `toId` int(250) NOT NULL,
  `lastMessage` varchar(250) NOT NULL,
  `lastMessageDate` varchar(250) NOT NULL,
  `messageStatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `newsboard`
--

CREATE TABLE `newsboard` (
  `id` int(250) NOT NULL,
  `newsTitle` varchar(250) NOT NULL,
  `newsText` text NOT NULL,
  `newsFor` varchar(250) NOT NULL,
  `newsDate` int(250) NOT NULL,
  `creationDate` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) NOT NULL,
  `fieldName` varchar(250) NOT NULL,
  `fieldValue` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `fieldName`, `fieldValue`) VALUES
(1, 'address', ''),
(2, 'footer', 'All Rights Reserved, Schoex Script'),
(3, 'lastUpdateCheck', '1485154407'),
(4, 'latestVersion', '1.4'),
(6, 'phoneNo', ''),
(7, 'siteTitle', 'Schoex'),
(9, 'systemEmail', ''),
(14, 'schoolTerms', '&lt;p&gt;Our school terms :&lt;/p&gt;\n\n&lt;ul&gt;\n	&lt;li&gt;Term 1&lt;/li&gt;\n	&lt;li&gt;Term 2&lt;/li&gt;\n	&lt;li&gt;Term 3&lt;/li&gt;\n	&lt;li&gt;Term 4&lt;/li&gt;\n	&lt;li&gt;Term 5&lt;/li&gt;\n	&lt;li&gt;Term 6&lt;/li&gt;\n	&lt;li&gt;Term 7&lt;/li&gt;\n	&lt;li&gt;Term 8&lt;/li&gt;\n	&lt;li&gt;Term 9&lt;/li&gt;\n	&lt;li&gt;Term 10&lt;/li&gt;\n&lt;/ul&gt;\n'),
(15, 'attendanceModel', 'subject'),
(16, 'smsProvider', '{"smsProvider":"nexmo","nexmoApiKey":"","nexmoApiSecret":"","nexmoPhoneNumber":"dfc","twilioSID":"","twilioToken":"","twilioFN":"","hoiioAppId":"","hoiioAccessToken":"","clickatellApiKey":"","clickatellUserName":"","clickatellPassword":"","intellismsUserName":"","intellismsPassword":"","intellismsSenderNumber":"","bulksmsUserName":"","bulksmsPassword":"","conceptoUserName":"","conceptoPassword":"","conceptoSenderId":"","msg91Authkey":"","msg91SenderId":""}'),
(17, 'mailProvider', '{"mailProvider":"mail","smtpHost":"","smtpPort":"","smtpUserName":"","smtpPassWord":"","AmazonSESAccessKey":"","AmazonSESSecretKey":"","AmazonSESVerifiedSender":""}'),
(18, 'examDetailsNotif', 'mailsms'),
(19, 'examDetailsNotifTo', 'both'),
(20, 'absentNotif', 'mailsms'),
(21, 'address2', ''),
(22, 'paypalPayment', ''),
(23, 'paymentTax', '10'),
(24, 'activatedModules', '["newsboardAct","eventsAct","attendanceAct","bookslibraryAct","assignmentsAct","onlineexamsAct","mediaAct","paymentsAct","pollsAct","staticpagesAct","transportAct"]'),
(25, 'languageDef', '1'),
(26, 'languageAllow', '1'),
(27, 'layoutColor', 'black'),
(28, 'thisVersion', '1.4');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentId` int(11) NOT NULL,
  `serialNumber` varchar(20) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `class` varchar(20) NOT NULL,
  `stream` varchar(30) NOT NULL,
  `studentNumber` varchar(40) NOT NULL,
  `aggregate` int(11) NOT NULL,
  `dateOfBirth` varchar(20) NOT NULL,
  `religion` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `parent` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `residence` varchar(100) NOT NULL,
  `receiptNumber` varchar(10) NOT NULL,
  `combination` varchar(100) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(250) NOT NULL,
  `subjectTitle` varchar(250) NOT NULL,
  `subjectDescription` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `remember_token` varchar(250) NOT NULL,
  `fullName` varchar(250) NOT NULL,
  `role` varchar(10) NOT NULL,
  `activated` int(1) NOT NULL DEFAULT '1',
  `studentRollId` varchar(250) DEFAULT NULL,
  `auth_session` text NOT NULL,
  `birthday` int(250) NOT NULL DEFAULT '0',
  `gender` varchar(10) DEFAULT NULL,
  `address` text,
  `phoneNo` varchar(250) DEFAULT NULL,
  `mobileNo` varchar(250) DEFAULT NULL,
  `studentClass` int(250) DEFAULT '0',
  `parentProfession` varchar(250) DEFAULT NULL,
  `parentOf` text NOT NULL,
  `photo` varchar(250) DEFAULT '',
  `isLeaderBoard` text NOT NULL,
  `restoreUniqId` varchar(250) NOT NULL,
  `transport` int(250) NOT NULL,
  `defLang` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `remember_token`, `fullName`, `role`, `activated`, `studentRollId`, `auth_session`, `birthday`, `gender`, `address`, `phoneNo`, `mobileNo`, `studentClass`, `parentProfession`, `parentOf`, `photo`, `isLeaderBoard`, `restoreUniqId`, `transport`, `defLang`) VALUES
(1, 'bbwire', 'bbwire2@gmail.com', '$2y$10$RcTdzHyj6uDeGX7Zz4vo/ueDC30bBH3QX64jlzc5EZhPomEiCw0fa', '', 'Brian Bwire', 'admin', 1, NULL, '', 667699200, 'male', 'Kasubi', '+256706741084', NULL, NULL, NULL, '[]', '', '', '', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booklibrary`
--
ALTER TABLE `booklibrary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exammarks`
--
ALTER TABLE `exammarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examslist`
--
ALTER TABLE `examslist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gradelevels`
--
ALTER TABLE `gradelevels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messageslist`
--
ALTER TABLE `messageslist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsboard`
--
ALTER TABLE `newsboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentId`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `booklibrary`
--
ALTER TABLE `booklibrary`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exammarks`
--
ALTER TABLE `exammarks`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `examslist`
--
ALTER TABLE `examslist`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gradelevels`
--
ALTER TABLE `gradelevels`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messageslist`
--
ALTER TABLE `messageslist`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newsboard`
--
ALTER TABLE `newsboard`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `studentId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
