-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 14, 2017 at 01:53 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbschoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `id` int(250) NOT NULL,
  `classId` text NOT NULL,
  `subjectId` int(250) NOT NULL,
  `teacherId` int(250) NOT NULL,
  `AssignTitle` varchar(250) NOT NULL,
  `AssignDescription` text NOT NULL,
  `AssignFile` varchar(250) NOT NULL,
  `AssignDeadLine` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(250) NOT NULL,
  `classId` int(250) NOT NULL,
  `subjectId` int(250) NOT NULL,
  `date` varchar(250) NOT NULL,
  `studentId` int(250) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `booklibrary`
--

CREATE TABLE `booklibrary` (
  `id` int(250) NOT NULL,
  `bookName` varchar(250) NOT NULL,
  `bookDescription` text NOT NULL,
  `bookAuthor` varchar(250) NOT NULL,
  `bookType` varchar(20) NOT NULL,
  `bookPrice` varchar(250) DEFAULT NULL,
  `bookState` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `booklibrary`
--

INSERT INTO `booklibrary` (`id`, `bookName`, `bookDescription`, `bookAuthor`, `bookType`, `bookPrice`, `bookState`) VALUES
(1, 'Chemistry book', 'its a book', 'Mike', 'Option 1', '2000', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `classes`
--

CREATE TABLE `classes` (
  `id` int(250) NOT NULL,
  `className` varchar(250) NOT NULL,
  `classTeacher` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `classes`
--

INSERT INTO `classes` (`id`, `className`, `classTeacher`) VALUES
(11, 'S.1', 'Bwire Brian'),
(14, 'S.2', 'Mike Mutyaba'),
(15, 'S.3', 'B bria'),
(16, 'S.4', 'kk kk'),
(17, 'S.5', 'jj hh'),
(18, 'S.6', 'kk dd');

-- --------------------------------------------------------

--
-- Table structure for table `county`
--

CREATE TABLE `county` (
  `countyId` int(11) NOT NULL,
  `districtId` int(11) NOT NULL,
  `countyName` varchar(45) NOT NULL,
  `countyDescription` text NOT NULL,
  `Active` tinyint(4) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `county`
--

INSERT INTO `county` (`countyId`, `districtId`, `countyName`, `countyDescription`, `Active`) VALUES
(1, 1, 'Apach A ', 'This is the first county in Apach', 1),
(2, 1, 'Adoherr', 'This is the County', 1),
(4, 2, 'Samia', 'This is the samia ', 1),
(5, 3, 'Samisa', 'This is the samis County', 1),
(6, 3, 'Kole_North', 'Kole North County', 1);

-- --------------------------------------------------------

--
-- Table structure for table `district`
--

CREATE TABLE `district` (
  `districtId` int(11) NOT NULL,
  `districtName` varchar(50) NOT NULL,
  `districtDescription` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `district`
--

INSERT INTO `district` (`districtId`, `districtName`, `districtDescription`) VALUES
(1, 'Apac', 'This is a district located in Northern Uganda'),
(2, 'Oyam', 'This is the district located Oyam'),
(3, 'Kole', 'This is Kole District'),
(4, 'Kiryandongo', 'Kiryandoongo District'),
(7, 'Nakasongola', 'nakasongola district');

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `divisionId` int(11) NOT NULL,
  `minimumAggregate` int(11) NOT NULL,
  `maximumAggregate` int(11) NOT NULL,
  `division` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`divisionId`, `minimumAggregate`, `maximumAggregate`, `division`) VALUES
(1, 8, 32, '1'),
(2, 33, 45, '2'),
(3, 46, 58, '3'),
(4, 59, 68, '4'),
(5, 69, 72, '9');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(250) NOT NULL,
  `eventTitle` varchar(250) NOT NULL,
  `eventDescription` text,
  `eventFor` varchar(10) DEFAULT NULL,
  `enentPlace` varchar(250) DEFAULT NULL,
  `eventDate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exammarks`
--

CREATE TABLE `exammarks` (
  `id` int(250) NOT NULL,
  `examId` int(250) NOT NULL,
  `classId` int(250) NOT NULL,
  `subjectId` int(250) NOT NULL,
  `studentId` int(250) NOT NULL,
  `examMark` varchar(250) NOT NULL,
  `attendanceMark` varchar(250) NOT NULL,
  `markComments` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `examslist`
--

CREATE TABLE `examslist` (
  `id` int(250) NOT NULL,
  `examTitle` varchar(250) NOT NULL,
  `examDescription` text,
  `examDate` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gradelevels`
--

CREATE TABLE `gradelevels` (
  `id` int(250) NOT NULL,
  `gradeName` varchar(250) NOT NULL,
  `gradeDescription` text,
  `gradePoints` varchar(250) NOT NULL,
  `gradeFrom` varchar(250) NOT NULL,
  `gradeTo` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `gradeId` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `markFrom` int(11) NOT NULL,
  `markTo` int(11) NOT NULL,
  `comment` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`gradeId`, `grade`, `markFrom`, `markTo`, `comment`) VALUES
(1, 'D1', 80, 100, 'Excellent '),
(2, 'D2', 75, 79, 'Very Good'),
(3, 'C3', 66, 74, ''),
(4, 'C4', 60, 65, ''),
(5, 'C5', 55, 59, ''),
(6, 'C6', 50, 54, ''),
(7, 'P7', 45, 49, ''),
(8, 'P8', 35, 44, ''),
(9, 'F9', 0, 34, 'Pull up');

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `marksId` int(11) NOT NULL,
  `classId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `testExamType` varchar(20) NOT NULL,
  `studentNumber` varchar(20) NOT NULL,
  `studentMark` varchar(10) NOT NULL,
  `year` int(11) NOT NULL,
  `term` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`marksId`, `classId`, `subjectId`, `testExamType`, `studentNumber`, `studentMark`, `year`, `term`) VALUES
(1, 0, 1, 'EOT Test', '17/B001', '79', 2017, 'Term 1'),
(2, 0, 7, 'BOT Test', '17/B001', '70', 2017, 'Term 1'),
(3, 0, 7, 'BOT Test', '17/B002', '60', 2017, 'Term 1'),
(4, 0, 7, 'BOT Test', '17/G001', '68', 2017, 'Term 1'),
(5, 0, 1, 'BOT Test', '17/B001', '76', 2017, 'Term 1'),
(6, 11, 1, 'BOT Exam', '17/B001', '20', 2017, 'Term 1'),
(7, 0, 1, 'EOT Exam', '17/B001', '75', 2017, 'Term 1'),
(8, 0, 7, 'BOT Exam', '17/B001', '70', 2017, 'Term 1'),
(9, 0, 7, 'EOT Test', '17/B001', '69', 2017, 'Term 1'),
(10, 0, 7, 'EOT Exam', '17/B001', '60', 2017, 'Term 1'),
(11, 0, 4, 'BOT Test', '17/B001', '80', 2017, 'Term 1'),
(12, 0, 4, 'BOT Exam', '17/B001', '74', 2017, 'Term 1'),
(13, 0, 4, 'EOT Test', '17/B001', '54', 2017, 'Term 1'),
(14, 0, 4, 'EOT Exam', '17/B001', '85', 2017, 'Term 1'),
(15, 0, 9, 'BOT Test', '17/B001', '23', 2017, 'Term 1'),
(16, 0, 9, 'BOT Exam', '17/B001', '66', 2017, 'Term 1'),
(17, 0, 9, 'EOT Test', '17/B001', '50', 2017, 'Term 1'),
(18, 0, 9, 'EOT Exam', '17/B001', '52', 2017, 'Term 1'),
(19, 0, 10, 'BOT Test', '17/B001', '55', 2017, 'Term 1'),
(20, 0, 10, 'BOT Exam', '17/B001', '79', 2017, 'Term 1'),
(21, 0, 10, 'EOT Test', '17/B001', '80', 2017, 'Term 1'),
(22, 0, 10, 'EOT Exam', '17/B001', '92', 2017, 'Term 1'),
(23, 0, 11, 'BOT Test', '17/B001', '56', 2017, 'Term 1'),
(24, 0, 11, 'BOT Exam', '17/B001', '40', 2017, 'Term 1'),
(25, 0, 11, 'EOT Test', '17/B001', '50', 2017, 'Term 1'),
(26, 0, 11, 'EOT Exam', '17/B001', '53', 2017, 'Term 1'),
(27, 0, 12, 'BOT Test', '17/B001', '79', 2017, 'Term 1'),
(28, 0, 12, 'BOT Exam', '17/B001', '90', 2017, 'Term 1'),
(29, 0, 12, 'EOT Test', '17/B001', '83', 2017, 'Term 1'),
(30, 0, 12, 'EOT Exam', '17/B001', '81', 2017, 'Term 1'),
(31, 0, 13, 'BOT Test', '17/B001', '50', 2017, 'Term 1'),
(32, 0, 13, 'BOT Exam', '17/B001', '50', 2017, 'Term 1'),
(33, 0, 13, 'EOT Test', '17/B001', '50', 2017, 'Term 1'),
(34, 0, 13, 'EOT Exam', '17/B001', '52', 2017, 'Term 1'),
(35, 0, 14, 'BOT Test', '17/B001', '70', 2017, 'Term 1'),
(36, 0, 14, 'BOT Test', '17/B001', '65', 2017, 'Term 1'),
(37, 0, 14, 'BOT Exam', '17/B001', '80', 2017, 'Term 1'),
(38, 0, 14, 'EOT Test', '17/B001', '75', 2017, 'Term 1'),
(39, 0, 14, 'EOT Exam', '17/B001', '50', 2017, 'Term 1'),
(40, 0, 15, 'BOT Test', '17/B001', '81', 2017, 'Term 1'),
(41, 0, 15, 'BOT Exam', '17/B001', '68', 2017, 'Term 1'),
(42, 0, 15, 'EOT Test', '17/B001', '77', 2017, 'Term 1'),
(43, 0, 15, 'EOT Exam', '17/B001', '80', 2017, 'Term 1'),
(44, 0, 16, 'BOT Test', '17/B001', '60', 2017, 'Term 1'),
(45, 0, 16, 'BOT Exam', '17/B001', '62', 2017, 'Term 1'),
(46, 0, 16, 'EOT Test', '17/B001', '70', 2017, 'Term 1'),
(47, 11, 16, 'EOT Exam', '17/B001', '60', 2017, 'Term 1');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(250) NOT NULL,
  `messageId` int(250) NOT NULL,
  `userId` int(250) NOT NULL,
  `fromId` int(250) NOT NULL,
  `toId` int(250) NOT NULL,
  `messageText` text NOT NULL,
  `dateSent` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `messageslist`
--

CREATE TABLE `messageslist` (
  `id` int(250) NOT NULL,
  `userId` int(250) NOT NULL,
  `toId` int(250) NOT NULL,
  `lastMessage` varchar(250) NOT NULL,
  `lastMessageDate` varchar(250) NOT NULL,
  `messageStatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `newsboard`
--

CREATE TABLE `newsboard` (
  `id` int(250) NOT NULL,
  `newsTitle` varchar(250) NOT NULL,
  `newsText` text NOT NULL,
  `newsFor` varchar(250) NOT NULL,
  `newsDate` int(250) NOT NULL,
  `creationDate` int(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(10) NOT NULL,
  `siteTitle` varchar(250) NOT NULL,
  `siteSlogan` text NOT NULL,
  `systemEmail` varchar(50) NOT NULL,
  `systemPhone` varchar(30) NOT NULL,
  `latestVersion` varchar(20) NOT NULL,
  `footerText` text NOT NULL,
  `siteLogo` text NOT NULL,
  `lastUpdated` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `siteTitle`, `siteSlogan`, `systemEmail`, `systemPhone`, `latestVersion`, `footerText`, `siteLogo`, `lastUpdated`) VALUES
(1, 'School Manager', 'Knowledge for Prosperity', 'bbwire73@yahoo.com', '+256706741084', '0.1', 'Â© 2017 School Managerâ„¢. All Rights Reserved', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `studentId` int(11) NOT NULL,
  `studyLevel` varchar(10) NOT NULL,
  `serialNumber` varchar(20) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `class` varchar(20) NOT NULL,
  `stream` varchar(30) NOT NULL,
  `studentNumber` varchar(40) NOT NULL,
  `aggregate` int(11) NOT NULL,
  `dateOfBirth` varchar(20) NOT NULL,
  `religion` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL,
  `parent` varchar(50) NOT NULL,
  `contact` varchar(20) NOT NULL,
  `district` varchar(100) NOT NULL,
  `county` varchar(50) NOT NULL,
  `receiptNumber` varchar(10) NOT NULL,
  `combination` varchar(100) NOT NULL,
  `photo` text NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`studentId`, `studyLevel`, `serialNumber`, `fname`, `lname`, `gender`, `class`, `stream`, `studentNumber`, `aggregate`, `dateOfBirth`, `religion`, `status`, `parent`, `contact`, `district`, `county`, `receiptNumber`, `combination`, `photo`, `date`) VALUES
(1, 'O Level', '', 'Brian', 'Bwire', 'Male', '11', 'South', '17/B001', 10, '1999-02-01', 'Catholic', '', 'Mike', '0706741084', '1', '1', '003', 'Pass', 'uploads/photo.jpg', '2017-01-27'),
(2, 'O Level', '', 'Okello', 'Walter', 'Male', '11', 'North', '17/B002', 16, '2006-02-01', 'Catholic', '', 'Mike', '0706741084', '1', '2', '098', '', '', '2017-02-07'),
(3, 'A Level', '', 'Opio', 'Wilfred', 'Male', '17', 'A', 'A/17/B001', 23, '1999-01-04', 'Catholic', '', 'Peter', '0706741084', '1', '1', '0098', 'HED', '', '2017-02-07'),
(4, 'O Level', '', 'Helen', 'Namutosi', 'Female', '11', 'North', '17/G001', 16, '2006-02-01', 'Catholic', '', 'Bwire', '0706741084', '1', '1', '003', '', '', '2017-02-07');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE `subject` (
  `id` int(250) NOT NULL,
  `subjectTitle` varchar(250) NOT NULL,
  `subjectDescription` text NOT NULL,
  `subjectType` varchar(30) NOT NULL,
  `subjectLevel` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subjectTitle`, `subjectDescription`, `subjectType`, `subjectLevel`) VALUES
(1, 'Mathematics', 'calculations', 'Core', 'O Level'),
(4, 'Biology', 'science', 'Sciences', 'O Level'),
(7, 'English Language', 'Mike Mutebi', 'Core', 'O Level'),
(9, 'Geography', 'Mutyaba Arnold', 'Humanities', 'O Level'),
(10, 'Agriculture', 'Mike Muyizi', 'Sciences', 'O Level'),
(11, 'C.R.E', 'Mutyaba Arnold', 'Humanities', 'O Level'),
(12, 'Commerce', 'Brandon Bwire', 'Humanities', 'O Level'),
(13, 'History', 'Brian Bwire', 'Humanities', 'O Level'),
(14, 'Chemistry', 'Peter Sifudu', 'Sciences', 'O Level'),
(15, 'Physics', 'Micheal Sowed', 'Sciences', 'O Level'),
(16, 'Fine Art', 'Mina', 'Humanities', 'O Level'),
(17, 'Literature in English', 'lit', 'Humanities', 'O Level'),
(18, 'IRE', 'ire', 'Humanities', 'O Level'),
(19, 'Entrepreneurship', 'ent', 'Humanities', 'O Level'),
(20, 'Computer', 'comp', 'Humanities', 'O Level');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userid` int(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(100) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `role` varchar(10) NOT NULL,
  `activated` int(1) NOT NULL DEFAULT '1',
  `birthday` varchar(20) NOT NULL DEFAULT '0',
  `gender` varchar(10) DEFAULT NULL,
  `address` text,
  `phoneNo` varchar(250) DEFAULT NULL,
  `photo` varchar(250) DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userid`, `username`, `email`, `password`, `fname`, `lname`, `role`, `activated`, `birthday`, `gender`, `address`, `phoneNo`, `photo`) VALUES
(3, 'walter', 'walterok@gmail.com', '841d93525b9f0960ceaf38f4fdf22e2e', 'Walter', 'Okello', 'admin', 1, '1999-01-18', 'Male', 'Apac', '706525830', ''),
(2, 'petrine', 'sifudu@gmail.com', 'c4333de80bc6c0df105d2f64a063fd45', 'Sifudu', 'Peter', 'finance', 1, '1999-02-04', 'Male', 'Lira', '+256706525830', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booklibrary`
--
ALTER TABLE `booklibrary`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `classes`
--
ALTER TABLE `classes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `county`
--
ALTER TABLE `county`
  ADD PRIMARY KEY (`countyId`);

--
-- Indexes for table `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`districtId`);

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`divisionId`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exammarks`
--
ALTER TABLE `exammarks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `examslist`
--
ALTER TABLE `examslist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gradelevels`
--
ALTER TABLE `gradelevels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`gradeId`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`marksId`),
  ADD KEY `studentNumber` (`studentNumber`),
  ADD KEY `classId` (`classId`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messageslist`
--
ALTER TABLE `messageslist`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsboard`
--
ALTER TABLE `newsboard`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`studentId`);

--
-- Indexes for table `subject`
--
ALTER TABLE `subject`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userid`),
  ADD KEY `id` (`userid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `booklibrary`
--
ALTER TABLE `booklibrary`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `classes`
--
ALTER TABLE `classes`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `county`
--
ALTER TABLE `county`
  MODIFY `countyId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `district`
--
ALTER TABLE `district`
  MODIFY `districtId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `divisionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exammarks`
--
ALTER TABLE `exammarks`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `examslist`
--
ALTER TABLE `examslist`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gradelevels`
--
ALTER TABLE `gradelevels`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `gradeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `marksId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `messageslist`
--
ALTER TABLE `messageslist`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `newsboard`
--
ALTER TABLE `newsboard`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `studentId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `subject`
--
ALTER TABLE `subject`
  MODIFY `id` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userid` int(250) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
