-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2017 at 03:47 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbschoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `alevelgrades`
--

CREATE TABLE `alevelgrades` (
  `gradeId` int(11) NOT NULL,
  `bestPaper` varchar(5) NOT NULL,
  `secondBestPaper` varchar(5) NOT NULL,
  `thirdBestPaper` varchar(5) NOT NULL,
  `paperType` varchar(15) NOT NULL,
  `grade` varchar(2) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `comment` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `alevelgrades`
--

INSERT INTO `alevelgrades` (`gradeId`, `bestPaper`, `secondBestPaper`, `thirdBestPaper`, `paperType`, `grade`, `points`, `comment`) VALUES
(1, '1', 'n/a', 'n/a', 'single', 'A', 6, 'Excelent'),
(2, '2', 'n/a', 'n/a', 'single', 'A', 6, 'Fantastic'),
(3, '3', 'n/a', 'n/a', 'single', 'B', 5, 'Very good'),
(4, '4', 'n/a', 'n/a', 'single', 'C', 4, 'Great'),
(5, '5', 'n/a', 'n/a', 'single', 'D', 3, 'Good'),
(6, '6', 'n/a', 'n/a', 'single', 'E', 2, 'Fair'),
(7, '7', 'n/a', 'n/a', 'single', 'O', 1, 'Fair'),
(8, '8', 'n/a', 'n/a', 'single', 'F', 0, 'poor'),
(9, '9', 'n/a', 'n/a', 'single', 'F', 0, 'very poor'),
(10, '1', '1', 'n/a', 'double', 'A', 6, 'Excelent'),
(11, '1', '2', 'n/a', 'double', 'A', 6, 'Fantastic'),
(12, '1', '3', 'n/a', 'double', 'B', 5, 'Great'),
(13, '1', '4', 'n/a', 'double', 'C', 4, 'Good'),
(14, '1', '5', 'n/a', 'double', 'D', 3, 'Good'),
(15, '1', '6', 'n/a', 'double', 'E', 2, 'Fair'),
(16, '1', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(17, '1', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(18, '1', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(19, '2', '2', 'n/a', 'double', 'A', 6, 'Excelent'),
(20, '2', '3', 'n/a', 'double', 'B', 5, 'Fantastic'),
(21, '2', '4', 'n/a', 'double', 'C', 4, 'Great'),
(22, '2', '5', 'n/a', 'double', 'D', 3, 'Good '),
(23, '2', '6', 'n/a', 'double', 'E', 2, 'Fair'),
(24, '2', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(25, '2', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(26, '2', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(27, '3', '3', 'n/a', 'double', 'B', 5, 'Great'),
(28, '3', '4', 'n/a', 'double', 'C', 4, 'Good Work'),
(29, '3', '5', 'n/a', 'double', 'D', 3, 'Good'),
(30, '3', '6', 'n/a', 'double', 'E', 2, 'Fair'),
(31, '3', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(32, '3', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(33, '3', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(34, '4', '4', 'n/a', 'double', 'C', 4, 'Good Work'),
(35, '4', '5', 'n/a', 'double', 'D', 3, 'Good'),
(36, '4', '6', 'n/a', 'double', 'E', 2, 'Fair'),
(37, '4', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(38, '4', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(39, '4', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(40, '5', '5', 'n/a', 'double', 'D', 3, 'Good'),
(41, '5', '6', 'n/a', 'double', 'E', 2, 'Fair'),
(42, '5', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(43, '5', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(44, '5', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(45, '6', '6', 'n/a', 'double', 'E', 2, 'Fair'),
(46, '6', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(47, '6', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(48, '6', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(49, '7', '7', 'n/a', 'double', 'O', 1, 'Fair'),
(50, '7', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(51, '7', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(52, '8', '8', 'n/a', 'double', 'F', 0, 'Poor'),
(53, '8', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(54, '9', '9', 'n/a', 'double', 'F', 0, 'Very Poor'),
(55, '1', '1', '1', 'triple', 'A', 6, 'Excelent'),
(56, '1', '1', '2', 'triple', 'A', 6, 'Fantastic'),
(57, '1', '1', '3', 'triple', 'B', 5, 'Great'),
(58, '1', '1', '4', 'triple', 'C', 4, 'Good Work'),
(59, '1', '1', '5', 'triple', 'D', 3, 'Good'),
(60, '1', '1', '6', 'triple', 'E', 2, 'Fair'),
(61, '1', '1', '7', 'triple', 'O', 1, 'Fair'),
(62, '1', '1', '8', 'triple', 'O', 1, 'Fair'),
(63, '1', '1', '9', 'triple', 'F', 0, 'Poor'),
(64, '1', '2', '2', 'triple', 'A', 6, 'Great Work'),
(65, '1', '2', '3', 'triple', 'B', 5, 'Great'),
(66, '1', '2', '4', 'triple', 'C', 4, 'Good Work'),
(67, '1', '2', '5', 'triple', 'D', 3, 'Good'),
(68, '1', '2', '6', 'triple', 'D', 3, 'Good'),
(69, '1', '2', '7', 'triple', 'E', 2, 'Fair'),
(70, '1', '2', '8', 'triple', 'E', 2, 'Fair'),
(71, '1', '2', '9', 'triple', 'O', 1, 'Fair'),
(72, '1', '3', '3', 'triple', 'B', 5, 'Great Work'),
(73, '1', '3', '4', 'triple', 'B', 5, 'Great'),
(74, '1', '3', '5', 'triple', 'C', 4, 'Good Work'),
(75, '1', '3', '6', 'triple', 'D', 3, 'Good'),
(76, '1', '3', '7', 'triple', 'E', 2, 'Fair'),
(77, '1', '3', '8', 'triple', 'E', 2, 'Fair'),
(78, '1', '3', '9', 'triple', 'O', 1, 'Fair'),
(79, '1', '4', '4', 'triple', 'C', 4, 'Good Work'),
(80, '1', '4', '5', 'triple', 'C', 4, 'Good'),
(81, '1', '4', '6', 'triple', 'D', 3, 'Good'),
(82, '1', '4', '7', 'triple', 'E', 2, 'Fair'),
(83, '1', '4', '8', 'triple', 'E', 2, 'Fair'),
(84, '1', '4', '9', 'triple', 'O', 1, 'Fair'),
(85, '1', '5', '5', 'triple', 'D', 3, 'Good Work'),
(86, '1', '5', '6', 'triple', 'D', 3, 'Good'),
(87, '1', '5', '7', 'triple', 'E', 2, 'Fair'),
(88, '1', '5', '8', 'triple', 'E', 2, 'Fair'),
(89, '1', '5', '9', 'triple', 'O', 1, 'Fair'),
(90, '1', '6', '6', 'triple', 'E', 2, 'Fair'),
(91, '1', '6', '7', 'triple', 'E', 2, 'Fair'),
(92, '1', '6', '8', 'triple', 'E', 2, 'Fair'),
(93, '1', '6', '9', 'triple', 'O', 1, 'Fair'),
(94, '1', '7', '7', 'triple', 'O', 1, 'Fair'),
(95, '1', '7', '8', 'triple', 'O', 1, 'Fair'),
(96, '1', '7', '9', 'triple', 'O', 1, 'Fair'),
(97, '1', '8', '8', 'triple', 'O', 1, 'Fair'),
(98, '1', '8', '9', 'triple', 'F', 0, 'Poor'),
(99, '1', '9', '9', 'triple', 'F', 0, 'Very Poor'),
(100, '2', '2', '2', 'triple', 'A', 6, 'Excelent'),
(101, '2', '2', '3', 'triple', 'A', 6, 'Fantastic'),
(102, '2', '2', '4', 'triple', 'B', 5, 'Great Work'),
(103, '2', '2', '5', 'triple', 'C', 4, 'Good Work'),
(104, '2', '2', '6', 'triple', 'D', 3, 'Good'),
(105, '2', '2', '7', 'triple', 'E', 2, 'Fair'),
(106, '2', '2', '8', 'triple', 'E', 2, 'Fair'),
(107, '2', '2', '9', 'triple', 'O', 1, 'Fair'),
(108, '2', '3', '3', 'triple', 'B', 5, 'Excelent'),
(109, '2', '3', '4', 'triple', 'B', 5, 'Great Work'),
(110, '2', '3', '5', 'triple', 'C', 4, 'Good Work'),
(111, '2', '3', '6', 'triple', 'D', 3, 'Good'),
(112, '2', '3', '7', 'triple', 'E', 2, 'Good'),
(113, '2', '3', '8', 'triple', 'E', 2, 'Fair'),
(114, '2', '3', '9', 'triple', 'O', 1, 'Fair'),
(115, '2', '4', '4', 'triple', 'C', 4, 'Great'),
(116, '2', '4', '5', 'triple', 'C', 4, 'Good Work'),
(117, '2', '4', '6', 'triple', 'D', 3, 'Good'),
(118, '2', '4', '7', 'triple', 'E', 2, 'Good'),
(119, '2', '4', '8', 'triple', 'E', 2, 'Fair'),
(120, '2', '4', '9', 'triple', 'O', 1, 'Fair'),
(121, '2', '5', '5', 'triple', 'D', 3, 'Good'),
(122, '2', '5', '6', 'triple', 'D', 3, 'Good'),
(123, '2', '5', '7', 'triple', 'E', 2, 'Fair'),
(124, '2', '5', '8', 'triple', 'E', 2, 'Fair'),
(125, '2', '5', '9', 'triple', 'O', 1, 'Fair'),
(126, '2', '6', '6', 'triple', 'E', 2, 'Fair'),
(127, '2', '6', '7', 'triple', 'E', 2, 'Fair'),
(128, '2', '6', '8', 'triple', 'E', 2, 'Fair'),
(129, '2', '6', '9', 'triple', 'O', 1, 'Fair'),
(130, '2', '7', '7', 'triple', 'O', 1, 'Fair'),
(131, '2', '7', '8', 'triple', 'O', 1, 'Fair'),
(132, '2', '7', '9', 'triple', 'O', 1, 'Fair'),
(133, '2', '8', '8', 'triple', 'O', 1, 'Fair'),
(134, '2', '8', '9', 'triple', 'F', 0, 'Poor'),
(135, '2', '9', '9', 'triple', 'F', 0, 'Very Poor'),
(136, '3', '3', '3', 'triple', 'B', 5, 'Great Work');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alevelgrades`
--
ALTER TABLE `alevelgrades`
  ADD PRIMARY KEY (`gradeId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alevelgrades`
--
ALTER TABLE `alevelgrades`
  MODIFY `gradeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=137;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
