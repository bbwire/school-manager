-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2017 at 01:42 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbschoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

CREATE TABLE `divisions` (
  `divisionId` int(11) NOT NULL,
  `minimumAggregate` int(11) NOT NULL,
  `maximumAggregate` int(11) NOT NULL,
  `division` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`divisionId`, `minimumAggregate`, `maximumAggregate`, `division`) VALUES
(1, 8, 32, '1'),
(2, 33, 45, '2'),
(3, 46, 58, '3'),
(4, 59, 68, '4'),
(5, 69, 72, '9');

-- --------------------------------------------------------

--
-- Table structure for table `grades`
--

CREATE TABLE `grades` (
  `gradeId` int(11) NOT NULL,
  `grade` varchar(5) NOT NULL,
  `markFrom` int(11) NOT NULL,
  `markTo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `grades`
--

INSERT INTO `grades` (`gradeId`, `grade`, `markFrom`, `markTo`) VALUES
(1, 'D1', 80, 100),
(2, 'D2', 75, 79),
(3, 'C3', 66, 74),
(4, 'C4', 60, 65),
(5, 'C5', 55, 59),
(6, 'C6', 50, 54),
(7, 'P7', 45, 49),
(8, 'P8', 35, 44),
(9, 'F9', 0, 34);

-- --------------------------------------------------------

--
-- Table structure for table `marks`
--

CREATE TABLE `marks` (
  `marksId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `testExamType` varchar(20) NOT NULL,
  `studentNumber` varchar(20) NOT NULL,
  `studentMark` varchar(10) NOT NULL,
  `year` int(11) NOT NULL,
  `term` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `marks`
--

INSERT INTO `marks` (`marksId`, `subjectId`, `testExamType`, `studentNumber`, `studentMark`, `year`, `term`) VALUES
(1, 1, 'EOT Test', '17/B001', '79', 2017, 'Term 1'),
(2, 7, 'BOT Test', '17/B001', '70', 2017, 'Term 1'),
(3, 7, 'BOT Test', '17/B002', '60', 2017, 'Term 1'),
(4, 7, 'BOT Test', '17/G001', '68', 2017, 'Term 1'),
(5, 1, 'BOT Test', '17/B001', '76', 2017, 'Term 1'),
(6, 1, 'BOT Exam', '17/B001', '70', 2017, 'Term 1'),
(7, 1, 'EOT Exam', '17/B001', '75', 2017, 'Term 1'),
(8, 7, 'BOT Exam', '17/B001', '70', 2017, 'Term 1'),
(9, 7, 'EOT Test', '17/B001', '69', 2017, 'Term 1'),
(10, 7, 'EOT Exam', '17/B001', '60', 2017, 'Term 1'),
(11, 4, 'BOT Test', '17/B001', '80', 2017, 'Term 1'),
(12, 4, 'BOT Exam', '17/B001', '74', 2017, 'Term 1'),
(13, 4, 'EOT Test', '17/B001', '54', 2017, 'Term 1'),
(14, 4, 'EOT Exam', '17/B001', '85', 2017, 'Term 1'),
(15, 9, 'BOT Test', '17/B001', '23', 2017, 'Term 1'),
(16, 9, 'BOT Exam', '17/B001', '66', 2017, 'Term 1'),
(17, 9, 'EOT Test', '17/B001', '50', 2017, 'Term 1'),
(18, 9, 'EOT Exam', '17/B001', '52', 2017, 'Term 1'),
(19, 10, 'BOT Test', '17/B001', '55', 2017, 'Term 1'),
(20, 10, 'BOT Exam', '17/B001', '79', 2017, 'Term 1'),
(21, 10, 'EOT Test', '17/B001', '80', 2017, 'Term 1'),
(22, 10, 'EOT Exam', '17/B001', '92', 2017, 'Term 1'),
(23, 11, 'BOT Test', '17/B001', '56', 2017, 'Term 1'),
(24, 11, 'BOT Exam', '17/B001', '40', 2017, 'Term 1'),
(25, 11, 'EOT Test', '17/B001', '50', 2017, 'Term 1'),
(26, 11, 'EOT Exam', '17/B001', '53', 2017, 'Term 1'),
(27, 12, 'BOT Test', '17/B001', '79', 2017, 'Term 1'),
(28, 12, 'BOT Exam', '17/B001', '90', 2017, 'Term 1'),
(29, 12, 'EOT Test', '17/B001', '83', 2017, 'Term 1'),
(30, 12, 'EOT Exam', '17/B001', '81', 2017, 'Term 1'),
(31, 13, 'BOT Test', '17/B001', '50', 2017, 'Term 1'),
(32, 13, 'BOT Exam', '17/B001', '50', 2017, 'Term 1'),
(33, 13, 'EOT Test', '17/B001', '50', 2017, 'Term 1'),
(34, 13, 'EOT Exam', '17/B001', '52', 2017, 'Term 1'),
(35, 14, 'BOT Test', '17/B001', '70', 2017, 'Term 1'),
(36, 14, 'BOT Test', '17/B001', '65', 2017, 'Term 1'),
(37, 14, 'BOT Exam', '17/B001', '80', 2017, 'Term 1'),
(38, 14, 'EOT Test', '17/B001', '75', 2017, 'Term 1'),
(39, 14, 'EOT Exam', '17/B001', '50', 2017, 'Term 1'),
(40, 15, 'BOT Test', '17/B001', '81', 2017, 'Term 1'),
(41, 15, 'BOT Exam', '17/B001', '68', 2017, 'Term 1'),
(42, 15, 'EOT Test', '17/B001', '77', 2017, 'Term 1'),
(43, 15, 'EOT Exam', '17/B001', '80', 2017, 'Term 1'),
(44, 16, 'BOT Test', '17/B001', '60', 2017, 'Term 1'),
(45, 16, 'BOT Exam', '17/B001', '62', 2017, 'Term 1'),
(46, 16, 'EOT Test', '17/B001', '70', 2017, 'Term 1'),
(47, 16, 'EOT Exam', '17/B001', '60', 2017, 'Term 1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `divisions`
--
ALTER TABLE `divisions`
  ADD PRIMARY KEY (`divisionId`);

--
-- Indexes for table `grades`
--
ALTER TABLE `grades`
  ADD PRIMARY KEY (`gradeId`);

--
-- Indexes for table `marks`
--
ALTER TABLE `marks`
  ADD PRIMARY KEY (`marksId`),
  ADD KEY `studentNumber` (`studentNumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `divisions`
--
ALTER TABLE `divisions`
  MODIFY `divisionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `grades`
--
ALTER TABLE `grades`
  MODIFY `gradeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `marks`
--
ALTER TABLE `marks`
  MODIFY `marksId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
