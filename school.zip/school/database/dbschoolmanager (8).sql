-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 04, 2017 at 01:53 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbschoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `alevelgrades`
--

CREATE TABLE `alevelgrades` (
  `gradeId` int(11) NOT NULL,
  `grade` varchar(2) NOT NULL,
  `points` int(11) NOT NULL DEFAULT '0',
  `markFrom` varchar(5) NOT NULL,
  `markTo` varchar(5) NOT NULL,
  `comment` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `alevelgrades`
--

INSERT INTO `alevelgrades` (`gradeId`, `grade`, `points`, `markFrom`, `markTo`, `comment`) VALUES
(1, 'A', 6, '1', '2.5', 'Excelent'),
(2, 'B', 5, '2.6', '3.5', 'Fantastic'),
(3, 'C', 4, '3.6', '4.5', 'Very good'),
(4, 'D', 3, '4.6', '5.5', 'Great'),
(5, 'E', 2, '5.6', '6.5', 'Good'),
(6, 'O', 1, '6.6', '8', 'Fair'),
(7, 'F', 0, '8', '9', 'Poor');

-- --------------------------------------------------------

--
-- Table structure for table `amarks`
--

CREATE TABLE `amarks` (
  `marksId` int(11) NOT NULL,
  `classId` int(11) NOT NULL,
  `subjectId` int(11) NOT NULL,
  `testExamType` varchar(20) NOT NULL,
  `studentNumber` varchar(15) NOT NULL,
  `studentMark` int(11) NOT NULL,
  `year` varchar(5) NOT NULL,
  `term` varchar(10) NOT NULL,
  `mtype` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `amarks`
--

INSERT INTO `amarks` (`marksId`, `classId`, `subjectId`, `testExamType`, `studentNumber`, `studentMark`, `year`, `term`, `mtype`) VALUES
(1, 17, 21, 'BOT Test', 'A/17/B001', 80, '2017', 'Term 1', 'subject'),
(2, 17, 21, 'BOT Exam', 'A/17/B001', 76, '2017', 'Term 1', 'subject'),
(3, 17, 21, 'EOT Test', 'A/17/B001', 50, '2017', 'Term 1', 'subject'),
(4, 17, 21, 'EOT Exam', 'A/17/B001', 60, '2017', 'Term 1', 'subject'),
(5, 17, 1, 'BOT Test', 'A/17/B001', 77, '2017', 'Term 1', 'paper'),
(6, 17, 1, 'BOT Exam', 'A/17/B001', 76, '2017', 'Term 1', 'paper'),
(7, 17, 1, 'EOT Test', 'A/17/B001', 66, '2017', 'Term 1', 'paper'),
(8, 17, 1, 'EOT Exam', 'A/17/B001', 85, '2017', 'Term 1', 'paper');

-- --------------------------------------------------------

--
-- Table structure for table `subjectpaper`
--

CREATE TABLE `subjectpaper` (
  `paperId` int(11) NOT NULL,
  `paperTitle` varchar(4) NOT NULL,
  `paperParent` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `subjectpaper`
--

INSERT INTO `subjectpaper` (`paperId`, `paperTitle`, `paperParent`) VALUES
(1, '1', 24),
(2, '2', 24);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `alevelgrades`
--
ALTER TABLE `alevelgrades`
  ADD PRIMARY KEY (`gradeId`);

--
-- Indexes for table `amarks`
--
ALTER TABLE `amarks`
  ADD PRIMARY KEY (`marksId`),
  ADD KEY `subjectId` (`subjectId`),
  ADD KEY `classId` (`classId`);

--
-- Indexes for table `subjectpaper`
--
ALTER TABLE `subjectpaper`
  ADD PRIMARY KEY (`paperId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `alevelgrades`
--
ALTER TABLE `alevelgrades`
  MODIFY `gradeId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `amarks`
--
ALTER TABLE `amarks`
  MODIFY `marksId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `subjectpaper`
--
ALTER TABLE `subjectpaper`
  MODIFY `paperId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
