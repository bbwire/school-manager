Update students table 

add:
1. district (in the place of residence)
2. county (just below district)

please import alevelgrades table (first drop the one u have)