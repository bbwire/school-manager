-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 01, 2017 at 11:12 AM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbschoolmanager`
--

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `siteTitle` varchar(250) NOT NULL,
  `siteSlogan` text NOT NULL,
  `systemEmail` varchar(50) NOT NULL,
  `systemPhone` varchar(30) NOT NULL,
  `latestVersion` varchar(20) NOT NULL,
  `footerText` text NOT NULL,
  `siteLogo` text NOT NULL,
  `lastUpdated` varchar(20) NOT NULL,
  `termBegin` varchar(30) NOT NULL,
  `termEnd` varchar(30) NOT NULL,
  `olevelBanner` text NOT NULL,
  `alevelBanner` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `siteTitle`, `siteSlogan`, `systemEmail`, `systemPhone`, `latestVersion`, `footerText`, `siteLogo`, `lastUpdated`, `termBegin`, `termEnd`, `olevelBanner`, `alevelBanner`) VALUES
(1, 'School Manager', 'Knowledge for Prosperity', 'info@kigumbaintensivesec.ac.ug', '+256392177217', '0.1', 'Â© 2017 School Managerâ„¢. All Rights Reserved', 'uploads/logo.png', '', '12 May 2017', '08 August 2017', 'uploads/olevel-banner.png', 'uploads/alevel-banner.png');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `id` int(250) NOT NULL AUTO_INCREMENT,
  `subjectTitle` varchar(250) NOT NULL,
  `subjectDescription` text NOT NULL,
  `subjectType` varchar(30) NOT NULL,
  `subjectLevel` varchar(10) NOT NULL,
  `subjectCode` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`id`, `subjectTitle`, `subjectDescription`, `subjectType`, `subjectLevel`, `subjectCode`) VALUES
(1, 'ENGLISH', 'SORROW CRISPO', 'Core', 'O Level', '112'),
(2, 'MATHEMATICS', 'WAISWA PATRICK', 'Core', 'O Level', '456'),
(5, 'BIOLOGY', 'OKETTA RICHARD', 'Sciences', 'O Level', '553'),
(6, 'AGRICULTURE', 'ODOCH JOEL ADAMS', 'Sciences', 'O Level', '527'),
(7, 'GEOGRAPHY', 'MUGANZI MARK', 'Humanities', 'O Level', '273'),
(8, 'HISTORY', 'PARUKU RASHID', 'Humanities', 'O Level', '241'),
(9, 'CRE', 'ALUR GLORIA', 'Humanities', 'O Level', '223'),
(10, 'IRE', 'ELIAS JUMA', 'Humanities', 'O Level', '225'),
(11, 'COMMERCE', 'KATO NELSON', 'Humanities', 'O Level', '800'),
(12, 'LITERATURE', 'SORROW CRISPO', 'Humanities', 'O Level', '208'),
(13, 'COMPUTER STUDIES', 'ODONGO CEASER', 'Humanities', 'O Level', '840'),
(14, 'IPS', 'KASADHA BENARD', 'Humanities', 'O Level', '612'),
(15, 'GENERAL PAPER', 'ALIKAH KYAMANYWA', 'Subsidiary', 'A Level', ''),
(16, 'Subsidiary Mathematics', 'AKUGIZIBWE ALED', 'Subsidiary', 'A Level', ''),
(17, 'COMPUTER STUDIES', 'ODONGO CEASER', 'Subsidiary', 'A Level', ''),
(18, 'BIOLOGY', 'LWANGA PAUL', 'Principal', 'A Level', ''),
(19, 'HISTORY', 'TIBENDA GILBERT', 'Principal', 'A Level', ''),
(20, 'PRINCIPLES AND PRACTICES OF AGRICULTURE', 'ODOCH JOEL ADAMS', 'Principal', 'A Level', ''),
(21, 'PHYSICS', 'ENWOU PETER', 'Principal', 'A Level', ''),
(22, 'CHEMISTRY', 'BAKALI KAYANGA', 'Principal', 'A Level', ''),
(23, 'MATHEMATICS', 'AKUGIZIBWE ALED', 'Principal', 'A Level', ''),
(24, 'ECONOMICS', 'MURU PETER', 'Principal', 'A Level', ''),
(25, 'ENTREPRENEURSHIP', 'SSEMPIJJA MARK', 'Principal', 'A Level', ''),
(26, 'CHRISTIAN RELIGIOUS EDUCATION', 'ATAMA CAROLINE', 'Principal', 'A Level', ''),
(27, 'LITERATURE IN ENGLISH', 'SORROW CRISPO', 'Principal', 'A Level', ''),
(28, 'GEOGRAPHY', 'AYESIGA STEPHEN', 'Principal', 'A Level', ''),
(29, 'ART AND DESIGN', 'KASADHA BENARD', 'Principal', 'A Level', ''),
(30, 'PHYSICS', 'ERAC DENIS', 'Sciences', 'O Level', '535'),
(31, 'CHEMISTRY', 'ABITEGEKA JOHN BAPTIST', 'Sciences', 'O Level', '545');

-- --------------------------------------------------------

--
-- Table structure for table `subjectpaper`
--

CREATE TABLE IF NOT EXISTS `subjectpaper` (
  `paperId` int(11) NOT NULL AUTO_INCREMENT,
  `paperTitle` varchar(4) NOT NULL,
  `paperParent` int(11) NOT NULL,
  PRIMARY KEY (`paperId`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `subjectpaper`
--

INSERT INTO `subjectpaper` (`paperId`, `paperTitle`, `paperParent`) VALUES
(1, '1', 24),
(2, '2', 24),
(3, '1', 1),
(4, '2', 1),
(5, '1', 18),
(6, '2', 18),
(7, '3', 19),
(8, '5', 19),
(9, '1', 20),
(10, '2', 20),
(11, '1', 21),
(12, '2', 21),
(13, '1', 22),
(14, '2', 22),
(15, '1', 23),
(16, '2', 23),
(17, '1', 25),
(18, '2', 25),
(19, '3', 25),
(20, '1', 26),
(21, '2', 26),
(22, '3', 26),
(23, '4', 26),
(24, '1', 27),
(25, '2', 27),
(26, '3', 27),
(27, '1', 28),
(28, '2', 28),
(29, '3', 28),
(30, '1', 29),
(31, '2', 29),
(32, '3', 29),
(33, '4', 29);
