		<?php
		require_once ("inc/essentials.php");
		
		$class = "StudentsController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

		<?php
		foreach($settings as $setting):
			$termbegin = $setting->termBegin;
			$termend = $setting->termEnd;
			$olbanner = $setting->olevelBanner;
		endforeach;
		?>
        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12" style="float:none">
              <div class="x_panel">
                  <div class="x_title no-print">
                    <h2>Student Report </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					if(isset($_GET['student']) and isset($_GET['year']) and isset($_GET['term']) and isset($_GET['class'])){
						
						$gterm = $_GET['term'];
						$gyear = $_GET['year'];
						$class = $_GET['class'];
						
						$updateid = $_GET['student'];
						
						$query = "SELECT * FROM students st, classes cl WHERE st.class = cl.id and st.studentId = '". $updateid ."'";
						
						$updatedatas = $controller->getcustomdata($query);
						
						foreach($updatedatas as $data):
						
						?>
							<div class="no-print">
							<div class="col-lg-11">
								<span class="section"><?php echo $data->fname. ' ' .$data->lname;?>'s Report</span>
							</div>
							<div class="col-lg-1">
								<a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><span class="fa fa-long-arrow-left"></span> Return</a>
							</div>
							</div>
							<div class="clearfix"></div>
							<div class="banner-with-img" style="position:relative;">
								<img src="<?php echo $setting->olevelBanner;?>" class="img-responsive">
								
								<?php
								$img = "images/user.png";
								
								if($data->photo != '')
								{
									$img = $data->photo;
								}
								?>
								
								<div class="profile-pic" style="">
									<img src="<?php echo $img;?>" class="img-responsive">
								</div>
							</div>
							<br>
							<table class="table-no-borders">
								<tr>
									<td> <?php echo $data->fname. ' ' .$data->lname;?></td>
									<td style="width:49%"></td>
									<td><b>Admission Number:</b> <?php echo $data->studentNumber;?></td>
									<td></td>
								</tr>
							</table>
							<table class="table-no-borders">
								
								<tr>
									<td><b>Class:</b> <?php echo $data->className. ' ' .$data->stream;?></td>
									<td></td>
									<td></td>
									<td></td>
									<td><b>Year:</b> <?php echo $gyear;?></td>
									<td></td>
									<td><?php echo $gterm;?></td>
								</tr>
							</table>
							
							<table class="report-table report-card-olevo print">
								<thead>
								<tr>
									<td width='23%'>Subject</td>
									<td>MoT (30%)</td>
									<td>MoT (70%)</td>
									<td>EoT (30%)</td>
									<td>EoT (70%)</td>
									<!--<td>Total</td>-->
									<td>AVG</td>
									<td>Grade</td>
									<td width='40%'>Comments</td>
									<td>Initials</td>
								</tr>
								</thead>
								
								<?php
								$studentscounter = $controller->countStudents($data->class);
								$subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'O Level'");
								
								$store['performances'] = array();
								$subs['cores'] = array();
								
								$core = array();
								$performance = array();
								$ttlmrk = 0;
								$ttavrge = 0;
								$countavail = 0;
								foreach($subjectdatas as $subject):
									
									$bottest = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, '');
									$botexam = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, '');
									$eottest = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, '');
									$eotexam = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, '');
									
									if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
									{
										$average = '';
										$total = '';
									}
									elseif($bottest == '' and $botexam == '' and $eottest == '' and $eotexam != '')
									{
										$average = number_format(($eotexam*100)/70);
										$total = ($eotexam*100)/70;
										$countavail++;
									}
									elseif($bottest == '' and $botexam != '' and $eottest == '' and $eotexam != '')
									{
										$botexam = ($botexam*100)/70;
										$eotexam = ($eotexam*100)/70;
										$average = number_format(($eotexam+$botexam)/2);
										$total = ($eotexam+$botexam);
										$countavail++;
									}
									elseif($bottest != '' and $botexam != '' and $eottest == '' and $eotexam == '')
									{
										$average = number_format(($bottest+$botexam));
										$total = ($bottest+$botexam);
										$countavail++;
									}
									elseif($bottest == '' and $botexam == '' and $eottest != '' and $eotexam != '')
									{
										$average = number_format(($eottest+$eotexam));
										$total = ($eottest+$eotexam);
										$countavail++;
									}
									elseif($bottest != '' and $botexam != '' and $eottest == '' and $eotexam != '')
									{
										$botttl = ($bottest+$botexam);
										$eotttl = ($eotexam*100)/70;
										$average = number_format(($eotttl+$botttl)/2);
										$total = ($eotttl+$botttl);
										$countavail++;
									}
									elseif($bottest == '' and $botexam != '' and $eottest != '' and $eotexam != '')
									{
										$botttl = ($botexam*100)/70;
										$eotttl = ($eotexam+$eottest);
										$average = number_format(($eotttl+$botttl)/2);
										$total = ($eotttl+$botttl);
										$countavail++;
									}
									else
									{
										$average = number_format((($bottest+$botexam)+($eottest+$eotexam))/2);
										
										$total = (($bottest+$botexam)+($eottest+$eotexam));
										$countavail++;
									}
									
									if($average != '')
									{
										$grade = $controller->getGrade($average);
										$comment = $controller->getComment("grades", $average);
									}
									else
									{
										$grade = '';
										$comment = '';
									}
									
									$ttavrge = $ttavrge+$average;
									$ttlmrk = $ttlmrk+$total;
									
									$initials = $controller->getInitials($class, $subject->id);
									
									if($subject->subjectType != "Core")
									{
										if($grade != '')
										{
											$performance['subject'] = $subject->id;
											$performance['average'] = $average;
											$performance['grade'] = $grade;
											array_push($store['performances'], $performance);
										}
									}
									else
									{
										if($grade != '')
										{
											$core['subject'] = $subject->id;
											$core['average'] = $average;
											$core['grade'] = $grade;
											array_push($subs['cores'], $core);
										}
									}
									
									?>
									<tr>
										<td><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
										<td><?php echo $bottest;?></td>
										<td><?php echo $botexam;?></td>
										<td><?php echo $eottest;?></td>
										<td><?php echo $eotexam;?></td>
										<!--<td><?php echo $total;?></td>-->
										<td><?php echo $average;?></td>
										<td><?php echo $grade;?></td>
										<td><?php echo $comment;?></td>
										<td><?php echo $initials;?></td>
									</tr>
									<?php
									
									
									
								endforeach;
								?>
							</table>
							<?php
							
							$stored = $controller->getPerformance($store['performances'], $subs['cores']);
													
							foreach($stored as $performance):
							
							?>
							<?php //$posits = $posdata['positions'];?>
							<table class="table-borders">
								<tr>
									<td >Total Mark: <span class='blue'><?php echo $ttlmrk;?></span></td>
									<td >Average Mark: <span class='blue'><?php if($ttlmrk != 0){ echo number_format($ttlmrk/$countavail, 2);}else{ echo $ttlmrk;};?></span></td>
									<td>Aggregate in best 8: <span class='red'><?php echo $performance['aggregate'];?></span></td>
									<td>Division/Result: <span class='red'><?php echo $performance['result'];?></span></td>
								</tr>
							</table>
							<?php
							
							endforeach;
							?>
							
							<table class="report-table">
								<tr>
									<td>MARKS</td>
									<td>---</td>
									<td>0-34</td>
									<td>35-44</td>
									<td>45-54</td>
									<td>55-59</td>
									<td>60-64</td>
									<td>65-69</td>
									<td>70-74</td>
									<td>75-79</td>
									<td>80-100</td>
									<td>---</td>
								</tr>
								
								<tr>
									<td>GRADE</td>
									<td>---</td>
									<td>F9</td>
									<td>P8</td>
									<td>P7</td>
									<td>C6</td>
									<td>C5</td>
									<td>C4</td>
									<td>C3</td>
									<td>D2</td>
									<td>D1</td>
									<td>---</td>
								</tr>
							</table><br>
							
							
							<table class="table-no-borders">
								<tr>
									<td>Class teacher comments:</td>
									<td width="80%">......................................................................................................................................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-no-borders">
								<tr>
									<td width="60%"></td>
									<td>Signature:</td>
									<td>....................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-no-borders">
								<tr>
									<td>Head Teacher Comments:</td>
									<td width="80%">......................................................................................................................................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-no-borders">
								<tr>
									<td width="60%"></td>
									<td>Signature:</td>
									<td>....................................................................</td>
									
								</tr>
								
							</table>							
							
							<table class="table-borders-top-bottom">
								<tr>
									<td>Next Term Begins on </td>
									<td><?php echo $termbegin;?></td>
									<td>and ends on</td>
									<td><?php echo $termend;?></td>
									
								</tr>
								
							</table>
							
							
                        
                        <div class="clearfix"></div>
                        <button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Report</button>
                        <?php
						endforeach;
					}
					
					
					else if(isset($_GET['all']) and isset($_GET['year']) and isset($_GET['term']) and isset($_GET['class'])){
						
						$gterm = $_GET['term'];
						$gyear = $_GET['year'];
						$class = $_GET['class'];
						
						
						
						$all_students = "select * from students where class = '$class'";
						
						$studentdatas = $controller->getcustomdata($all_students);
						
						$all_stds_num = count($studentdatas);
						
						if($all_stds_num == 0){
							$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
							?>
							<div class="no-print">
							<hr>
							<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
							
							</div>
							<?php
							exit();
						}
						?>
                        <div class="no-print">
                        <button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Reports </button>
                        <hr>
                        </div>
                        <?php
						$countst = 0;
						
						$posdata['positions'] = array();
						$position = array();
						
						foreach($studentdatas as $stdata):
						
							?>
                            <div class="clearfix"></div>
                            <div class="page-break" id="page-break" style="page-break-after:always;">
                            <?php
						
							$stdidd = $stdata->studentId;
							
							$countst++;
							
							$query = "SELECT * FROM students st, classes cl WHERE st.class = cl.id and st.studentId = '". $stdidd ."'";
							
							$updatedatas = $controller->getcustomdata($query);
							
							foreach($updatedatas as $data):
							
							?>
							<div class="no-print">
							<div class="col-lg-11">
								<span class="section"><?php echo $data->fname. ' ' .$data->lname;?>'s Report</span>
							</div>
							<div class="col-lg-1">
								<a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><span class="fa fa-long-arrow-left"></span> Return</a>
							</div>
							</div>
							<div class="clearfix"></div>
							<div class="banner-with-img" style="position:relative;">
								<img src="<?php echo $setting->olevelBanner;?>" class="img-responsive">
								
								<?php
								$img = "images/user.png";
								
								if($data->photo != '')
								{
									$img = $data->photo;
								}
								?>
								
								<div class="profile-pic" style="">
									<img src="<?php echo $img;?>" class="img-responsive">
								</div>
							</div>
							<br>
							<table class="table-no-borders">
								<tr>
									<td>Name: <?php echo $data->fname. ' ' .$data->lname;?></td>
									<td style="width:49%"></td>
									<td>Admission Number: <?php echo $data->studentNumber;?></td>
									<td></td>
								</tr>
							</table>
							<table class="table-no-borders">
								
								<tr>
									<td>Class: <?php echo $data->className. ' ' .$data->stream;?></td>
									<td></td>
									<td>Year: <?php echo $gyear;?></td>
									<td></td>
									<td><?php echo $gterm;?></td>
								</tr>
							</table>
							<table class="report-table report-card-olevo print">
								<thead>
								<tr>
									<td width='23%'>Subject</td>
									<td>MoT (30%)</td>
									<td>MoT (70%)</td>
									<td>EoT (30%)</td>
									<td>EoT (70%)</td>
									<!--<td>Total</td>-->
									<td>AVG</td>
									<td>Grade</td>
									<td width='40%'>Comments</td>
									<td>Initials</td>
								</tr>
								</thead>
								<?php
								$subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'O Level'");
								
								$store['performances'] = array();
								$subs['cores'] = array();
								
								$core = array();
								$performance = array();
								$ttlmrk = 0;
								$ttavrge = 0;
								$countavail = 0;
								foreach($subjectdatas as $subject):
									
									$bottest = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, '');
									$botexam = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, '');
									$eottest = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, '');
									$eotexam = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, '');
									
									if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
									{
										$average = '';
										$total = '';
									}
									elseif($bottest == '' and $botexam == '' and $eottest == '' and $eotexam != '')
									{
										$average = number_format(($eotexam*100)/70);
										$total = ($eotexam*100)/70;
										$countavail++;
									}
									elseif($bottest == '' and $botexam != '' and $eottest == '' and $eotexam != '')
									{
										$botexam = ($botexam*100)/70;
										$eotexam = ($eotexam*100)/70;
										$average = number_format(($eotexam+$botexam)/2);
										$total = ($eotexam+$botexam);
										$countavail++;
									}
									elseif($bottest != '' and $botexam != '' and $eottest == '' and $eotexam == '')
									{
										$average = number_format(($bottest+$botexam));
										$total = ($bottest+$botexam);
										$countavail++;
									}
									elseif($bottest == '' and $botexam == '' and $eottest != '' and $eotexam != '')
									{
										$average = number_format(($eottest+$eotexam));
										$total = ($eottest+$eotexam);
										$countavail++;
									}
									elseif($bottest != '' and $botexam != '' and $eottest == '' and $eotexam != '')
									{
										$botttl = ($bottest+$botexam);
										$eotttl = ($eotexam*100)/70;
										$average = number_format(($eotttl+$botttl)/2);
										$total = ($eotttl+$botttl);
										$countavail++;
									}
									elseif($bottest == '' and $botexam != '' and $eottest != '' and $eotexam != '')
									{
										$botttl = ($botexam*100)/70;
										$eotttl = ($eotexam+$eottest);
										$average = number_format(($eotttl+$botttl)/2);
										$total = ($eotttl+$botttl);
										$countavail++;
									}
									else
									{
										$average = number_format((($bottest+$botexam)+($eottest+$eotexam))/2);
										
										$total = (($bottest+$botexam)+($eottest+$eotexam));
										$countavail++;
									}
									
									if($average != '')
									{
										$grade = $controller->getGrade($average);
										$comment = $controller->getComment("grades", $average);
									}
									else
									{
										$grade = '';
										$comment = '';
										$initials = '';
									}
									
									if($grade == ''){
										$initials = '';
									}
									else
									{
										$ttavrge = $ttavrge+$average;
										$ttlmrk = $ttlmrk+$total;
										
										$initials = $controller->getInitials($class, $subject->id);
									}
									
									if($subject->subjectType != "Core")
									{
										if($grade != '')
										{
											$performance['subject'] = $subject->id;
											$performance['average'] = $average;
											$performance['grade'] = $grade;
											array_push($store['performances'], $performance);
										}
									}
									else
									{
										if($grade != '')
										{
											$core['subject'] = $subject->id;
											$core['average'] = $average;
											$core['grade'] = $grade;
											array_push($subs['cores'], $core);
										}
									}
									
									?>
									<tr>
										<td><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
										<td><?php echo $bottest;?></td>
										<td><?php echo $botexam;?></td>
										<td><?php echo $eottest;?></td>
										<td><?php echo $eotexam;?></td>
										<!--<td><?php echo $total;?></td>-->
										<td><?php echo $average;?></td>
										<td><?php echo $grade;?></td>
										<td><?php echo $comment;?></td>
										<td><?php echo $initials;?></td>
									</tr>
									<?php
									
								endforeach;
								?>
							</table>
							
							<br>
							<?php
							
							$stored = $controller->getPerformance($store['performances'], $subs['cores']);
													
							foreach($stored as $performance):
							$avrgmrk = number_format($performance['averagemark'], 2);
							$position['avrgmrk'] = $avrgmrk;
							$position['student'] = $data->studentNumber;
							$position['result'] = $performance['result'];
							
							array_push($posdata['positions'], $position);
							?>
							
							<?php $posits = $posdata['positions'];?>
							<table class="table-borders">
								<tr>
									<td >Total Mark: <span class='blue'><?php echo $ttlmrk;?></span></td>
									<td >Average Mark: <span class='blue'><?php if($ttlmrk != 0){ echo number_format($ttlmrk/$countavail, 2);}else{ echo $ttlmrk;};?></span></td>
									<td>Aggregate in best 8: <span class='red'><?php echo $performance['aggregate'];?></span></td>
									<td>Division/Result: <span class='red'><?php echo $performance['result'];?></span></td>
								</tr>
							</table>
							<?php
							
							endforeach;
							?>
							
							<table class="report-table">
								<tr>
									<td>MARKS</td>
									<td>---</td>
									<td>0-34</td>
									<td>35-44</td>
									<td>45-54</td>
									<td>55-59</td>
									<td>60-64</td>
									<td>65-69</td>
									<td>70-74</td>
									<td>75-79</td>
									<td>80-100</td>
									<td>---</td>
								</tr>
								
								<tr>
									<td>GRADE</td>
									<td>---</td>
									<td>F9</td>
									<td>P8</td>
									<td>P7</td>
									<td>C6</td>
									<td>C5</td>
									<td>C4</td>
									<td>C3</td>
									<td>D2</td>
									<td>D1</td>
									<td>---</td>
								</tr>
							</table><br>
							
							
							<table class="table-no-borders">
								<tr>
									<td>Class teacher comments:</td>
									<td width="80%">......................................................................................................................................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-no-borders">
								<tr>
									<td width="60%"></td>
									<td>Signature:</td>
									<td>....................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-no-borders">
								<tr>
									<td>Head Teacher Comments:</td>
									<td width="80%">......................................................................................................................................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-no-borders">
								<tr>
									<td width="60%"></td>
									<td>Signature:</td>
									<td>....................................................................</td>
									
								</tr>
								
							</table>
							
							<table class="table-borders-top-bottom">
								
								<tr>
									<td>Next Term Begins on </td>
									<td><?php echo $termbegin;?></td>
									<td>and ends on</td>
									<td><?php echo $termend;?></td>
									
								</tr>
									
								
								
							</table>
							
							<?php
							endforeach;
							?>
							<div class="clearfix"></div>
                            </div>
							<div class="clearfix" style="page-break-after:always"></div>
                            
                            <?php
						endforeach;
						
						?>
                        
                        <div class="clearfix" style="page-break-after:always;"></div>
                        
							<button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Report</button>
                        <?php
						
						$posits = $posdata['positions'];
						
						/*foreach($posits as $posit):
							echo $posit['avrgmrk'].',';
							echo $posit['student'].' ';
						endforeach;*/
						
						//echo $controller->getPositionGeneral($posits);
					}
					
					else{
					
					
					
					$mclass = '';
					$myear = '';
					$mterm = '';
					if(isset($_GET['year']) and isset($_GET['class']))
				  	{
					  $mclass = $_GET['class'];
					  $myear = $_GET['year'];
					  $mterm = $_GET['term'];
					  
					$sql = "SELECT * FROM students st WHERE st.class = '$mclass'";
					  
				  	}
                 	?>
                    <div class="info"></div>
                    <div class="col-lg-12 col-sm-12">
                    	<p class="text-muted font-13 m-b-30">
                            <div class="row">
                                <form action="" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>
                                    <div class="col-lg-2">
                                        <h4>Filter students</h4>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="text" id="year" name="year" value="<?php echo $myear;?>" placeholder="Select year" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                      <div class="item form-group">
                                            <?php
                                            $terms = array('Term 1', 'Term 2', 'Term 3');
                                            ?>
                                          <select id="term" class="form-control" name="term" required>
                                            <option value="">Select term</option>
                                            <?php
                                            foreach($terms as $term):
                                            ?>
                                                <option <?php if($term == $mterm) echo "Selected";?>><?php echo $term;?></option>                                
                                            <?php
                                            endforeach;
                                            ?>
                                          </select>
                                      </div>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'O Level'");
										?>
									  <select id="class" class="class form-control" name="class" required>
										<option value="">Select class</option>
										<?php
										foreach($classes as $class):
										?>
										
										<option value="<?php echo $class->id;?>" <?php if($class->id == $mclass) echo "Selected";?>><?php echo $class->className;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                    	<div class="btn-group">
                                    		<input type="submit" name="action" value="Filter students" class="btn btn-primary">
                                            <?php
											if(isset($_GET['year'])){
											?>
                                            <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger"><span class="fa fa-times"></span> Cancel filter</a>
											<?php
											}
											?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </p>
                    </div>
                    <!--<div class="col-lg-2 col-sm-12">
                    <p class="text-muted font-13 m-b-30">
                    	
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add marks</a>
                      <div class="clearfix"></div>
                    </p>
                    </div>-->
                    <div class="clearfix"></div>
                    <hr>
                    <?php
					
					if(isset($_GET['year']) and isset($_GET['term'])){
						$year = $_GET['year'];
						$term = $_GET['term'];
						$all_marks = "SELECT * FROM marks WHERE year = '$year' AND term = '$term'";
						
						$marksdatas = $controller->getcustomdata($all_marks);
							
							if(count($marksdatas) < 1){
								$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
								?>
								<div class="no-print">
								<hr>
								<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
								
								</div>
								<?php
								exit();
							}
					?>
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <!--<th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>-->
                          <th>Year</th>
                          <th>Term</th>
                          <th>Student Name</th>
                          <th>Student Number</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  
					  $datas = $controller->getcustomdata($sql);
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
					  ?>
                        <tr>
                          <!--<td><input type="checkbox" name="ids[]" value="<?php echo $data->marksId;?>" class="table_records flat "></td>-->
                          <td><?php echo $myear;?></td>
                          <td><?php echo $mterm;?></td>
                          <td><?php echo $data->fname. ' ' .$data->lname;?></td>
                          <td><?php echo $data->studentNumber;?></td>
                          <td><a href="?student=<?php echo $data->studentId;?>&year=<?php echo $myear;?>&term=<?php echo $mterm;?>&class=<?php echo $mclass;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Generate Report</a> </td>
                        </tr>
                        
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                	<div class="clearfix"></div>
                    <hr>
                    <a href="?all&year=<?php echo $myear;?>&term=<?php echo $mterm;?>&class=<?php echo $mclass;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Generate All Reports</a>
					</form>
					<?php }?>
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>