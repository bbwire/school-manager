		<?php
		require_once ("inc/essentials.php");
		
		$class = "StudentsController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Students </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					
					
					if(isset($_GET['new'])){
						
						if(isset($_POST['postnew']))
						{
							$controller->poststudent();
						}
						
						if(isset($_POST['upload']))
						{
							$controller->uploadfromexcel('students', 'students.php');
						}
						
						?>
                        
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

                      
                          <span class="section">New Student</span>
    
    					  <div id="output"></div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="level">Level <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12" id="study_level">
                              <select id="level" class="form-control" name="level" required>
                              	<option value="">Select level</option>
                              	<option class="o-level" value="O Level">O Level</option>
                                <option class="a-level" value="A Level">A Level</option>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="fname">First Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="fname" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="fname" placeholder="First Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="lname">Last Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="lname" class="form-control" name="lname" placeholder="Last Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group gender" id="genders">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="gender">Gender <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="gender" class="flat" value="Male" name="gender" type="radio"> Male &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <input id="gender" class="flat" value="Female" name="gender" type="radio"> Female
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="class">Class <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$classes = $controller->getdata("classes", "id", "asc");
								?>
                              <select id="class" class="class form-control" name="class" required>
                              	<option value="">Select class</option>
                              	<?php
								foreach($classes as $class):
								
								$explode = explode('.', $class->className);
								$clasnum = $explode[1];
								
								if($class->className == 'S.5' or $class->className == 'S.6')
								{
									$classid = "alevel".$clasnum;
								}
								else
								{
									$classid = "olevel".$clasnum;
								}
								?>
                                
                                <option id="<?php echo $classid;?>" value="<?php echo $class->id;?>"><?php echo $class->className;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group" id="class_stream">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="stream">Stream <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <select id="stream" class="form-control" name="stream" required>
                              	<option value="">Select stream</option>
                              	<option id="north">North</option>
                                <option id="south">South</option>
                                <option id="a">A</option>
                                <option id="s">S</option>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="stdno">Student Number <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="stdno" class="form-control" name="stdno" placeholder="Student Number" readonly required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="aggregate">Aggregate <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="aggregate" class="form-control" name="aggregate" placeholder="Aggregate"  type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="dob">Date of birth <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="dob" class="form-control" name="dob" placeholder="Date of birth" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="religion">Religion <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="religion" class="form-control" name="religion" placeholder="Religion"  type="text">
                            </div>
                          </div>
                          <div id="a_level_show">
                          
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="ps1">Principle Subject 1 <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Principal'");
                                    ?>
                                  <select id="ps1" class="form-control" name="ps1">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="ps2">Principle Subject 2 <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Principal'");
                                    ?>
                                  <select id="ps2" class="form-control" name="ps2">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="ps3">Principle Subject 3 <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Principal'");
                                    ?>
                                  <select id="ps3" class="form-control" name="ps3">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="sub">Subsidiary Subject <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Subsidiary'");
                                    ?>
                                  <select id="sub" class="form-control" name="sub">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group" id="a_level_show">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="combination">Combination <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <input id="combination" class="form-control" name="combination" placeholder="Combination" readonly type="text">
                                </div>
                              </div>
                          </div>                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pic">Student pic <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="pic" name="pic" type="file">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="parent">Parent <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="parent" class="form-control" name="parent" placeholder="Parent"  type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="contact">Contact <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="contact" class="form-control" name="contact" placeholder="Contact"  type="text">
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="district">District <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$districts = $controller->getdata("district", "districtName", "asc");
								?>
                              <select id="district" class="form-control" name="district" >
                              	<option value="">Select district</option>
                              	<?php
								foreach($districts as $district):
								?>
                                
                                <option value="<?php echo $district->districtId;?>"><?php echo $district->districtName;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="county">County <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	
                              	<select class="form-control" name="county" id="county" >
                                	                                
                                </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="receipt">Receipt Number <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="receipt" class="form-control" name="receipt" placeholder="Receipt Number"  type="text">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="postnew" class="btn btn-success"><i class="fa fa-check"></i> Save Student</button>
                            </div>
                          </div>
                        </form>
                        
                        <hr>
                        <h3>Upload from excel(csv) file</h3>
						<div class="output"></div>
                        <form class="form-horizontal form-label-left" method="post" id="demo-form2" data-parsley-validate enctype="multipart/form-data">
							<div class="item form-group xlevel">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="levelex">Level <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12" id="study_level">
                              <select id="levelex" class="form-control" name="level" required>
                              	<option value="">Select level</option>
                              	<option class="o-level" value="O Level">O Level</option>
                                <option class="a-level" value="A Level">A Level</option>
                              </select>
                            </div>
                          </div>
                        	<div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="classex">Class <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$classes = $controller->getdata("classes", "id", "asc");
								?>
                              <select id="classex" class="class form-control" name="class" required>
                              	<option value="">Select class</option>
                              	<?php
								foreach($classes as $class):
								
								$explode = explode('.', $class->className);
								$clasnum = $explode[1];
								
								if($class->className == 'S.5' or $class->className == 'S.6')
								{
									$classid = "alevelx".$clasnum;
								}
								else
								{
									$classid = "olevelx".$clasnum;
								}
								?>
                                
                                <option id="<?php echo $classid;?>" value="<?php echo $class->id;?>"><?php echo $class->className;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                        	<div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="excelfile">Choose the csv file to upload <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="excelfile" name="file" type="file">
                            </div>
                          </div>
                          <div class="clearfix"></div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="sendexcel" type="submit" class="btn btn-success" name="upload"><i class="fa fa-upload"></i> Upload Students Data</button>
                            </div>
                          </div>
                          
                        </form>
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updatestudent($updateid);
						}
						
						$updatedatas = $controller->getindividual("students", "studentId", $updateid);
						
						foreach($updatedatas as $data):
						
						$level = $data->studyLevel;
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

                      
                          <span class="section">Update <?php echo $data->fname;?> Info</span>
    
    					  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="level">Level <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12" id="study_level_update">
                            	<?php
								$levels = array('O Level','A Level');
								?>
                              <select id="level" class="form-control" name="level" required disabled>
                              	<?php
								foreach($levels as $level):
								?>
                              	<option <?php if($level == $data->studyLevel) echo "Selected";?>><?php echo $level;?></option>
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="fname">First Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="fname" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" value="<?php echo $data->fname;?>" name="fname" placeholder="First Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="lname">Last Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="lname" class="form-control" name="lname" placeholder="Last Name" value="<?php echo $data->lname;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="gender">Gender <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$genders = array('Female', 'Male');
								?>
                              <select id="gender" class="form-control" name="gender" required>
                              	<option value="">Select gender</option>
                              	<?php
								foreach($genders as $gender):
								?>
                                
                                <option <?php if($gender == $data->gender){ echo "selected";}?>><?php echo $gender;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="class">Class <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$classes = $controller->getdata("classes", "id", "asc");
								?>
                              <select id="class" class="class form-control" name="class" required>
                              	<option value="">Select class</option>
                              	<?php
								foreach($classes as $class):
								?>
                                
                                <option value="<?php echo $class->id;?>" <?php if($class->id == $data->class) echo "Selected";?>><?php echo $class->className;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group" id="class_stream">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="stream">Stream <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								if($level == 'O Level')
								{
									$streams = array('North', 'South');
								}
								else
								{
									$streams = array('A', 'S');
								}
								?>
                              <select id="stream" class="form-control" name="stream" required>
                              	<option value="">Select stream</option>
                                <?php
								foreach($streams as $stream):
								?>
                              	<option id="north" <?php if($stream == $data->stream){ echo "selected";}?>><?php echo $stream;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="aggregate">Aggregate <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="aggregate" class="form-control" name="aggregate" placeholder="Aggregate" value="<?php echo $data->aggregate;?>" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="dob">Date of birth <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="dob" class="form-control" name="dob" placeholder="Date of birth" value="<?php echo $data->dateOfBirth;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="religion">Religion <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="religion" class="form-control" name="religion" placeholder="Religion" value="<?php echo $data->religion;?>" required="required" type="text">
                            </div>
                          </div>
                          <div id="a_level_show_update">
                          	<div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="psone">Principle Subject 1 <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Principal'");
                                    ?>
                                  <select id="psone" class="form-control" name="ps1">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>" <?php if($subject->id == $data->principOne) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pstwo">Principle Subject 2 <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Principal'");
                                    ?>
                                  <select id="pstwo" class="form-control" name="ps2">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>" <?php if($subject->id == $data->principTwo) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="psthree">Principle Subject 3 <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Principal'");
                                    ?>
                                  <select id="psthree" class="form-control" name="ps3">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>" <?php if($subject->id == $data->principThree) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group gender">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="subsi">Subsidiary Subject <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                    <?php
                                    $subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level' and subjectType = 'Subsidiary'");
                                    ?>
                                  <select id="subsi" class="form-control" name="sub">
                                    <option value="">Select subject</option>
                                    <?php
                                    foreach($subjects as $subject):
                                    ?>
                                    
                                    <option value="<?php echo $subject->id;?>" <?php if($subject->id == $data->subsid) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
                                    
                                    <?php
                                    endforeach;
                                    ?>
                                  </select>
                                </div>
                              </div>
                              <div class="item form-group">
                                <label class="control-label col-md-2 col-sm-2 col-xs-12" for="combinationup">Combination <span class="required">*</span>
                                </label>
                                <div class="col-md-8 col-sm-8 col-xs-12">
                                  <input id="combinationup" class="form-control" name="combination" placeholder="Combination" value="<?php echo $data->combination;?>" type="text" readonly>
                                </div>
                              </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="parent">Parent <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="parent" class="form-control" name="parent" placeholder="Parent" value="<?php echo $data->parent;?>" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="contact">Contact <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="contact" class="form-control" name="contact" placeholder="Contact" value="<?php echo $data->contact;?>" type="text">
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="district">District <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$districts = $controller->getdata("district", "districtName", "asc");
								?>
                              <select id="district" class="form-control" name="district">
                              	<option value=""> Select District</option>
                              	<?php
								foreach($districts as $district):
								?>
                                
                                <option value="<?php echo $district->districtId;?>" <?php if($district->districtId == $data->district) echo "Selected";?>><?php echo $district->districtName;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="county">County <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$countys = $controller->getindividual("county", "countyId", $data->county);
								$countname = '';
								foreach($countys as $county):
									$countname = $county->countyName;
								endforeach;
								?>
                              	<select class="form-control" name="county" id="county">
                                	  <option value="<?php echo $data->county;?>" <?php //if($district->districtId == $data->district) echo "Selected";?>><?php echo $countname;?></option>                              
                                </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="receipt">Receipt Number <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="receipt" class="form-control" name="receipt" placeholder="Receipt Number" value="<?php echo $data->receiptNumber;?>" type="text">
                            </div>
                          </div>
                                                    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pic">Change student pic <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="pic" name="pic" type="file">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "students";
						$primary_key = "studentId";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'students';
							$url = 'students.php';
							$pk = 'studentId';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count Students have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
                 	?>
                    <p class="text-muted font-13 m-b-30">
                    	<div class="info"></div>
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add a student</a>
                      <div class="clearfix"></div>
                    </p>
                    
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
                          <th>Name</th>
                          <th>Gender</th>
                          <th>Class</th>
                          <th>Stream</th>
                          <th>Student No.</th>
                          <th>D.O.B</th>
                          <th>Religion</th>
                          <th>Parent</th>
                          <th>Contact</th>
                          <th>District</th>
                          <th>County</th>
                          <th>Receipt</th>
                          <!---<th>Date</th>--->
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  $datas = $controller->getdata("students", 'studentId', 'asc');
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
						
						$class = $controller->getindividual("classes", "id", $data->class);
						
						foreach($class as $clas):
							$clasnam = $clas->className;
						endforeach;
						
						$districts = $controller->getindividual("district", "districtId", $data->district);
						
						$distnam = '';
						foreach($districts as $district):
							$distnam = $district->districtName;
						endforeach;
						
						$counties = $controller->getindividual("county", "countyId", $data->county);
						
						$countnam = '';
						foreach($counties as $county):
							$countnam = $county->countyName;
						endforeach;
					  ?>
                        <tr>
                          <td><input type="checkbox" name="ids[]" value="<?php echo $data->studentId;?>" class="table_records flat "></td>
                          <td><?php echo $data->fname.' '.$data->lname;?></td>
                          <td><?php echo $data->gender;?></td>
                          <td><?php echo $clasnam;?></td>
                          <td><?php echo $data->stream;?></td>
                          <td><?php echo $data->studentNumber;?></td>
                          <td><?php echo $data->dateOfBirth;?></td>
                          <td><?php echo $data->religion;?></td>
                          <td><?php echo $data->parent;?></td>
                          <td><?php echo $data->contact;?></td>
                          <td><?php echo $distnam;?></td>
                          <td><?php echo $countnam;?></td>
                          <td><?php echo $data->receiptNumber;?></td>
                          <!----<td><?php echo $data->date;?></td>--->
                          <td><a href="?update=<?php echo $data->studentId;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $data->studentId;?>"><i class="fa fa-trash"></i> Delete</button></td>
                        </tr>
                        
                        <div class="modal fade" id="confirm-delete<?php echo $data->studentId;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
									</div>
									<div class="modal-body">
										Are you sure you want to delete this record?
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
										<a href="?delete=<?php echo $data->studentId;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
									</div>
								</div>
							</div>
						</div>
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                    
                    <div class="clearfix"></div>
                    <hr>
                    <button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
					</form>
					
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->

        <?php
		require_once ("inc/footer.php");
		?>