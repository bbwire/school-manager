		<?php
		require_once ("inc/essentials.php");
		
		$class = "GradeController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Alevel Grades </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                  
                  	<?php
					if(isset($_GET['new'])){
						
						if(isset($_POST['postnew']))
						{
							$controller->postagrade();							
						}
						
						?>
                        <form action="" method="post" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>

                          <span class="section"><i class="fa fa-plus"></i> New grade</span>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="bestpaper">Best Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="bestpaper" class="form-control" name="bestpaper" placeholder="Enter Best Paper" required type="text">
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="secondbestpaper">Second Best Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="secondbestpaper" class="form-control" name="secondbestpaper" placeholder="Enter Second Best Paper" required type="text">
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="thirdbestpaper">Third Best Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="thirdbestpaper" class="form-control" name="thirdbestpaper" placeholder="Enter Third Best Paper" required type="text">
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="papertype">Paper Type <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$papertype = array('single', 'double', 'triple');
								?>
                              <select id="papertype" class="form-control" name="papertype" required>
                              	<option value="">Select Paper Type</option>
                                <?php
								foreach($papertype as $paper):
								?>
                                	<option><?php echo $paper;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="grade">Select grade <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$grades = array('A', 'B', 'C', 'D', 'E', 'O', 'F');
								?>
                              <select id="grade" class="form-control" name="grade" required>
                              	<option value="">Select Grade</option>
                                <?php
								foreach($grades as $grade):
								?>
                                	<option><?php echo $grade;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="points">Points <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$gradepoints = array('6', '5', '4', '3', '2', '1', '0');
								?>
                              <select id="points" class="form-control" name="points" required>
                              	<option value="">Select Point</option>
                                <?php
								foreach($gradepoints as $point):
								?>
                                	<option><?php echo $point;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="comm">Comment <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <textarea id="comm" required name="comm" placeholder = "Enter Comment" class="form-control"></textarea>
                            </div>
                          </div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="postnew" class="btn btn-success" ><i class="fa fa-check"></i> Save Grade</button>
                            </div>
                          </div>
                        </form>
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updateagrade($updateid);
						}
						
						$updatedatas = $controller->getindividual("alevelgrades", "gradeId", $updateid);
						
						foreach($updatedatas as $data):
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                      
                          <span class="section">Update Info</span>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="bestpaper">Best Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="bestpaper" class="form-control" name="bestpaper" value = "<?php echo $data->bestPaper;?>" placeholder="Best Paper Mark" required type="text">
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="secondbestpaper">Second Best Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="secondbestpaper" class="form-control" name="secondbestpaper" value = "<?php echo $data->secondBestPaper;?>" placeholder="Second Best Paper Mark" required type="text">
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="thirdbestpaper">Third Best Paper <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="thirdbestpaper" class="form-control" name="thirdbestpaper" value = "<?php echo $data->thirdBestPaper;?>" placeholder="Third Best Paper Mark" required type="text">
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="papertype">Paper Type <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$papertype = array('single', 'double', 'triple');
								?>
                              <select id="papertype" class="form-control" name="papertype" required>
                                <?php
								foreach($papertype as $paper):
								?>
                                	<option <?php if($data->paperType == $paper) echo "Selected";?>><?php echo $paper;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="grade">Select grade <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$grades = array('A', 'B', 'C', 'D', 'E', 'O', 'F');
								?>
                              <select id="grade" class="form-control" name="grade" required>
                                <?php
								foreach($grades as $grade):
								?>
                                	<option <?php if($data->grade == $grade) echo "Selected";?>><?php echo $grade;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="points">Points <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$points = array('6', '5', '4', '3', '2', '1', '0');
								?>
                              <select id="points" class="form-control" name="points" required>
                                <?php
								foreach($points as $point):
								?>
                                	<option <?php if($data->points == $point) echo "Selected";?>><?php echo $point;?></option>                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="comm">Comment <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <textarea id="comm" required name="comm" class="form-control"><?php echo $data->comment;?></textarea>
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "alevelgrades";
						$primary_key = "gradeId";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'alevelgrades';
							$url = basename($_SERVER['PHP_SELF']);
							$pk = 'gradeId';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count grades have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
                 	?>
                    <p class="text-muted font-13 m-b-30">
                    	<div class="info"></div>
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add a grade</a>
                      <div class="clearfix"></div>
                    </p>
                    
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
                          <th>Best Paper</th>
						  <th>Second Best Paper</th>
						  <th>Third Best Paper</th>
						  <th>Grade</th>
                          <th>Points</th>
                          <th>Comment</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  $datas = $controller->getdata("alevelgrades", "gradeId", "ASC");
					  
					  $count = 0;
					  foreach($datas as $data):
					  	
						$id = $data->gradeId;
					  	$count++;
					  ?>
                        <tr>
                          <td><input type="checkbox" name="ids[]" value="<?php echo $id;?>" class="table_records flat "></td>
                          <td><?php echo $data->bestPaper;?></td>
						  <td><?php echo $data->secondBestPaper;?></td>
						  <td><?php echo $data->thirdBestPaper;?></td>
						  <td><?php echo $data->grade;?></td>
                          <td><?php echo $data->points;?></td>
                          <td><?php echo $data->comment;?></td>
                          <td><a href="?update=<?php echo $id;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $id;?>"><i class="fa fa-trash"></i> Delete</button></td>
                        </tr>
                        
                        <div class="modal fade" id="confirm-delete<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to delete this record?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
                                    <a href="?delete=<?php echo $id;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
                                </div>
                            </div>
                        </div>
                    </div>
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                    <div class="clearfix"></div>
                    <hr>
                    <button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
					</form>
                    
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>