		<?php
		require_once ("inc/essentials.php");
		
		$class = "UsersController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Users </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					
					if(isset($_POST['postnew']))
					{
						$controller->postuser();
					}
					
					if(isset($_GET['new'])){
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

                      
                          <span class="section">New User</span>
    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="fname">First Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="fname" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="fname" placeholder="First Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="lname">Last Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="lname" class="form-control" name="lname" placeholder="Last Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="dob">Date of birth <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="dob" class="form-control" name="dob" placeholder="Date of birth" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="email">Email <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="email" class="form-control" name="email" placeholder="Email" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="gender">Gender <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="gender" class="flat" value="Male" name="gender" data-parsley-multiple="gender" type="radio"> Male &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                              <input id="gender" class="flat" value="Female" name="gender" data-parsley-multiple="gender" type="radio"> Female
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="phone">Phone <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="phone" class="form-control" name="phone" placeholder="Phone" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="address">Address <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="address" class="form-control" name="address" placeholder="Address" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="level">User level <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$users = array("admin","dos","finance","teacher");
								?>
                              <select id="level" class="form-control" name="level" required>
                              	<option value="">Select user level</option>
                              	<?php
								foreach($users as $user):
								?>
                                
                                	<option><?php echo $user;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pic">Profile pic <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="pic" class="form-control" name="pic" type="file">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="username">Username <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="username" class="form-control" name="username" placeholder="Username" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="password">Password <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="paassword" class="form-control" name="password" placeholder="Password" required="required" type="password">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="postnew" class="btn btn-success"><i class="fa fa-check"></i> Save User</button>
                            </div>
                          </div>
                        </form>
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updateusers($updateid, "users.php");
						}
						
						$updatedatas = $controller->getindividual("users", "userid", $updateid);
						
						foreach($updatedatas as $data):
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                      
                          <span class="section">Update <?php echo $data->fname;?> Info</span>
    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="fname">First Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="fname" class="form-control col-md-7 col-xs-12" value="<?php echo $data->fname;?>" data-validate-length-range="6" name="fname" placeholder="First Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="lname">Last Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="lname" class="form-control" name="lname" placeholder="Last Name" value="<?php echo $data->lname;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="dob">Date of birth <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="dob" class="form-control" name="dob" placeholder="Date of birth" value="<?php echo $data->birthday;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="email">Email <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="email" class="form-control" name="email" placeholder="Email" value="<?php echo $data->email;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="gender">Gender <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$genders = array('Female', 'Male');
								?>
                              <select id="gender" class="form-control" name="gender" required>
                              	<option value="">Select gender</option>
                              	<?php
								foreach($genders as $gender):
								?>
                                
                                <option <?php if($gender == $data->gender){ echo "selected";}?>><?php echo $gender;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="phone">Phone <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="phone" class="form-control" name="phone" placeholder="Phone" value="<?php echo $data->phoneNo;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="address">Address <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="address" class="form-control" name="address" placeholder="Address" value="<?php echo $data->address;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="level">User level <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$roles = array("admin","dos","finance");
								?>
                              <select id="level" class="form-control" name="level" required>
                              	<option value="">Select user level</option>
                              	<?php
								foreach($roles as $role):
								?>
                                
                                	<option <?php if($role == $data->role) echo "selected"?>><?php echo $role;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pic">Profile pic (select to change) <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="pic" class="form-control" name="pic" type="file">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="username">Username <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="username" class="form-control" name="username" placeholder="Username" value="<?php echo $data->username;?>" required="required" type="text">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "users";
						$primary_key = "userid";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'classes';
							$url = 'classes.php';
							$pk = 'id';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count Classes have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
                 	?>
                    
                    <p class="text-muted font-13 m-b-30">
                    	<div class="info"></div>
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add a user</a>
                      <div class="clearfix"></div>
                    </p>
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
                          <th>Name</th>
                          <th>Gender</th>
                          <th>Phone</th>
                          <th>Email</th>
                          <th>Address</th>
                          <th>D.O.B</th>
                          <th>Username</th>
                          <th>Role</th>
                          <th>Operation</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  $datas = $controller->getdata("users", "userid", "ASC");
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
					  ?>
                        <tr>
                          <td><input type="checkbox" name="ids[]" value="<?php echo $data->userid;?>" class="table_records flat "></td>
                          <td><?php echo $data->fname.' '.$data->lname;?></td>
                          <td><?php echo $data->gender;?></td>
                          <td><?php echo $data->phoneNo;?></td>
                          <td><?php echo $data->email;?></td>
                          <td><?php echo $data->address;?></td>
                          <td><?php echo $data->birthday;?></td>
                          <td><?php echo $data->username;?></td>
                          <td><?php echo $data->role;?></td>
                          <td><a href="?update=<?php echo $data->userid;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $data->userid;?>"><i class="fa fa-trash"></i> Delete</button></td>
                        </tr>
                        
                        <div class="modal fade" id="confirm-delete<?php echo $data->userid;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to delete this record?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
                                    <a href="?delete=<?php echo $data->userid;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
                                </div>
                            </div>
                        </div>
                    </div>
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
					<div class="clearfix"></div>
                    <hr>
                    <button type="submit" class="btn btn-warning" name="deletemulti" id="delete_multiple"><i class="fa fa-trash"></i> Delete multiple Records</button>
					</form>
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->

        <?php
		require_once ("inc/footer.php");
		?>