		<?php
		require_once ("inc/essentials.php");
		
		$class = "BooksController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Books in the library </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					
					if(isset($_POST['postnew']))
					{
						$controller->postbook();
					}
					
					if(isset($_GET['new'])){
						?>
                        <form class="form-horizontal form-label-left" method="post" id="demo-form2" data-parsley-validate>

                          <span class="section"><i class="fa fa-plus"></i> New book</span>
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="name">Book Title <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="name" class="form-control" data-validate-length-range="6" name="name" placeholder="Book Title" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="desc">Book Description <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <textarea id="desc" required name="desc" class="form-control"></textarea>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="author">Book Author <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="author" class="form-control" data-validate-length-range="6" name="author" placeholder="Both Name(s) e.g Ojok David" data-validate-words="2" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="type">Book Type <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <select id="type" class="form-control" name="type" required>
                              	<option></option>
                              	<option>Option 1</option>
                                <option>Option 2</option>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="price">Book Price <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="price" class="form-control" data-validate-length-range="6" name="price" placeholder="Book Price" required="required" type="text">
                            </div>
                          </div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" name="postnew" type="submit" class="btn btn-success"><i class="fa fa-check"></i> Save Book</button>
                            </div>
                          </div>
                        </form>
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updatebook($updateid);
						}
						
						$updatedatas = $controller->getindividual("booklibrary", "id", $updateid);
						
						foreach($updatedatas as $data):
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                      
                          <span class="section">Update <?php echo $data->bookName;?> Info</span>
    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="name">Book Title <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="name" class="form-control" data-validate-length-range="6" name="name" value="<?php echo $data->bookName;?>" placeholder="Book Title" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="desc">Book Description <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <textarea id="desc" required name="desc" class="form-control"><?php echo $data->bookDescription;?></textarea>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="author">Book Author <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="author" class="form-control" data-validate-length-range="6" name="author" value="<?php echo $data->bookAuthor;?>" placeholder="Both Name(s) e.g Ojok David" data-validate-words="2" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="type">Book Type <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <select id="type" class="form-control" name="type" required>
                              	<option value="">Select Book Type</option>
                              	<option>Option 1</option>
                                <option>Option 2</option>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="price">Book Price <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="price" class="form-control" data-validate-length-range="6" name="price" value="<?php echo $data->bookPrice;?>" placeholder="Book Price" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="state">Book State<span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$states = array('Available', 'Unavailable');
								?>
                              <select id="state" class="form-control" name="state" required>
                              	<option value="">Select Book State</option>
                                <?php
								foreach($states as $state):
								?>
                              	<option <?php if($state == $data->bookState) echo "selected";?>><?php echo $state;?></option>
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "booklibrary";
						$primary_key = "id";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'booklibrary';
							$url = 'library.php';
							$pk = 'id';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count Books have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
                 	?>
                    
                    <p class="text-muted font-13 m-b-30">
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add a book</a>
                      <div class="clearfix"></div>
                    </p>
                    
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
                          <th>Book Name</th>
                          <th>Description</th>
                          <th>Author</th>
                          <th>Type</th>
                          <th>Price</th>
                          <th>State</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  $datas = $controller->getdata("booklibrary", "id", "ASC");
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
					  ?>
                        <tr>
                          <td><input type="checkbox" name="ids[]" value="<?php echo $data->id;?>" class="table_records flat "></td>
                          <td><?php echo $data->bookName;?></td>
                          <td><?php echo $data->bookDescription;?></td>
                          <td><?php echo $data->bookAuthor;?></td>
                          <td><?php echo $data->bookType;?></td>
                          <td><?php echo $data->bookPrice;?></td>
                          <td><?php echo $data->bookState;?></td>
                          <td><a href="?update=<?php echo $data->id;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <a href="" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $data->id;?>"><i class="fa fa-times"></i> Delete</a></td>
                        </tr>
                    
                        <div class="modal fade" id="confirm-delete<?php echo $data->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
                                    </div>
                                    <div class="modal-body">
                                        Are you sure you want to delete this record?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
                                        <a href="?delete=<?php echo $data->id;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                    
                    <div class="clearfix"></div>
                    <hr>
                    <button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
					</form>
					
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        
        

        <?php
		require_once ("inc/footer.php");
		?>