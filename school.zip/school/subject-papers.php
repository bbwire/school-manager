		<?php
		require_once ("inc/essentials.php");
		
		$class = "SubjectsController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Subject Paper </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
						if(isset($_POST['postnew']))
						{
							$controller->postpaper();
						}
						
						if(isset($_POST['upload']))
						{
							$controller->uploadfromexcel("subject", "subjects.php");
						}
						
					if(isset($_GET['new'])){
						
						?>
                        <form class="form-horizontal form-label-left" method="post" id="demo-form2" data-parsley-validate>

                          <span class="section"><i class="fa fa-plus"></i> New Paper</span>
    
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="name">Paper Title <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="name" class="form-control" name="name" placeholder="e.g 1" required="required" type="text">
                            </div>
                          </div>
                          <!--<div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="desc">Paper Teacher <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input type="text" id="desc" required name="desc" class="form-control" placeholder="Both Name(s) e.g Ojok David" data-validate-words="2"  data-validate-length-range="6">
                            </div>
                          </div>-->
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="subject">Parent Subject <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level'");
								?>
                              <select id="subject" class="subject form-control" name="subject" required>
                              	<option value="">Select student number</option>
                              	<?php
								foreach($subjects as $subject):
								?>
                                
                                <option value="<?php echo $subject->id;?>"><?php echo $subject->subjectTitle;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" class="btn btn-success" name="postnew"><i class="fa fa-check"></i> Save Paper</button>
                            </div>
                          </div>
                        </form>
                       
                        
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updatepaper($updateid);
						}
						
						$updatedatas = $controller->getindividual("subjectpaper", "paperId", $updateid);
						
						foreach($updatedatas as $data):
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                      
                          <span class="section">Update <?php echo $data->paperTitle;?> Info</span>
    
						  <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="name">Paper Title <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="name" class="form-control" name="name" placeholder="e.g 1" value="<?php echo $data->paperTitle;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="subject">Parent Subject <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level'");
								?>
                              <select id="subject" class="subject form-control" name="subject" required>
                              	<option value="">Select student number</option>
                              	<?php
								foreach($subjects as $subject):
								?>
                                
                                <option value="<?php echo $subject->id;?>"<?php if($subject->id == $data->paperParent) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
							</div>
							
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "subject";
						$primary_key = "id";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'subject';
							$url = 'subjects.php';
							$pk = 'id';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count Subjects have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
                 	?>
                    <p class="text-muted font-13 m-b-30">
                    	<div class="info"></div>
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add a subject paper</a>
                      <div class="clearfix"></div>
                    </p>
                    
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
                          <th>Paper Title</th>
                          <th>Paper Parent</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  $datas = $controller->getcustomdata("SELECT * FROM subjectpaper sp, subject s WHERE sp.paperParent = s.id");
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
					  ?>
                        <tr>
                          <td><input type="checkbox" name="ids[]" value="<?php echo $data->paperId;?>" class="table_records flat "></td>
                          <td><?php echo $data->paperTitle;?></td>
                          <td><?php echo $data->subjectTitle;?></td>
                          <td><a href="?update=<?php echo $data->paperId;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $data->paperId;?>"><i class="fa fa-trash"></i> Delete</button></td>
                        </tr>
                        
                        <div class="modal fade" id="confirm-delete<?php echo $data->paperId;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to delete this record?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
                                    <a href="?delete=<?php echo $data->paperId;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
                                </div>
                            </div>
                        </div>
                    </div>
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                    
                    <div class="clearfix"></div>
                    <hr>
                    <button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
					</form>
					
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>