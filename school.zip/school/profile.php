		<?php
		require_once ("inc/essentials.php");
		
		$class = "UsersController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Profile </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
						
						$datas = $controller->getuser();
						
						foreach($datas as $data):
						
						if(isset($_POST['update']))
						{
							$controller->updateusers($data->userid, "profile.php");
						}
						
						if(isset($_POST['updatepas']))
						{
							$controller->updatepassword($data->userid, "profile.php");
						}
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="fname">First Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="fname" class="form-control col-md-7 col-xs-12" value="<?php echo $data->fname;?>" data-validate-length-range="6" name="fname" placeholder="First Name" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="lname">Last Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="lname" class="form-control" name="lname" placeholder="Last Name" value="<?php echo $data->lname;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="dob">Date of birth <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="dob" class="form-control" name="dob" placeholder="Date of birth" value="<?php echo $data->birthday;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="email">Email <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="email" class="form-control" name="email" placeholder="Email" value="<?php echo $data->email;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="gender">Gender <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$genders = array('Female', 'Male');
								?>
                              <select id="gender" class="form-control" name="gender" required>
                              	<option value="">Select gender</option>
                              	<?php
								foreach($genders as $gender):
								?>
                                
                                <option <?php if($gender == $data->gender){ echo "selected";}?>><?php echo $gender;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="phone">Phone <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="phone" class="form-control" name="phone" placeholder="Phone" value="<?php echo $data->phoneNo;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="address">Address <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="address" class="form-control" name="address" placeholder="Address" value="<?php echo $data->address;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pic">Profile pic (select to change) <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="pic" class="form-control" name="pic" type="file">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="username">Username <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="username" class="form-control" name="username" placeholder="Username" value="<?php echo $data->username;?>" required="required" type="text">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                             
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
						?>
						
						<hr>
						<h3><i>--- Change password ---</i></h3>
						<div class="output"></div>
						<form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="curpass">Current password <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="curpass" class="form-control" name="curpass" placeholder="Current password" required="required" type="password">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="pass">New password <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="pass" class="form-control" name="pass" placeholder="New password" required="required" type="password">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="cpass">Retype new password<span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="cpass" class="form-control" name="cpass" placeholder="Retype new password"  required="required" type="password">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                             
                              <button id="updatepas" type="submit" name="updatepas" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->

        <?php
		require_once ("inc/footer.php");
		?>