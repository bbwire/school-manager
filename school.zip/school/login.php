<?php
error_reporting(0);
session_start();

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $setting->siteTitle;?> :: Login </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- Animate.css -->
    <link href="https://colorlib.com/polygon/gentelella/css/animate.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.css" rel="stylesheet">
  </head>

  <body class="login">
	
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
			<?php
			require_once ('application/controller/Controller.php');
			if(isset($_SESSION['user'])){
				header("location:./");
			}
			$controller = new Controller();

			if($controller->model->mysqli->connect_errno)
			{ 
				$controller->model->Alert("alert-warning", "It seems there is a database connection problem, please create one <a href='create-database.php'>here</a>");
			}

			$settings = $controller->getdata("settings","id","asc");

			foreach($settings as $setting):
			
				$stitle = $setting->siteTitle;
			?>
            
            <?php
			endforeach;
			?>
          	<?php
			if(isset($_POST['login']))
			{
				$controller->dologin();
			}
			?>
            <form action="" method="post">
              <h1>Admin Login</h1>
              <div>
                <input type="text" class="form-control" placeholder="Username" name="username" required="" />
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" name="password" required="" />
              </div>
              <div>
                <input type="submit" class="btn btn-primary pull-left" name="login" value="Login">
                <a class="reset_pass" href="#">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-paw"></i> <?php echo $stitle?></h1>
                  <p>© <?php echo date("Y");?> All Rights Reserved. <?php echo $stitle;?> </p>
                </div>
              </div>
            </form>
			
          </section>
        </div>
      </div>
    </div>
	
  </body>
</html>
