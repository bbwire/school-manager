		<?php
require_once ("inc/essentials.php");
		
		$class = "StudentsController";
		
		require_once ("inc/head.php");
		?>
		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title no-print">
                    <h2>A Level performance summary </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					if(isset($_GET['term']) and isset($_GET['year']) and isset($_GET['class'])){
						
						$gterm = $_GET['term'];
						$gyear = $_GET['year'];
						$class = $_GET['class'];
						
						$all_marks = "select * from amarks where year = '$gyear' and term = '$gterm' and classId = '$class'";
							
						$marksdatas = $controller->getcustomdata($all_marks);
						
						if(count($marksdatas) < 1){
							$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
							?>
							<div class="no-print">
							<hr>
							<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
							
							</div>
							<?php
							exit();
						}
						
						?>
						<div class="no-print">
							<button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Report </button>
							<a class="btn btn-primary no-print pull-right" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
							<hr>
							</div>
                        <table class="report-table">
                        	<tr>
                            	<td class="main rotate"><div><span>NAME</span></td>
								<td class="main rotate"><div><span>GP</span></div>
								<td class="main rotate"><div><span>SMA</span></td>
								<td class="main rotate"><div><span>CST</span></td>
								<td class="main rotate"><div><span>BIO</span></td>
								<td class="main rotate"><div><span>HIS</span></td>
								<td class="main rotate"><div><span>AGRIC</span></td>
								<td class="main rotate"><div><span>PHY</span></td>
								<td class="main rotate"><div><span>CHE</span></td>
								<td class="main rotate"><div><span>MTC</span></td>
								<td class="main rotate"><div><span>ECON</span></td>
								<td class="main rotate"><div><span>ENT</span></td>
								<td class="main rotate"><div><span>DIV</span></td>
								<td class="main rotate"><div><span>LIT</span></td>
								<td class="main rotate"><div><span>GOE</span></td>
								<td class="main rotate"><div><span>ART</span></td>
								<td class="main rotate"><div><span>POINTS</span></td>
                            </tr>
                            <?php
						
						
						$query = "SELECT * FROM students  WHERE class = '". $class ."'";
						
						$updatedatas = $controller->getcustomdata($query);
						
						foreach($updatedatas as $data):
						
						
							$subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level'");
							
							$store['performances'] = array();
							$subs['cores'] = array();
							
							$core = array();
							$performance = array();
							
							$span = 1;
							$principals = 0;
							$subsidiaries = 0;
							$fg = null;
							foreach($subjectdatas as $subject):
								
								$bottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, 'subject');
								$botexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, 'subject');
								$eottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, 'subject');
								$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, 'subject');
								
								if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
								{
									$average = '';
									$bottotal = '';
									$eottotal = '';
									$grade = '';
									$final_grade = '';
									$sgrade = '';
									$comment = '';
								}
								else
								{
									if($bottest == '' and $botexam == ''){
										$bottotal = "";
									}elseif($bottest == '' and $botexam != ''){
										$bottotal = ($botexam*100)/70;
									}elseif($bottest != '' and $botexam == ''){
										$bottotal = '';
									}else{
										$bottotal = ($bottest+$botexam);
									}
										
									if($eottest == '' and $eotexam == ''){
										$eottotal = '';
									}elseif($eottest == '' and $eotexam != ''){
										$eottotal = ($eotexam*100)/70;
									}elseif($eottest != '' and $eotexam == ''){
										$eottotal = '';
									}else{
										$eottotal = ($eottest+$eotexam);
									}
									
									if($bottotal == '' and $eottotal != '')
										$average = ($eottotal);
									elseif($bottotal != '' and $eottotal == '')
										$average = ($bottotal);
									else
										$average = (($bottotal)+($eottotal))/2;
									
									
									$grade = $controller->getGrade(number_format($average));
									
									$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
									
									$sgrade = $grades[1];
									
									if($subject->subjectType == 'Subsidiary')
									{
										if($sgrade == (1 or 2 or 3 or 4 or 5 or 6))
										{
											$final_grade = "O";
										}
										else
										{
											$final_grade = "F";
										}
									}
									else
									{
										$final_grade = $controller->getAlevelGrade($grades[1], 'single');
									}
									
									$comment = $controller->getaComment($grades[1], 'single');
								}
								
								
								
								$teacher = $subject->subjectDescription;
								
								$words = explode(" ", $teacher);
								$initials = "";
								
								foreach ($words as $w) {
								  $initials .= $w[0];
								}
								
								
								if($subject->subjectType != "Core")
								{
									$performance['subject'] = $subject->id;
									$performance['average'] = $average;
									$performance['grade'] = $grade;
									array_push($store['performances'], $performance);
								}
								else
								{
									$core['subject'] = $subject->id;
									$core['average'] = $average;
									$core['grade'] = $grade;
									array_push($subs['cores'], $core);
								}
								
								$parent_to = $controller->getcustomdata("SELECT * FROM subjectpaper WHERE paperParent = '". $subject->id ."'");
								
								if(count($parent_to) > 1)
									$span = count($parent_to);
								else
									$span = $span;
									
								if(count($parent_to) <= 1)
								{
								
								
								}
								else
								{
									$avrg_grd = 0;
									$countp = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = '';
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = '';
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = '';
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = '';
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == '' and $eottotal != '')
												$average = ($eottotal);
											elseif($bottotal != '' and $eottotal == '')
												$average = ($bottotal);
											else
												$average = (($bottotal)+($eottotal))/2;
												
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											if($grade != 'Ungraded')
												array_push($papers, $grades[1]);
										}
									
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									$comment = $controller->getaComment($papers, $ptype);
									
									
									/*if($final_grade != '')
									{
										if($subject->subjectType == 'Principal'){
											$principals = $principals+($controller->getPoints($final_grade));
										}
										
										if($subject->subjectType == 'Subsidiary')
										{
											$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
										}
										
										
										
									}*/
									//$fg .= "<td>$final_grade;</td>";
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = '';
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = '';
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = '';
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = '';
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == '' and $eottotal != '')
												$average = ($eottotal);
											elseif($bottotal != '' and $eottotal == '')
												$average = ($bottotal);
											else
												$average = (($bottotal)+($eottotal))/2;
										
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											if($grade != 'Ungraded')
												$sgrade = $grades[1];
											else
												$sgrade = '';
											
										}
										
										
									
									endforeach;
									
									
								
									
								}
								
								
								
								if($final_grade != '')
								{
									if($subject->subjectType == 'Principal'){
										$principals = $principals+$controller->getPoints($final_grade);
									}
									
									if($subject->subjectType == 'Subsidiary')
									{
										$subsidiaries = $subsidiaries+$controller->getPoints($final_grade);
									}
								}
								
								$fg .= "<td>$final_grade</td>";
								
							endforeach;
							//$fg .= "<td>$final_grade</td>";
							?>
								<tr>
									<td><?php echo $data->fname.' '.$data->lname;?></td>
									<?php echo $fg;?>
									<td><?php echo $principals+$subsidiaries;?></td>
								</tr>
                                
								<?php
						
						
						endforeach;	?>
                        </table>
                        
                        
                        <?php
					}else{
					
					
					
					$mclass = '';
					$myear = '';
					$mterm = '';
					if(isset($_GET['year']) and isset($_GET['class']))
				  	{
					  $mclass = $_GET['class'];
					  $myear = $_GET['year'];
					  $mterm = $_GET['term'];
					  
					$sql = "SELECT * FROM students st WHERE st.class = '$mclass'";
					  
				  	}
                 	?>
                    <div class="info"></div>
                    <div class="col-lg-12 col-sm-12">
                    	<p class="text-muted font-13 m-b-30">
                            <div class="row">
                                <form action="" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>
                                    <div class="col-lg-2">
                                        <h4>Filter students</h4>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="text" id="year" name="year" value="<?php echo $myear;?>" placeholder="Select year" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                      <div class="item form-group">
                                            <?php
                                            $terms = array('Term 1', 'Term 2', 'Term 3');
                                            ?>
                                          <select id="term" class="form-control" name="term" required>
                                            <option value="">Select term</option>
                                            <?php
                                            foreach($terms as $term):
                                            ?>
                                                <option <?php if($term == $mterm) echo "Selected";?>><?php echo $term;?></option>                                
                                            <?php
                                            endforeach;
                                            ?>
                                          </select>
                                      </div>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'A Level'");
										?>
									  <select id="class" class="class form-control" name="class" required>
										<option value="">Select class</option>
										<?php
										foreach($classes as $class):
										?>
										
										<option value="<?php echo $class->id;?>" <?php if($class->id == $mclass) echo "Selected";?>><?php echo $class->className;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                    	<div class="btn-group">
                                    		<input type="submit" name="action" value="Filter students" class="btn btn-primary">
                                            <?php
											if(isset($_GET['year'])){
											?>
                                            <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger"><span class="fa fa-times"></span> Cancel filter</a>
											<?php
											}
											?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </p>
                    </div>
                    <!--<div class="col-lg-2 col-sm-12">
                    <p class="text-muted font-13 m-b-30">
                    	
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add marks</a>
                      <div class="clearfix"></div>
                    </p>
                    </div>-->
                    <div class="clearfix"></div>
                    <hr>
                    <?php
					
					if(isset($_GET['year']) and isset($_GET['term'])){
						
					$year = $_GET['year'];
					$term = $_GET['term'];
					
					$all_marks = "select * from amarks where year = '$year' and term = '$term'";
							
					$marksdatas = $controller->getcustomdata($all_marks);
					
					if(count($marksdatas) < 1){
						$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
						?>
						<div class="no-print">
						<hr>
						<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-check"></span> Ok </a>
						
						</div>
						<?php
						exit();
					}
					?>
                    
					<?php }?>
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>