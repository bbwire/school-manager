		<?php
		require_once ("inc/essentials.php");
		
		$class = "CountyController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Counties </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
						if(isset($_POST['postnew']))
						{
							$controller->postcounty();
						}
						
						
					if(isset($_GET['new'])){
						
						?>
                        <form class="form-horizontal form-label-left" method="post" id="demo-form2" data-parsley-validate>

                          <span class="section"><i class="fa fa-plus"></i> New county</span>
    						
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="district">District <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$districts = $controller->getdata("district", "districtName", "asc");
								?>
                              <select id="district" class="form-control" name="district" required>
                              	<option value="">Select District</option>
                              	<?php
								foreach($districts as $district):
								?>
                                
                                <option value="<?php echo $district->districtId;?>"><?php echo $district->districtName;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="name">County Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="name" class="form-control" name="name" placeholder="District name e.g. Kampala" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="desc">County Description <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <textarea id="desc" required name="desc" placeholder="County Description" class="form-control"></textarea>
                            </div>
                          </div>
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" class="btn btn-success" name="postnew"><i class="fa fa-check"></i> Save county</button>
                            </div>
                          </div>
                        </form>
                        
                        <?php
					}elseif(isset($_GET['update'])){
						
						$updateid = $_GET['update'];
						
						/*
							Update button action triggered
						*/
						if(isset($_POST['update']))
						{
							$controller->updatecounty($updateid);
						}
						
						$updatedatas = $controller->getindividual("county", "countyId", $updateid);
						
						foreach($updatedatas as $data):
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post">

                      
                          <span class="section">Update <?php echo $data->countyName;?> Info</span>
    
    					  
                          
                          <div class="item form-group gender">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="district">District <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                            	<?php
								$districts = $controller->getdata("district", "districtId", "asc");
								?>
                              <select id="district" class="form-control" name="district" required>
                              	<option value="">Select district</option>
                              	<?php
								foreach($districts as $district):
								?>
                                
                                <option <?php if($district->districtId == $data->districtId) echo "selected"?> value="<?php echo $district->districtId;?>"><?php echo $district->districtName;?></option>
                                
                                <?php
								endforeach;
								?>
                              </select>
                            </div>
                          </div>
                          
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="name">County Name <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="name" class="form-control" name="name" placeholder="County Name" value="<?php echo $data->countyName;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="desc">County Description <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <textarea id="desc" required name="desc" class="form-control" placeholder="County Description"><?php echo $data->countyDescription;?></textarea>
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                              <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><i class="fa fa-long-arrow-left"></i> Return</a>
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
                        <?php
						endforeach;
					}else{
					?>
                    
                    <?php
					if(isset($_GET['delete'])){
						
						$table = "county";
						$primary_key = "countyId";
						$key_value = $_GET['delete'];
						$return_url = basename($_SERVER['PHP_SELF']);
						
						$controller->delete($table, $primary_key, $key_value, $return_url);
					}
					?>
                    
                    <?php
                    if(isset($_POST['deletemulti'])){
						
						if(isset($_POST['ids']))
						{
							$count = count($_POST['ids']);
							
							$table = 'county';
							$url = basename($_SERVER['PHP_SELF']);
							$pk = 'countyId';
							
							for($i=0; $i<$count; $i++)
							{
								$value = $_POST['ids'][$i];
								$controller->deletemultiple($table, $pk, $value, $url);
							}
							
							$controller->model->Alert("alert-success", "$count Counties have been deleted");
							
						}else
						{
							$controller->model->Alert("alert-danger", "Please select record(s) to delete");
						}
					}
                 	?>
                    <p class="text-muted font-13 m-b-30">
                    	<div class="info"></div>
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add a county</a>
                      <div class="clearfix"></div>
                    </p>
                    
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>
                          <th>County Name</th>
                          <th>County Description</th>
                          <th>District</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  $datas = $controller->getmultiple("county", "district", "districtId");
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
						
						$id = $data->countyId;
					  ?>
                        <tr>
                          <td><input type="checkbox" name="ids[]" value="<?php echo $id;?>" class="table_records flat "></td>
                          <td><?php echo $data->countyName;?></td>
                          <td><?php echo $data->countyDescription;?></td>
                          <td><?php echo $data->districtName;?></td>
                          <td><a href="?update=<?php echo $id;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit</a> <button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#confirm-delete<?php echo $id;?>"><i class="fa fa-trash"></i> Delete</button></td>
                        </tr>
                        
                        <div class="modal fade" id="confirm-delete<?php echo $id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <b><i class="fa fa-info-circle"> </i> Confirm Delete</b>
                                </div>
                                <div class="modal-body">
                                    Are you sure you want to delete this record?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
                                    <a href="?delete=<?php echo $id;?>" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
                                </div>
                            </div>
                        </div>
                    </div>
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                    
                    <div class="clearfix"></div>
                    <hr>
                    <button type="submit" class="btn btn-warning" name="deletemulti"  ><i class="fa fa-trash"></i> Delete multiple Records</button>
					</form>
					
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>