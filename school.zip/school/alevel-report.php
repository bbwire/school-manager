		<?php
require_once ("inc/essentials.php");
		
		$class = "StudentsController";
		
		require_once ("inc/head.php");
		?>
		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          
          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title no-print">
                    <h2>Student Report </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					if(isset($_GET['student']) and isset($_GET['year'])){
						
						$gterm = $_GET['term'];
						$gyear = $_GET['year'];
						
						$updateid = $_GET['student'];
						
						$query = "SELECT * FROM students st, classes cl WHERE st.class = cl.id and st.studentId = '". $updateid ."'";
						
						$updatedatas = $controller->getcustomdata($query);
						
						foreach($updatedatas as $data):
						
						?>
                        <div class="no-print">
                        <div class="col-lg-11">
                        	<span class="section"><?php echo $data->fname. ' ' .$data->lname;?>'s Report Card</span>
                        </div>
                        <div class="col-lg-1">
                        	<a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><span class="fa fa-long-arrow-left"></span> Return</a>
                        </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="banner-with-img" style="position:relative;">
                        	<img src="<?php echo $setting->alevelBanner;?>" class="img-responsive">
                            
                            <?php
							$img = "images/user.png";
							
							if($data->photo != '')
							{
								$img = $data->photo;
							}
							?>
                            
                            <div class="profile-pic" style="">
                            	<img src="<?php echo $img;?>" class="img-responsive">
                            </div>
                        </div>
                        <br>
                        <table class="table-no-borders">
                        	<tr>
                            	<td><b>Name:</b> <?php echo $data->fname. ' ' .$data->lname;?></td>
                                <td style="width:49%"></td>
                                <td><b>Admission Number:</b> <?php echo $data->studentNumber;?></td>
                                <td></td>
                            </tr>
                        </table>
                        <table class="table-no-borders">
                            
                            <tr>
                            	<td style="width:50%;"><b>Class:</b> <?php echo $data->className. ' ' .$data->stream;?></td>
                                <td></td>
                                <td><b>Year:</b> <?php echo $gyear;?></td>
                                <td></td>
                                <td><b><?php echo $gterm;?></b></td>
                                <td></td>
                            </tr>
                        </table>
                        <table class="report-table report-card">
							<thead>
                        	<tr>
                            	<td width='26%'>Subject</td>
                                <td>P</td>
                                <td>MoT (30%)</td>
                                <td>MoT (70%)</td>
                                <!--<td>Total</td>-->
                                <td>EoT (30%)</td>
                                <td>EoT (70%)</td>
                                <!--<td>Total</td>-->
                                <td>AVG</td>
                                <td>Grade</td>
                                <td>Final Grade</td>
                                <td width='37%'>Comments</td>
                                <td>Initials</td>
                            </tr>
							</thead>
                            <?php
							$subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level'");
							
							$store['performances'] = array();
							$subs['cores'] = array();
							
							$core = array();
							$performance = array();
							
							$span = 1;
							$principals = 0;
							$subsidiaries = 0;
							
							foreach($subjectdatas as $subject):
								
								$bottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, 'subject');
								$botexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, 'subject');
								$eottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, 'subject');
								$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, 'subject');
								
								if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
								{
									$average = '';
									$bottotal = '';
									$eottotal = '';
									$grade = '';
									$final_grade = '';
									$sgrade = '';
									$comment = '';
									$initials = '';
								}
								else
								{
									if($bottest == '' and $botexam == ''){
										$bottotal = "";
									}elseif($bottest == '' and $botexam != ''){
										$bottotal = ($botexam*100)/70;
									}elseif($bottest != '' and $botexam == ''){
										$bottotal = "";
									}else{
										$bottotal = ($bottest+$botexam);
									}
										
									if($eottest == '' and $eotexam == ''){
										$eottotal = "";
									}elseif($eottest == '' and $eotexam != ''){
										$eottotal = ($eotexam*100)/70;
									}elseif($eottest != '' and $eotexam == ''){
										$eottotal = "";
									}else{
										$eottotal = ($eottest+$eotexam);
									}
									
									if($bottotal == "" and $eottotal != '')
										$average = number_format(($eottotal));
									elseif($bottotal != "" and $eottotal == '')
										$average = number_format(($bottotal));
									else
										$average = number_format((($bottotal)+($eottotal))/2);
									
									
									$grade = $controller->getGrade($average);
									
									$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
									
									$sgrade = $grades[1];
									
									if($subject->subjectType == 'Subsidiary')
									{
										if($sgrade >= 1 and $sgrade <= 6)
										{
											$final_grade = "O";
										}
										else
										{
											$final_grade = "F";
										}
									}
									else
									{
										$final_grade = $controller->getAlevelGrade($grades[1], 'single');
									}
									
									if($final_grade == '')
										$initials = '';
																		
										$comment = $controller->getaComment($grades[1], 'single');
								}
								
								$teacher = $subject->subjectDescription;
								$initials = "";
								
								
									$words = explode(" ", $teacher);
									
									
									foreach ($words as $w) {
									  $initials .= $w[0];
									}
								
								
								
								if($subject->subjectType != "Core")
								{
									$performance['subject'] = $subject->id;
									$performance['average'] = $average;
									$performance['grade'] = $grade;
									array_push($store['performances'], $performance);
								}
								else
								{
									$core['subject'] = $subject->id;
									$core['average'] = $average;
									$core['grade'] = $grade;
									array_push($subs['cores'], $core);
								}
								
								$parent_to = $controller->getcustomdata("SELECT * FROM subjectpaper WHERE paperParent = '". $subject->id ."'");
								
								if(count($parent_to) > 1)
									$span = count($parent_to);
								else
									$span = $span;
									
								if(count($parent_to) <= 1)
								{
								?>
								<tr>
									<td><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
									<td><?php echo 1;?></td>
									<td><?php echo $bottest;?></td>
                                    <td><?php echo $botexam;?></td>
                                    <!--<td><?php echo $bottotal;?></td>-->
                                    <td><?php echo $eottest;?></td>
									<td><?php echo $eotexam;?></td>
									<!--<td><?php echo $eottotal;?></td>-->
									<td><?php echo $average;?></td>
									<td><?php echo $sgrade;?></td>
									<td>
									<?php 
									if($subject->subjectType == 'Subsidiary')
										echo '';
									else
										echo $final_grade;
									//echo $final_grade;?>
									
									</td>
									<td><?php echo $comment;?></td>
									<td><?php echo $initials;?></td>
								</tr>
                                
								<?php
								
								}
								elseif($span == 2)
								{
									$avrg_grd = 0;
									$countp = 0;
									$i = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											array_push($papers, $grades[1]);
										}
									
										
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else if($span == 3 or $span == 4)
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									
									if($final_grade == '')
										$initials = '';
									
										$comment = $controller->getaComment($papers, $ptype);
									?>
                                    <tr>
                                    	<td rowspan="<?php echo $span+1;?>"><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
										<td class="extra-td"><?php //echo $parent->paperTitle;?></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <!--<td class="extra-td"></td>
                                        <td  class="extra-td"></td>-->
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $final_grade;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $comment;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $initials;?></td>
                                    </tr>
                                    
                                    <?php
									
									
										$countpap = 0;
									
										foreach($papers as $pap){
										
											$countpap++;
										
											if($countpap == 2 and $pap == ''){
												if($final_grade != '')
												{
													if($subject->subjectType == 'Principal'){
														$principals = $principals+($controller->getPoints($final_grade));
													}
													
													if($subject->subjectType == 'Subsidiary')
													{
														$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
														
													}
													
													
												}
											}
										}
									
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
										
										$grade = $controller->getGrade(number_format($average));
										
										$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
										$sgrade = $grades[1];
										}
									?>
                                    	<tr>
                                        	<td><?php echo $parent->paperTitle;?></td>
                                            <td><?php echo $bottest;?></td>
                                            <td><?php echo $botexam;?></td>
                                            <!--<td><?php echo $bottotal;?></td>-->
                                            <td><?php echo $eottest;?></td>
                                            <td><?php echo $eotexam;?></td>
                                            <!--<td><?php echo $eottotal;?></td>-->
                                            <td><?php echo $average;?></td>
                                            <td><?php echo $sgrade;?></td>
                                        </tr>
                                    <?php
									endforeach;
								}
								else if($span == 3)
								{
									$avrg_grd = 0;
									$countp = 0;
									$i = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											array_push($papers, $grades[1]);
										}
									
										
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else if($span == 3 or $span == 4)
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									
									if($final_grade == '')
										$initials = '';
									
										$comment = $controller->getaComment($papers, $ptype);
									?>
                                    <tr>
                                    	<td rowspan="<?php echo $span+1;?>"><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
										<td class="extra-td"><?php //echo $parent->paperTitle;?></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <!--<td class="extra-td"></td>
                                        <td  class="extra-td"></td>-->
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $final_grade;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $comment;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $initials;?></td>
                                    </tr>
                                    
                                    <?php
									
									$countpap = 0;
									
									foreach($papers as $pap){
									
										$countpap++;
									
										if($countpap == 3 and $pap == ''){
											if($final_grade != '')
											{
												if($subject->subjectType == 'Principal'){
													$principals = $principals+($controller->getPoints($final_grade));
												}
												
												if($subject->subjectType == 'Subsidiary')
												{
													$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
													
												}
												
												
											}
										}
									}
									
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
										
										$grade = $controller->getGrade(number_format($average));
										
										$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
										$sgrade = $grades[1];
										}
									?>
                                    	<tr>
                                        	<td><?php echo $parent->paperTitle;?></td>
                                            <td><?php echo $bottest;?></td>
                                            <td><?php echo $botexam;?></td>
                                            <!--<td><?php echo $bottotal;?></td>-->
                                            <td><?php echo $eottest;?></td>
                                            <td><?php echo $eotexam;?></td>
                                            <!--<td><?php echo $eottotal;?></td>-->
                                            <td><?php echo $average;?></td>
                                            <td><?php echo $sgrade;?></td>
                                        </tr>
                                    <?php
									endforeach;
								}
								else
								{
									$avrg_grd = 0;
									$countp = 0;
									$i = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											array_push($papers, $grades[1]);
										}
									
										
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else if($span == 3 or $span == 4)
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									
									if($final_grade == '')
										$initials = '';
									
										$comment = $controller->getaComment($papers, $ptype);
									?>
                                    <tr>
                                    	<td rowspan="<?php echo $span+1;?>"><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
										<td class="extra-td"><?php //echo $parent->paperTitle;?></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <!--<td class="extra-td"></td>
                                        <td  class="extra-td"></td>-->
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $final_grade;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $comment;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $initials;?></td>
                                    </tr>
                                    
                                    <?php
									
									if($span > 3){
										if($final_grade != '')
										{
											if($subject->subjectType == 'Principal'){
												$principals = $principals+($controller->getPoints($final_grade));
											}
											
											if($subject->subjectType == 'Subsidiary')
											{
												$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
												
											}
											
											
										}
									}
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
										
										$grade = $controller->getGrade(number_format($average));
										
										$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
										$sgrade = $grades[1];
										}
									?>
                                    	<tr>
                                        	<td><?php echo $parent->paperTitle;?></td>
                                            <td><?php echo $bottest;?></td>
                                            <td><?php echo $botexam;?></td>
                                            <!--<td><?php echo $bottotal;?></td>-->
                                            <td><?php echo $eottest;?></td>
                                            <td><?php echo $eotexam;?></td>
                                            <!--<td><?php echo $eottotal;?></td>-->
                                            <td><?php echo $average;?></td>
                                            <td><?php echo $sgrade;?></td>
                                        </tr>
                                    <?php
									endforeach;
									
									
								
									
								}
								
								
								
								if($final_grade != '')
								{
									if($subject->subjectType == 'Principal'){
										$principals = $principals+$controller->getPoints($final_grade);
									}
									
									if($subject->subjectType == 'Subsidiary')
									{
										$subsidiaries = $subsidiaries+$controller->getPoints($final_grade);
									}
								}
								
								
								
							endforeach;
							?>
                        </table>
                        
                        <br>
                        <?php
						
						/*$stored = $controller->getPerformance($store['performances'], $subs['cores']);
												
						foreach($stored as $performance):*/
						?>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td></td>
                            	<td align="center">Principal</td>
                                <td align="center">Subsidiary</td>
                                <td align="center">Total</td>
                                <td style="width:10%;"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                            	<td>Points</td>
                                <td style="border:1px solid #000;" align="center"><?php echo number_format($principals);?></td>
                                <td style="border:1px solid #000;" align="center"><?php echo number_format($subsidiaries);?></td>
                                <td style="border:1px solid #000;" align="center"><?php echo number_format($principals+$subsidiaries);?></td>
                                <td></td>
                                <!--<td>Position:</td>
                                <td></td>
                                <td>out of:</td>
                                <td></td>
                                <td>in class:</td>
                                <td></td>-->
                            </tr>
                        </table>
                        <?php
						//endforeach;
						?>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td>Class teacher comments:</td>
                                <td width="80%">......................................................................................................................................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td width="60%"></td>
                            	<td>Signature:</td>
                                <td>....................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <!--<table class="table-no-borders">
                        	<tr>
                            	<td>Outstanding Balance:</td>
                                <td width="80%">......................................................................................................................................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td width="60%"></td>
                            	<td>Signature:</td>
                                <td>....................................................................</td>
                                
                            </tr>
                            
                        </table>-->
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td>Head Teacher Comments:</td>
                                <td width="80%">......................................................................................................................................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td width="60%"></td>
                            	<td>Signature:</td>
                                <td>....................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <!---->
						<div class="row">
							<div class="col-lg-7 col-xs-7">
								<table class="report-table smaller">
										<tr>
											<td>MARKS</td>
											<td>0-34</td>
											<td>35-44</td>
											<td>45-54</td>
											<td>55-59</td>
											<td>60-64</td>
											<td>65-69</td>
											<td>70-74</td>
											<td>75-79</td>
											<td>80-100</td>
										</tr>
										
										<tr>
											<td>GRADE</td>
											<td>F9</td>
											<td>P8</td>
											<td>P7</td>
											<td>C6</td>
											<td>C5</td>
											<td>C4</td>
											<td>C3</td>
											<td>D2</td>
											<td>D1</td>
										</tr>
									</table>
								</div>
								
								<div class="col-lg-5 col-xs-5">
									<table class="report-table smaller">
									
									<tr>
										<td>GRADE</td>
										<td>A</td>
										<td>B</td>
										<td>C</td>
										<td>D</td>
										<td>E</td>
										<td>O</td>
										<td>F</td>
									</tr>
									
									<tr>
										<td>POINTS</td>
										<td>6</td>
										<td>5</td>
										<td>4</td>
										<td>3</td>
										<td>2</td>
										<td>1</td>
										<td>0</td>
									</tr>
								</table>
							</div>
						</div>
                        <br>
                        <div class="clearfix"></div>
                        <button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Report</button>
                        <?php
						endforeach;
					}
					
					else if(isset($_GET['all']) and isset($_GET['year']) and isset($_GET['term']) and isset($_GET['class']))
					{
						$gterm = $_GET['term'];
						$gyear = $_GET['year'];
						$class = $_GET['class'];
						
						$all_students = "select * from students where class = '$class'";
						
						$studentdatas = $controller->getcustomdata($all_students);
						
						$all_stds_num = count($studentdatas);
						
						if($all_stds_num == 0){
							$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
							?>
							<div class="no-print">
							<hr>
							<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
							
							</div>
							<?php
							exit();
						}
						?>
                        <div class="no-print">
                        <button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Reports </button>
                        <hr>
                        </div>
                        <?php
						$countst = 0;
						
						$posdata['positions'] = array();
						$position = array();
						
						foreach($studentdatas as $stdata):
						
							?>
                            <div class="clearfix"></div>
                            <div class="alevel-page-break" id="page-break" style="page-break-after:always;">
                            <?php
						
							$stdidd = $stdata->studentId;
							
							$countst++;
							
							$query = "SELECT * FROM students st, classes cl WHERE st.class = cl.id and st.studentId = '". $stdidd ."'";
						
						$updatedatas = $controller->getcustomdata($query);
						
						foreach($updatedatas as $data):
						
						?>
                        <div class="no-print">
                        <div class="col-lg-11">
                        	<span class="section"><?php echo $data->fname. ' ' .$data->lname;?>'s Report Card</span>
                        </div>
                        <div class="col-lg-1">
                        	<a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger pull-right"><span class="fa fa-long-arrow-left"></span> Return</a>
                        </div>
                        </div>
                        <div class="clearfix"></div>
                        <div class="banner-with-img" style="position:relative;">
                        	<img src="<?php echo $setting->alevelBanner;?>" class="img-responsive">
                            
                            <?php
							$img = "images/user.png";
							
							if($data->photo != '')
							{
								$img = $data->photo;
							}
							?>
                            
                            <div class="profile-pic" style="">
                            	<img src="<?php echo $img;?>" class="img-responsive">
                            </div>
                        </div>
                        <br>
                        <table class="table-no-borders">
                        	<tr>
                            	<td><b>Name:</b> <?php echo $data->fname. ' ' .$data->lname;?></td>
                                <td style="width:49%"></td>
                                <td><b>Admission Number:</b> <?php echo $data->studentNumber;?></td>
                                <td></td>
                            </tr>
                        </table>
                        <table class="table-no-borders">
                            
                            <tr>
                            	<td style="width:50%;"><b>Class:</b> <?php echo $data->className. ' ' .$data->stream;?></td>
                                <td></td>
                                <td><b>Year:</b> <?php echo $gyear;?></td>
                                <td></td>
                                <td><b><?php echo $gterm;?></b></td>
                                <td></td>
                            </tr>
                        </table>
                        <table class="report-table report-card">
							<thead>
                        	<tr>
                            	<td width='26%'>Subject</td>
                                <td>P</td>
                                <td>MoT (30%)</td>
                                <td>MoT (70%)</td>
                                <!--<td>Total</td>-->
                                <td>EoT (30%)</td>
                                <td>EoT (70%)</td>
                                <!--<td>Total</td>-->
                                <td>AVG</td>
                                <td>Grade</td>
                                <td>Final Grade</td>
                                <td width='37%'>Comments</td>
                                <td>Initials</td>
                            </tr>
							</thead>
                            <?php
							$subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level'");
							
							$store['performances'] = array();
							$subs['cores'] = array();
							
							$core = array();
							$performance = array();
							
							$span = 1;
							$principals = 0;
							$subsidiaries = 0;
							
							foreach($subjectdatas as $subject):
								
								$bottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, 'subject');
								$botexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, 'subject');
								$eottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, 'subject');
								$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, 'subject');
								
								if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
								{
									$average = '';
									$bottotal = '';
									$eottotal = '';
									$grade = '';
									$final_grade = '';
									$sgrade = '';
									$comment = '';
									$initials = '';
								}
								else
								{
									if($bottest == '' and $botexam == ''){
										$bottotal = "";
									}elseif($bottest == '' and $botexam != ''){
										$bottotal = ($botexam*100)/70;
									}elseif($bottest != '' and $botexam == ''){
										$bottotal = "";
									}else{
										$bottotal = ($bottest+$botexam);
									}
										
									if($eottest == '' and $eotexam == ''){
										$eottotal = "";
									}elseif($eottest == '' and $eotexam != ''){
										$eottotal = ($eotexam*100)/70;
									}elseif($eottest != '' and $eotexam == ''){
										$eottotal = "";
									}else{
										$eottotal = ($eottest+$eotexam);
									}
									
									if($bottotal == "" and $eottotal != '')
										$average = number_format(($eottotal));
									elseif($bottotal != "" and $eottotal == '')
										$average = number_format(($bottotal));
									else
										$average = number_format((($bottotal)+($eottotal))/2);
									
									
									$grade = $controller->getGrade($average);
									
									$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
									
									$sgrade = $grades[1];
									
									if($subject->subjectType == 'Subsidiary')
									{
										if($sgrade >= 1 and $sgrade <= 6)
										{
											$final_grade = "O";
										}
										else
										{
											$final_grade = "F";
										}
									}
									else
									{
										$final_grade = $controller->getAlevelGrade($grades[1], 'single');
									}
									
									if($final_grade == '')
										$initials = '';
																		
										$comment = $controller->getaComment($grades[1], 'single');
								}
								
								$teacher = $subject->subjectDescription;
								$initials = "";
								
								
									$words = explode(" ", $teacher);
									
									
									foreach ($words as $w) {
									  $initials .= $w[0];
									}
								
								
								
								if($subject->subjectType != "Core")
								{
									$performance['subject'] = $subject->id;
									$performance['average'] = $average;
									$performance['grade'] = $grade;
									array_push($store['performances'], $performance);
								}
								else
								{
									$core['subject'] = $subject->id;
									$core['average'] = $average;
									$core['grade'] = $grade;
									array_push($subs['cores'], $core);
								}
								
								$parent_to = $controller->getcustomdata("SELECT * FROM subjectpaper WHERE paperParent = '". $subject->id ."'");
								
								if(count($parent_to) > 1)
									$span = count($parent_to);
								else
									$span = $span;
									
								if(count($parent_to) <= 1)
								{
								?>
								<tr>
									<td><?php echo $subject->subjectCode.' '. $subject->subjectTitle;?></td>
									<td><?php echo 1;?></td>
									<td><?php echo $bottest;?></td>
                                    <td><?php echo $botexam;?></td>
                                    <!--<td><?php echo $bottotal;?></td>-->
                                    <td><?php echo $eottest;?></td>
									<td><?php echo $eotexam;?></td>
									<!--<td><?php echo $eottotal;?></td>-->
									<td><?php echo $average;?></td>
									<td><?php echo $sgrade;?></td>
									<td>
									<?php 
									if($subject->subjectType == 'Subsidiary')
										echo '';
									else
										echo $final_grade;
									//echo $final_grade;?>
									
									</td>
									<td><?php echo $comment;?></td>
									<td><?php echo $initials;?></td>
								</tr>
                                
								<?php
								
								}
								elseif($span == 2)
								{
									$avrg_grd = 0;
									$countp = 0;
									$i = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											array_push($papers, $grades[1]);
										}
									
										
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else if($span == 3 or $span == 4)
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									
									if($final_grade == '')
										$initials = '';
									
										$comment = $controller->getaComment($papers, $ptype);
									?>
                                    <tr>
                                    	<td rowspan="<?php echo $span+1;?>"><?php echo $subject->subjectCode.' '. $subject->subjectTitle; if($span == 3) echo ' '.$ptype;?></td>
										<td class="extra-td"><?php //echo $parent->paperTitle;?></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <!--<td class="extra-td"></td>
                                        <td  class="extra-td"></td>-->
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $final_grade;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $comment;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $initials;?></td>
                                    </tr>
                                    
                                    <?php
									
									
										$countpap = 0;
									
										foreach($papers as $pap){
										
											$countpap++;
										
											if($countpap == 2 and $pap == ''){
												if($final_grade != '')
												{
													if($subject->subjectType == 'Principal'){
														$principals = $principals+($controller->getPoints($final_grade));
													}
													
													if($subject->subjectType == 'Subsidiary')
													{
														$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
														
													}
													
													
												}
											}
										}
									
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
										
										$grade = $controller->getGrade(number_format($average));
										
										$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
										$sgrade = $grades[1];
										}
									?>
                                    	<tr>
                                        	<td><?php echo $parent->paperTitle;?></td>
                                            <td><?php echo $bottest;?></td>
                                            <td><?php echo $botexam;?></td>
                                            <!--<td><?php echo $bottotal;?></td>-->
                                            <td><?php echo $eottest;?></td>
                                            <td><?php echo $eotexam;?></td>
                                            <!--<td><?php echo $eottotal;?></td>-->
                                            <td><?php echo $average;?></td>
                                            <td><?php echo $sgrade;?></td>
                                        </tr>
                                    <?php
									endforeach;
								}
								else if($span == 3)
								{
									$avrg_grd = 0;
									$countp = 0;
									$i = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											array_push($papers, $grades[1]);
										}
									
										
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else if($span == 3 or $span == 4)
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									
									if($final_grade == '')
										$initials = '';
									
										$comment = $controller->getaComment($papers, $ptype);
									?>
                                    <tr>
                                    	<td rowspan="<?php echo $span+1;?>"><?php echo $subject->subjectCode.' '. $subject->subjectTitle; if($span == 3) echo ' '.$ptype;?></td>
										<td class="extra-td"><?php //echo $parent->paperTitle;?></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <!--<td class="extra-td"></td>
                                        <td  class="extra-td"></td>-->
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $final_grade;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $comment;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $initials;?></td>
                                    </tr>
                                    
                                    <?php
									
									
										$countpap = 0;
									
										foreach($papers as $pap){
										
											$countpap++;
										
											if($countpap == 3 and $pap == ''){
												if($final_grade != '')
												{
													if($subject->subjectType == 'Principal'){
														$principals = $principals+($controller->getPoints($final_grade));
													}
													
													if($subject->subjectType == 'Subsidiary')
													{
														$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
														
													}
													
													
												}
											}
										}
									
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
										
										$grade = $controller->getGrade(number_format($average));
										
										$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
										$sgrade = $grades[1];
										}
									?>
                                    	<tr>
                                        	<td><?php echo $parent->paperTitle;?></td>
                                            <td><?php echo $bottest;?></td>
                                            <td><?php echo $botexam;?></td>
                                            <!--<td><?php echo $bottotal;?></td>-->
                                            <td><?php echo $eottest;?></td>
                                            <td><?php echo $eotexam;?></td>
                                            <!--<td><?php echo $eottotal;?></td>-->
                                            <td><?php echo $average;?></td>
                                            <td><?php echo $sgrade;?></td>
                                        </tr>
                                    <?php
									endforeach;
								}
								else
								{
									$avrg_grd = 0;
									$countp = 0;
									$i = 0;
									
									$papers = array();
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											array_push($papers, '');
										}else{
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
											
											$grade = $controller->getGrade(number_format($average));
											
											$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
											
											array_push($papers, $grades[1]);
										}
									
										
									endforeach;
									
									if($span == 2)
										$ptype = 'double';
									else if($span == 3 or $span == 4)
										$ptype = 'triple';
										
									$final_grade = $controller->getAlevelGrade($papers, $ptype);
									
									if($final_grade == '')
										$initials = '';
									
										$comment = $controller->getaComment($papers, $ptype);
									?>
                                    <tr>
                                    	<td rowspan="<?php echo $span+1;?>"><?php echo $subject->subjectCode.' '. $subject->subjectTitle; if($span == 3) echo ' '.$ptype;?></td>
										<td class="extra-td"><?php //echo $parent->paperTitle;?></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <td class="extra-td"></td>
                                        <!--<td class="extra-td"></td>
                                        <td  class="extra-td"></td>-->
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $final_grade;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $comment;?></td>
                                        <td rowspan="<?php echo $span+1;?>"><?php echo $initials;?></td>
                                    </tr>
                                    
                                    <?php
									
									if($span > 3){
										if($final_grade != '')
										{
											if($subject->subjectType == 'Principal'){
												$principals = $principals+($controller->getPoints($final_grade));
											}
											
											if($subject->subjectType == 'Subsidiary')
											{
												$subsidiaries = $subsidiaries+($controller->getPoints($final_grade));
												
											}
											
											
										}
									}
									
									foreach($parent_to as $parent):
									
										$bottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Test", $gyear, $gterm, 'paper');
										$botexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "BOT Exam", $gyear, $gterm, 'paper');
										$eottest = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Test", $gyear, $gterm, 'paper');
										$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $parent->paperId, "EOT Exam", $gyear, $gterm, 'paper');
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$bottotal = '';
											$eottotal = '';
											$grade = '';
											$final_grade = '';
											$sgrade = '';
											$comment = '';
										}
										else
										{
										
											if($bottest == '' and $botexam == ''){
												$bottotal = "";
											}elseif($bottest == '' and $botexam != ''){
												$bottotal = ($botexam*100)/70;
											}elseif($bottest != '' and $botexam == ''){
												$bottotal = "";
											}else{
												$bottotal = ($bottest+$botexam);
											}
												
											if($eottest == '' and $eotexam == ''){
												$eottotal = "";
											}elseif($eottest == '' and $eotexam != ''){
												$eottotal = ($eotexam*100)/70;
											}elseif($eottest != '' and $eotexam == ''){
												$eottotal = "";
											}else{
												$eottotal = ($eottest+$eotexam);
											}
											
											if($bottotal == "" and $eottotal != '')
												$average = number_format(($eottotal));
											elseif($bottotal != "" and $eottotal == '')
												$average = number_format(($bottotal));
											else
												$average = number_format((($bottotal)+($eottotal))/2);
										
										$grade = $controller->getGrade(number_format($average));
										
										$grades = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $grade);
										$sgrade = $grades[1];
										}
									?>
                                    	<tr>
                                        	<td><?php echo $parent->paperTitle;?></td>
                                            <td><?php echo $bottest;?></td>
                                            <td><?php echo $botexam;?></td>
                                            <!--<td><?php echo $bottotal;?></td>-->
                                            <td><?php echo $eottest;?></td>
                                            <td><?php echo $eotexam;?></td>
                                            <!--<td><?php echo $eottotal;?></td>-->
                                            <td><?php echo $average;?></td>
                                            <td><?php echo $sgrade;?></td>
                                        </tr>
                                    <?php
									endforeach;
									
									
								
									
								}
								
								
								
								if($final_grade != '')
								{
									if($subject->subjectType == 'Principal'){
										$principals = $principals+$controller->getPoints($final_grade);
									}
									
									if($subject->subjectType == 'Subsidiary')
									{
										$subsidiaries = $subsidiaries+$controller->getPoints($final_grade);
									}
								}
								
								
								
							endforeach;
							?>
                        </table>
                        
                        <br>
                        <?php
						
						/*$stored = $controller->getPerformance($store['performances'], $subs['cores']);
												
						foreach($stored as $performance):*/
						?>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td></td>
                            	<td align="center">Principal</td>
                                <td align="center">Subsidiary</td>
                                <td align="center">Total</td>
                                <td style="width:10%;"></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                                <td></td>
                            </tr>
                            <tr>
                            	<td>Points</td>
                                <td style="border:1px solid #000;" align="center"><?php echo number_format($principals);?></td>
                                <td style="border:1px solid #000;" align="center"><?php echo number_format($subsidiaries);?></td>
                                <td style="border:1px solid #000;" align="center"><?php echo number_format($principals+$subsidiaries);?></td>
                                <td></td>
                                <!--<td>Position:</td>
                                <td></td>
                                <td>out of:</td>
                                <td></td>
                                <td>in class:</td>
                                <td></td>-->
                            </tr>
                        </table>
                        <?php
						//endforeach;
						?>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td>Class teacher comments:</td>
                                <td width="80%">......................................................................................................................................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td width="60%"></td>
                            	<td>Signature:</td>
                                <td>....................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <!--<table class="table-no-borders">
                        	<tr>
                            	<td>Outstanding Balance:</td>
                                <td width="80%">......................................................................................................................................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td width="60%"></td>
                            	<td>Signature:</td>
                                <td>....................................................................</td>
                                
                            </tr>
                            
                        </table>-->
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td>Head Teacher Comments:</td>
                                <td width="80%">......................................................................................................................................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <table class="table-no-borders">
                        	<tr>
                            	<td width="60%"></td>
                            	<td>Signature:</td>
                                <td>....................................................................</td>
                                
                            </tr>
                            
                        </table>
                        
                        <!---->
						<div class="row">
							<div class="col-lg-7 col-xs-7">
								<table class="report-table smaller">
										<tr>
											<td>MARKS</td>
											<td>0-34</td>
											<td>35-44</td>
											<td>45-54</td>
											<td>55-59</td>
											<td>60-64</td>
											<td>65-69</td>
											<td>70-74</td>
											<td>75-79</td>
											<td>80-100</td>
										</tr>
										
										<tr>
											<td>GRADE</td>
											<td>F9</td>
											<td>P8</td>
											<td>P7</td>
											<td>C6</td>
											<td>C5</td>
											<td>C4</td>
											<td>C3</td>
											<td>D2</td>
											<td>D1</td>
										</tr>
									</table>
								</div>
								
								<div class="col-lg-5 col-xs-5">
									<table class="report-table smaller">
									
									<tr>
										<td>GRADE</td>
										<td>A</td>
										<td>B</td>
										<td>C</td>
										<td>D</td>
										<td>E</td>
										<td>O</td>
										<td>F</td>
									</tr>
									
									<tr>
										<td>POINTS</td>
										<td>6</td>
										<td>5</td>
										<td>4</td>
										<td>3</td>
										<td>2</td>
										<td>1</td>
										<td>0</td>
									</tr>
								</table>
							</div>
						</div>
                        <br>
                        
                        <?php
						endforeach;
						?>
							<div class="clearfix"></div>
                            </div>
							<div class="clearfix" style="page-break-after:always"></div>
                            
                            <?php	
							
						endforeach;
						
						?>
                        <div class="clearfix"></div>
                        <button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Reports</button>
                        <?php
					}
					else{
					
					
					
					$mclass = '';
					$myear = '';
					$mterm = '';
					if(isset($_GET['year']) and isset($_GET['class']))
				  	{
					  $mclass = $_GET['class'];
					  $myear = $_GET['year'];
					  $mterm = $_GET['term'];
					  
					$sql = "SELECT * FROM students st WHERE st.class = '$mclass'";
					  
				  	}
                 	?>
                    <div class="info"></div>
                    <div class="col-lg-12 col-sm-12">
                    	<p class="text-muted font-13 m-b-30">
                            <div class="row">
                                <form action="" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>
                                    <div class="col-lg-2">
                                        <h4>Filter students</h4>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="text" id="year" name="year" value="<?php echo $myear;?>" placeholder="Select year" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                      <div class="item form-group">
                                            <?php
                                            $terms = array('Term 1', 'Term 2', 'Term 3');
                                            ?>
                                          <select id="term" class="form-control" name="term" required>
                                            <option value="">Select term</option>
                                            <?php
                                            foreach($terms as $term):
                                            ?>
                                                <option <?php if($term == $mterm) echo "Selected";?>><?php echo $term;?></option>                                
                                            <?php
                                            endforeach;
                                            ?>
                                          </select>
                                      </div>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'A Level'");
										?>
									  <select id="class" class="class form-control" name="class" required>
										<option value="">Select class</option>
										<?php
										foreach($classes as $class):
										?>
										
										<option value="<?php echo $class->id;?>" <?php if($class->id == $mclass) echo "Selected";?>><?php echo $class->className;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                    	<div class="btn-group">
                                    		<input type="submit" name="action" value="Filter students" class="btn btn-primary">
                                            <?php
											if(isset($_GET['year'])){
											?>
                                            <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger"><span class="fa fa-times"></span> Cancel filter</a>
											<?php
											}
											?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </p>
                    </div>
                    <!--<div class="col-lg-2 col-sm-12">
                    <p class="text-muted font-13 m-b-30">
                    	
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add marks</a>
                      <div class="clearfix"></div>
                    </p>
                    </div>-->
                    <div class="clearfix"></div>
                    <hr>
                    <?php
					
					if(isset($_GET['year']) and isset($_GET['term'])){
						
					$year = $_GET['year'];
					$term = $_GET['term'];
					
					$all_marks = "select * from amarks where year = '$year' and term = '$term'";
							
					$marksdatas = $controller->getcustomdata($all_marks);
					
					if(count($marksdatas) < 1){
						$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
						?>
						<div class="no-print">
						<hr>
						<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-check"></span> Ok </a>
						
						</div>
						<?php
						exit();
					}
					?>
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <!--<th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>-->
                          <th>Year</th>
                          <th>Term</th>
                          <th>Student Name</th>
                          <th>Student Number</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  
					  $datas = $controller->getcustomdata($sql);
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
					  ?>
                        <tr>
                          <!--<td><input type="checkbox" name="ids[]" value="<?php echo $data->marksId;?>" class="table_records flat "></td>-->
                          <td><?php echo $myear;?></td>
                          <td><?php echo $mterm;?></td>
                          <td><?php echo $data->fname. ' ' .$data->lname;?></td>
                          <td><?php echo $data->studentNumber;?></td>
                          <td><a href="?student=<?php echo $data->studentId;?>&year=<?php echo $myear;?>&term=<?php echo $mterm;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Generate Report</a> </td>
                        </tr>
                        
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                    <div class="clearfix"></div>
                    <a href="?all&year=<?php echo $myear;?>&term=<?php echo $mterm;?>&class=<?php echo $mclass;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Generate All Reports</a>
                    
					</form>
					<?php }?>
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>