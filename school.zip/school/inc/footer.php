<!-- footer content -->
	<?php
	foreach($settings as $setting):
	?>
        <footer>
          <div class="pull-right no-print">
            <?php echo $setting->footerText;?> - Powered by <a href="#">Dreamscom Technologies</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>
    <?php
	endforeach;
	?>

    
    <!-- Bootstrap -->
    <script src="vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="vendors/iCheck/icheck.min.js"></script>
    <!-- Datepicker -->
    <script src="js/datepicker/bootstrap-datepicker.js"></script>
    <!-- FullCalendar-->
    <script src="vendors/moment/min/moment.min.js"></script>
    <script src="vendors/fullcalendar/dist/fullcalendar.min.js"></script> 
    <!-- Datatables -->
    <script src="vendors/datatables.net/js/jquery.dataTables.js"></script>
    <script src="vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="vendors/datatables.net-buttons-bs/js/buttons.bootstrap.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="vendors/datatables.net-scroller/js/datatables.scroller.min.js"></script>
    <script src="vendors/jszip/dist/jszip.min.js"></script>
    <script src="vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="vendors/pdfmake/build/vfs_fonts.js"></script>
    <!-- Select2 -->
    <script src="vendors/select2/dist/js/select2.full.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="build/js/custom.js"></script>
    <!-- Parsley -->
    <script src="vendors/parsleyjs/dist/parsley.min.js"></script>
    
    <script src="jquery.printPage.js" type="text/javascript"></script>

    <!-- FullCalendar -->
    <script>
	
	
      $(window).load(function() {
        var date = new Date(),
            d = date.getDate(),
            m = date.getMonth(),
            y = date.getFullYear(),
            started,
            categoryClass;

        var calendar = $('#calendar').fullCalendar({
          header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay'
          },
          selectable: true,
          selectHelper: true,
          select: function(start, end, allDay) {
            $('#fc_create').click();

            started = start;
            ended = end;

            $(".antosubmit").on("click", function() {
              var title = $("#title").val();
              if (end) {
                ended = end;
              }

              categoryClass = $("#event_type").val();

              if (title) {
                calendar.fullCalendar('renderEvent', {
                    title: title,
                    start: started,
                    end: end,
                    allDay: allDay
                  },
                  true // make the event "stick"
                );
              }

              $('#title').val('');

              calendar.fullCalendar('unselect');

              $('.antoclose').click();

              return false;
            });
          },
          eventClick: function(calEvent, jsEvent, view) {
            $('#fc_edit').click();
            $('#title2').val(calEvent.title);

            categoryClass = $("#event_type").val();

            $(".antosubmit2").on("click", function() {
              calEvent.title = $("#title2").val();

              calendar.fullCalendar('updateEvent', calEvent);
              $('.antoclose2').click();
            });

            calendar.fullCalendar('unselect');
          },
          editable: true,
          events: [{
            title: 'All Day Event',
            start: new Date(y, m, 1)
          }, {
            title: 'Long Event',
            start: new Date(y, m, d - 5),
            end: new Date(y, m, d - 2)
          }]
        });
      });
    </script>
    <!-- /FullCalendar -->

	<!-- Datatables -->
    <script>
      $(document).ready(function() {
        var handleDataTableButtons = function() {
          if ($("#datatable-buttons").length) {
            $("#datatable-buttons").DataTable({
              dom: "Bfrtip",
              buttons: [
                {
                  extend: "copy",
                  className: "btn-sm",
				  exportOptions: {
					  /*columns: [1,2]*/
					  columns: ':visible'
				  }
                },
                {
                  extend: "pdf",
                  className: "btn-sm",
				  exportOptions: {
					  /*columns: [1,2]*/
					  columns: ':visible'
				  }
                },
                {
                  extend: "csv",
                  className: "btn-sm",
				  exportOptions: {
					  /*columns: [1,2]*/
					  columns: ':visible'
				  }
                },
                {
                  extend: "excel",
                  className: "btn-sm",
				  exportOptions: {
					  /*columns: [1,2],*/
					  columns: ':visible'
				  }
                },
                {
                  extend: "print",
                  className: "btn-sm",
				  exportOptions: {
					  /*columns: [1,2]*/
					  columns: ':visible'
				  }
                },
              ],
			  /*columnDefs: [
				  {
					  targets: -1,
					  visible: false
				  },
				  {
					 targets: [0],
					 visible: false
					  
				  }
			  ],*/
              responsive: false
            });
          }
        };

        TableManageButtons = function() {
          "use strict";
          return {
            init: function() {
              handleDataTableButtons();
            }
          };
        }();

        $('#datatable').dataTable();
        $('#datatable-keytable').DataTable({
          keys: true
        });

        $('#datatable-responsive').DataTable();

        $('#datatable-scroller').DataTable({
          ajax: "js/datatables/json/scroller-demo.json",
          deferRender: true,
          scrollY: 380,
          scrollCollapse: true,
          scroller: true
        });

        var table = $('#datatable-fixed-header').DataTable({
          fixedHeader: true
        });

        TableManageButtons.init();
      });
    </script>
    <!-- /Datatables -->
    
    <!--Datepicker-->
    <script type="text/javascript">
		$("#dob").datepicker({
			autoclose: true,
			format: "yyyy-mm-dd",
			endDate: "-4015d"
			
		});
	</script>
	
	<script type="text/javascript">
		$("#begin").datepicker({
			autoclose: true,
			format: "dd MM yyyy"
			
		});
	</script>
	
	<script type="text/javascript">
		$("#end").datepicker({
			autoclose: true,
			format: "dd MM yyyy"
			
		});
	</script>
    
    <script type="text/javascript">
		$("#year").datepicker({
			autoclose: true,
			format: "yyyy",
			viewMode: 'years', 
			minViewMode: "years"
			
		});
	</script>
    
    <script type="text/javascript">
		$("#yearex").datepicker({
			autoclose: true,
			format: "yyyy",
			viewMode: 'years', 
			minViewMode: "years"
			
		});
		
		
	</script>
    
    <script>
      $(document).ready(function() {
        $(".subject").select2({
          placeholder: "Select a subject",
          allowClear: true,
		  dropdownAutoWidth: true,
		  autoWidth: true
        });
		$(".teachers").select2({
          placeholder: "Select a teacher",
          allowClear: true,
		  dropdownAutoWidth: true,
		  autoWidth: true
        });
		$(".stdno").select2({
          placeholder: "Select student number",
          allowClear: true
        });
        $(".select2_group").select2({});
        $(".select2_multiple").select2({
          maximumSelectionLength: 10,
          placeholder: "Select subjects",
          allowClear: true
        });
      });
    </script>
    
    <!-- validator 
    <script>
      // initialize the validator function
      validator.message.date = 'not a real date';

      // validate a field on "blur" event, a 'select' on 'change' event & a '.reuired' classed multifield on 'keyup':
      $('form')
        .on('blur', 'input[required], input.optional, select.required', validator.checkField)
        .on('change', 'select.required', validator.checkField)
        .on('keypress', 'input[required][pattern]', validator.keypress);

      $('.multi.required').on('keyup blur', 'input', function() {
        validator.checkField.apply($(this).siblings().last()[0]);
      });

      $('form').submit(function(e) {
        e.preventDefault();
        var submit = true;

        // evaluate the form using generic validaing
        if (!validator.checkAll($(this))) {
          submit = false;
        }

        if (submit)
          this.submit();

        return false;
      });
    </script>
    <!-- /validator -->
    
    
  </body>
</html>