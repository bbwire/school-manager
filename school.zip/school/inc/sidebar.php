<!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>Admin</h3>
                <ul class="nav side-menu">
                	<li><a href="./"><i class="fa fa-home"></i> Dashboard </a></li>
                    <!--<li><a href="users.php"><i class="fa fa-user"></i> Users </a></li>-->
                    
                  	<li><a><i class="fa fa-book"></i> Academics <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                          <li><a href="students.php">Students</a></li>
                          <li><a href="library.php">Library</a></li>
                          <li><a href="classes.php">Classes</a></li>
                          <li><a href="#">Subjects <span class="fa fa-chevron-down"></span></a>
                          	 <ul class="nav child_menu">
                                <li class="sub_menu"><a href="subjects.php">Main Subjects</a>
                                </li>
                                <li><a href="subject-papers.php">Subject Papers</a>
								<li><a href="subject-teachers.php">Subject Teachers</a>
                                </li>
                              </ul>
                          </li>
                          <li><a href="#">Marks <span class="fa fa-chevron-down"></span></a>
                          	<ul class="nav child_menu">
                                <li class="sub_menu"><a href="marks.php">O Level</a>
                                </li>
                                <li><a href="alevel-marks.php">A Level</a>
                                </li>
                              </ul>
                          </li>
                          <li><a href="#">Report Card Generator <span class="fa fa-chevron-down"></span></a>
                          	<ul class="nav child_menu">
                                <li class="sub_menu"><a href="students-report.php">O Level</a>
                                </li>
                                <li><a href="alevel-report.php">A Level</a>
                                </li>
                              </ul>
                          </li>
						  <li><a href="#">O Level Performance <span class="fa fa-chevron-down"></span></a>
                          	 <ul class="nav child_menu">
                                <li class="sub_menu"><a href="subject-performance.php">Subject Performance</a>
                                </li>
								<li><a href="performance-summary.php">Class Performance Summary</a>
                                </li>
								<li><a href="division-summary.php">General Performance Summary</a>
                                </li>
                              </ul>
                          </li>
                          
						  <li><a href="#">A Level Performance <span class="fa fa-chevron-down"></span></a>
                          	 <ul class="nav child_menu">
                                <!--<li class="sub_menu"><a href="subject-performance.php">Subject Performance</a>
                                </li>-->
								<li><a href="alevel-performance-summary.php">Class Performance Summary</a>
                                </li>
								<!--<li><a href="division-summary.php">General Performance Summary</a>
                                </li>-->
                              </ul>
                          </li>
                          <!--<li><a href="#">Parents</a></li>
                          <li><a href="assignments.php">Assignments</a></li>-->
                        </ul>
                      </li>
                  	<li><a><i class="fa fa-cogs"></i> Administrative <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                    	<li><a href="users.php">Users</a></li>
                      	<li><a href="settings.php">Settings</a></li>
                      	<li><a href="districts.php">Districts</a></li>
                      	<li><a href="counties.php">Counties</a></li>
                      	<li><a href="#">Grading</a>
                        	<ul class="nav child_menu">
                                <li class="sub_menu"><a href="grades.php">O Level Grading</a>
                                </li>
                                <li><a href="alevel-grades.php">A Level Grading</a>
                                </li>
                              </ul>
                        </li>
                        <li><a href="divisions.php">Divisions</a></li>
                        <li><a href="assign-subjects.php">Subjects to teachers</a></li>
                    </ul>
                  </li>                  
                </ul>
              </div>
              

            </div>
            <!-- /sidebar menu -->

            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a href="settings.php" data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a href="profile.php" data-toggle="tooltip" data-placement="top" title="Profile">
                <span class="fa fa-user" aria-hidden="true"></span>
              </a>
              <a href="logout.php" data-toggle="tooltip" data-placement="top" title="Logout">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>