<?php
if(isset($_SESSION['user'])){
	require_once ("application/controller/". $class .".php");
	
	$controller = new $class();
	
	$settings = $controller->getdata("settings", "id", "asc");
	
	$users = $controller->getuser();
	
	$uid = $controller->userid();
}
else
{
	header("location:logout.php");
}

foreach($settings as $setting):

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<?php
	
	$page = basename($_SERVER['PHP_SELF']);
	
	$split_page = explode('.', $page);
	
	$this_page = $split_page[0];
	?>
    <title><?php echo $setting->siteTitle;?> | <?php echo $this_page;?> </title>

    <!-- Bootstrap -->
    <link href="vendors/bootstrap/dist/css/bootstrap.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="vendors/iCheck/skins/flat/green.css" rel="stylesheet">
    <!-- bootstrap-progressbar -->
    <link href="vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet">
    <!-- Callendar -->
    <link href="vendors/fullcalendar/dist/fullcalendar.min.css" rel="stylesheet">
    <link href="vendors/fullcalendar/dist/fullcalendar.print.css" rel="stylesheet" media="print">
    <!-- jVectorMap -->
    <link href="css/maps/jquery-jvectormap-2.0.3.css" rel="stylesheet"/>
    <!-- Datepicker -->
    <link href="css/datepicker/datepicker3.css" rel="stylesheet"/>
    <!-- Datatables -->
    <link href="vendors/datatables.net-bs/css/dataTables.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css" rel="stylesheet">
    <link href="vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css" rel="stylesheet">
    <!-- Select2 -->
    <link href="vendors/select2/dist/css/select2.min.css" rel="stylesheet">

    <!-- Custom Theme Style -->
    <link href="build/css/custom.css" rel="stylesheet">
    
    <!-- jQuery -->
    <script src="vendors/jquery/dist/jquery.min.js"></script>
    
    
    
    <script type="text/javascript">
		function delete_confirm(){
			var result = confirm("Are you sure to delete multiple records?");
			if(result){
				return true;
			}else{
				return false;
			}
		}
	
	
	</script>
        
        <script type="text/javascript">
			$(document).ready(function(e) {
                $("button[name='deletemulti']").click(function(){
					var check = $("td input:checkbox.flat:checked").val();
					
					if(!check){
						$("div.info").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please select record(s) to delete</div>'); 
						return false;
					}else{
						$("div.info").html('');
					}
				});
				
				$("td input:checkbox").on("ifChecked", function(event){
					$("div.info").html('');
				});
            });
		</script>
    
    <script type="text/javascript">
		$(document).ready(function() {
            
			var level = $("#study_level_update select[name='level']").val();
			
			
			if(level === 'A Level')
			{
				$("#a_level_show_update").show();
			}
			else
			{
				$("#a_level_show_update").hide();
			}
			
			$("#combination").click(function(){
				var prone = $('select[name="ps1"] option:selected').html().substring(0,1);
				var prtwo = $('select[name="ps2"] option:selected').html().substring(0,1);
				var prthree = $('select[name="ps3"] option:selected').html().substring(0,1);
				var subsid = $('select[name="sub"] option:selected').html();
				
				if(subsid === 'Subsidiary Computer Studies')
					var code = 'CST';
				else if(subsid === 'Subsidiary Mathematics')
					var code = 'SMA';
				
				$(this).val(prone+prtwo+prthree+'/'+code);
			});
			
			$("#combinationup").click(function(){
				var prone = $('select[name="ps1"]#psone option:selected').html().substring(0,1);
				var prtwo = $('select[name="ps2"]#pstwo option:selected').html().substring(0,1);
				var prthree = $('select[name="ps3"]#psthree option:selected').html().substring(0,1);
				var subsid = $('select[name="sub"]#subsi option:selected').html();
				
				if(subsid === 'Subsidiary Computer Studies')
					var code = 'CST';
				else if(subsid === 'Subsidiary Mathematics')
					var code = 'SMA';
				
				$(this).val(prone+prtwo+prthree+'/'+code);
			});
			
        });
	</script>
    
    <script type="text/javascript">

		$(document).ready(function() {
			
			$(".level").click(function() {
			   
				//$(this).after('<div id="loader"><img src="img/loading.gif" alt="loading subcategory" /></div>');
				$.get('ajax.php?clas=' + $(this).val(), function(data) {
					$("#class").html(data);
					$('#loader').slideUp(200, function() {
						$(this).remove();
					});
				});	
			});
		
		});
		
		$(document).ready(function() {
			
			$("#level").click(function() {
			   
				//$(this).after('<div id="loader"><img src="img/loading.gif" alt="loading subcategory" /></div>');
				$.get('ajax.php?subjec=' + $(this).val(), function(data) {
					$("#subject").html(data);
					$('#loader').slideUp(200, function() {
						$(this).remove();
					});
				});	
			});
		
		});
		
		$(document).ready(function() {
			
			$("#district").click(function() {
			   
				//$(this).after('<div id="loader"><img src="img/loading.gif" alt="loading subcategory" /></div>');
				$.get('ajax.php?parent=' + $(this).val(), function(data) {
					$("#county").html(data);
					$('#loader').slideUp(200, function() {
						$(this).remove();
					});
				});	
			});
		
		});
		
		$(document).ready(function(e) {
            $('select[name="subject"].sub').change(function(){
				//var level = $(this).val();
				
				$.get('ajax.php?sub=' + $(this).val(), function(data) {
					$("#paper").html(data);
					$('#loader').slideUp(200, function() {
						$(this).remove();
					});
				});
			});
			
			$('select[name="subject"].xsub').change(function(){
				//var level = $(this).val();
				
				$.get('ajax.php?sub=' + $(this).val(), function(data) {
					$("#paper1").html(data);
					$('#loader').slideUp(200, function() {
						$(this).remove();
					});
				});
			});
        });
		
		</script>
        
        <script type="text/javascript">


			$(document).ready(function() {
			
			$("#stdno").click(function() {
			   
			   var gender = $('.gender input[name="gender"]:checked').val();
			   
			   var classe = $('select[name="class"] option:selected').val();
				
			   //alert(classe);			   
				
				if(!gender)
				{					
					$("div#output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please select gender to generate student number</div>'); 
					return false; 
				}
				else if(classe == '')
				{
					$("div#output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please select class to generate student number</div>'); 
					return false; 
				}
				else
				{					
					$("div#output").html('');
					
					var dat = new Date();
					
					var year = dat.getFullYear();
					
					var dats = ""+year;
					
					var date = dats.substring(2,4);
					
					var genders = gender.substring(0,1);
					
					var prefix = '';
					
					if ($('#study_level select[name="level"] option:selected').hasClass('a-level')){
						
						prefix = "A";
					}
					
					var string = prefix+date+"/";
					
					//$(this).val(string);
					$.get('ajax.php?class='+classe+'&gender='+gender, function(data) {
						
						$("#stdno").val(string+data);
						
					});
				}	
			});
		
		});
		
		</script>
        
        <script type="text/javascript">
			$(document).ready(function() {
			  	$('#genders input:radio').on('ifChecked', function(event){
				  $('#stdno').val('');
				});
			});
		</script>
    
    <script type="text/javascript">
		
		$(document).ready(function() {
			
			$('select[name="level"]').change(function(){
				var level = $(this).val();
				
				if(level === 'O Level')
				{
					$('#type #alevel').hide()
					$('#type #olevel').show()
				}
				else if(level == 'A Level')
				{
					$('#type #olevel').hide()
					$('#type #alevel').show()
				}
				
				$('select[name="type"] option').prop('selected', function() {
						return this.defaultSelected;
					});
			});
			
			//var level = $('select[name="level"] option:selected').val();
			
			$('select[name="class"]').change(function(){
				$('#stdno').val('');
			});
			
			$("#a_level_show").hide();
			$("#a").hide();
			$("#s").hide();
			$("#north").show();
			$("#south").show();
			$("#alevel5").hide();
			$("#alevel6").hide();
			$("#alevelx5").hide();
			$("#alevelx6").hide();
			
			$('#study_level select[name="level"]').change(function () {
				
				$('#stdno').val('');
				
				$('select[name="class"] option').prop('selected', function() {
					return this.defaultSelected;
				});
				
				if ($('#study_level select[name="level"] option:selected').hasClass('a-level')) {
					//$('#a_level_show').show();
					 //alert($(this).val());
				  //$("#a_level_show").show();
					$('#a_level_show').show(400);
					
					$("#north").hide();
					$("#south").hide();
					$("#a").show();
					$("#s").show();
					$("#olevel1").hide();
					$("#olevel2").hide();
					$("#olevel3").hide();
					$("#olevel4").hide();
					$("#alevel5").show();
					$("#alevel6").show();
					
					$('#class_stream').show(400);
					
					$('#class_stream select[name="stream"] option').prop('selected', function() {
						return this.defaultSelected;
					});
					
					
					
					
				} else {
					
					$('#a_level_show').hide(400);
					$("#combination").val("");
					$("#a").hide();
					$("#s").hide();
					$("#north").show();
					$("#south").show();
					$("#olevel1").show();
					$("#olevel2").show();
					$("#olevel3").show();
					$("#olevel4").show();
					$("#alevel5").hide();
					$("#alevel6").hide();
					
					$('#class_stream').show(400);
					
					$('#class_stream select[name="stream"] option').prop('selected', function() {
						return this.defaultSelected;
					});
					
					
				}
				
			});
			
			
			
		});
	</script>
	<script>
		$(document).ready(function(){
			$("#sendexcel").click(function(){
				var excel = $("#excelfile").val();
				var level = $("#levelex").val();
				var classx = $("#classex").val();
				
				if(level == '' || classx == '')
				{
					$("div.output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Level and class are mandatory please!</div>'); 
					return false; 
				}
				
				else if(excel == '')
				{
					$("div.output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please choose the excel file to upload</div>'); 
					return false; 
				}
			});
			
			$("#alevelx5").hide();
			$("#alevelx6").hide();
			
			$('#study_level select[name="level"]').change(function () {
				
				$('#stdno').val('');
				
				$('select[name="class"] option').prop('selected', function() {
					return this.defaultSelected;
				});
				
				if ($('.xlevel select[name="level"] option:selected').hasClass('a-level')) {
					//$('#a_level_show').show();
					 //alert($(this).val());
				  //$("#a_level_show").show();
					$("#olevelx1").hide();
					$("#olevelx2").hide();
					$("#olevelx3").hide();
					$("#olevelx4").hide();
					$("#alevelx5").show();
					$("#alevelx6").show();
					
					$('select[name="class"]#classx  option').prop('selected', function() {
						return this.defaultSelected;
					});
					
				} else {
					
					$("#olevelx1").show();
					$("#olevelx2").show();
					$("#olevelx3").show();
					$("#olevelx4").show();
					$("#alevelx5").hide();
					$("#alevelx6").hide();
					
					
					$('select[name="class"]#classx option').prop('selected', function() {
						return this.defaultSelected;
					});
				}
				
			});
			
			$("#sendxmarks").click(function(){
				var file = $("#filexmarks").val();
				var yearx = $("#yearex").val();
				var term = $(".xmarks #term").val();
				var classx = $(".xmarks #class").val();
				var subject = $(".xmarks #subject").val();
				var type = $(".xmarks #type").val();
				
				if(yearx === '' || term === '' || classx === '' || subject === '' || type === '')
				{
					$(".output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please fill all the required information</div>')
					return false;
				}
				else if(file == ''){
					$(".output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Please choose a file to upload</div>')
					return false;
				}
			});
			
		});
	</script>
    <script>
		$(document).ready(function(){
			$("#updatepas").click(function(){
				
				var pass = $("#pass").val();
				var cpass = $("#cpass").val();
				
				if(pass != cpass){
					$(".output").html('<div class="alert alert-danger alert-dismissable no-print"><i class="fa fa-check"></i>			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button> Your new passwords do not match </div>')
					return false;
				}
			});
		});
	</script>
    <style>
		
		.profile-pic{
			position:absolute; 
			top:6%; 
			right:0%; 
			width:8.5%; 
			height:auto;
		}
		
		.report-water{
			position:relative;
		}
		
		.report-water img.water-img{
			position:absolute;
			top:10px;
			left:30%;
			z-index:1;
			max-width:400px;
			height:auto;
		}
		
		.report-water table.report-table{
			z-index:2;
			position:relative;
		}
		
		.report-table {
			width:100%;
		}
		.report-table td{
			border:1px solid #111;
			padding:1px 5px 1px 5px;
			font-size:16px;
			color:#111;
		}
		
		.report-table.smaller td{
			border:1px solid #111;
			padding:2px 5px 2px 5px;
			font-size:16px;
			color:#111;
		}
		
		.report-table.smaller{
			margin-bottom:6px;
		}
		
		.report-table thead td{
			font-weight:bold;
			font-size:13px;
			padding:6px;
		}
		
		.report-table.report-card{
			background:url(images/Intensive_logo.jpg) center center no-repeat;
			
		}
		
		.report-table.report-card-olevo{
			background:url(images/Intensive_logo_levelo.jpg) center center no-repeat;
			
		}
		
		.table-no-borders{
			width:100%;
			margin-bottom:12px;
			font-size:16px;
			color:#111;
		}
		
		.table-borders{
			width:100%;
			margin-bottom:12px;
			margin-top:1px;
			font-size:16px;
			color:#111;
			border:1px solid #222;
			border-top:3px solid #222;
			border-bottom:3px solid #222;
		}
		
		.table-borders td{
			padding:3px;
			text-transform:uppercase;
		}
		
		.table-borders td span.blue{
			color:#0e63c2;
			font-weight:bold;
		}
		
		.table-borders td span.red{
			color:#d41515;
			font-weight:bold;
		}
		
		.table-borders-top-bottom{
			width:100%;
			margin-bottom:12px;
			margin-top:1px;
			font-size:16px;
			color:#111;
			border-top:2px solid #222;
			border-bottom:3px solid #222;
		}
		
		.table-borders-top-bottom td{
			padding:3px;
			width:10%;
		}
		
		.table-borders-top-bottom td:nth-child(even){
			font-weight:bold;
		}
		
		table td.extra-td{
			padding:0; 
			border-bottom-color:#fff; border-top-color:#fff
		}
		@media print{
			.no-print{
				display:none;
			}
			.x_panel {
				border:none;
			}
			
			.report-water{
				position:relative;
			}
			
			.report-water img.water-img{
				position:absolute;
				top:10px;
				left:30%;
				max-width:350px;
				height:auto;
				display:block important;
			}
			
			body {
			  -webkit-print-color-adjust: exact;
			}
			
			.report-water table.report-table{
				z-index:2;
				position:relative;
				background:none !important;
			}
			
			.report-table.report-card{
				background:url(images/Intensive_logo.jpg) center center no-repeat !important;
				-webkit-print-color-adjust: exact;
				
			}
			
			.report-table.report-card-olevo{
				background:url(images/Intensive_logo_levelo.jpg) center center no-repeat !important;
				-webkit-print-color-adjust: exact;
				
			}
			
			.report-table.report-card-olevo.print{
				
				
			}
			
			.profile-pic{
				position:absolute; 
				top:6%; 
				right:0%; 
				width:8.5%; 
				height:auto;
			}
			.report-table {
				width:100%;
				margin-bottom:10px;
			}
			.report-table td{
				border:1px solid #111;
				padding:5px;
				font-size:16px;
				color:#111;
			}
			
		
			.table-borders td span.blue{
				color:#0e63c2;
				font-weight:bold;
				-webkit-print-color-adjust: exact;
			}
			
			.table-borders td span.red{
				color:#d41515;
				font-weight:bold;
				-webkit-print-color-adjust: exact;
			}
			table td.extra-td{
				padding:0; 
				border-bottom-color:#fff !important; border-top-color:#fff !important;
			}
			
			
			.right_col, .x_panel, .x_content, .col-md-12.col-sm-12.col-xs-12{
				float:none;
			}
		}
		
		.page-break{
			margin-bottom:100px;
			clear:both;
		}
		
		.alevel-page-break{
			margin-bottom:100px;
			clear:both;
		}
		
		.page-break::after{
			content: "";
			clear: both;
			display: table;
		}
		
		.page-break::before{
			content: "";
			clear: both;
			display: table;
		}
		
		.right_col, .x_panel, .x_content, .col-md-12.col-sm-12.col-xs-12{
			float:none !important;
		}
		
		td.rotate {
			  /* Something you can count on */
			  height: 140px;
			  white-space: nowrap;
			}
			
			td.rotate > div {
			  transform: 
				/* Magic Numbers */
				translate(0px, 50px)
				/* 45 is really 360 - 45 */
				rotate(270deg);
				
				-moz-transform: 
				/* Magic Numbers */
				translate(0px, 50px)
				/* 45 is really 360 - 45 */
				rotate(270deg);
				
				-ms-transform: 
				/* Magic Numbers */
				translate(0px, 50px)
				/* 45 is really 360 - 45 */
				rotate(270deg);
				
				-webkit-transform: 
				/* Magic Numbers */
				translate(0px, 50px)
				/* 45 is really 360 - 45 */
				rotate(270deg);
				
			  width: 30px;
			}
			td.rotate > div > span {
			  padding: 0px 0px;
			}
	</style>
    <style media="print">
		.page-break{
			page-break-after: always !important;
			clear:both !important;
			display:block;
			margin-bottom:458.5px !important;
		}
		
		
		.alevel-page-break{
			page-break-after: always !important;
			clear:both !important;
			display:block;
			margin-bottom:125px !important;
		}
		
		
		table.report{
			page-break-after:always !important;
			clear:both;
			display:block;
		}
		
		.right_col, .x_panel, .x_content, .col-md-12.col-sm-12.col-xs-12{
			float:none !important;
			clear:both;
		}
	</style>
  </head>

  <body class="nav-md">
  	<div class="banner no-print" style="background:#fff; padding:10px 0;">
    	<img src="<?php echo $setting->siteLogo;?>" class="img-responsive">
    </div>
	<div class="clearfix"></div>
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="./" class="site_title"><i class="fa fa-paw"></i> <span><?php echo $setting->siteTitle;?></span></a>
            </div>
			
			<?php 
			
			?>

            <div class="clearfix"></div>

            <!-- menu profile quick info -->
            <?php
			foreach($users as $user):
			
			if($user->photo == '')
			{
				$img = "images/img.jpg";
			}
			else
			{
				$img = $user->photo;
			}
			?>
            <div class="profile">
              <div class="profile_pic">
                <img src="<?php echo $img;?>" alt="<?php echo $user->fname.' '.$user->lname;?>" title="<?php echo $user->fname.' '.$user->lname;?>" class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo $user->fname.' '.$user->lname;?></h2>
              </div>
            </div>
            <?php
			endforeach;
			?>
<?php
endforeach;
?>
            <!-- /menu profile quick info -->

            <br />