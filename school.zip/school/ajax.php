<?php
    include 'application/controller/Controller.php';
	
	$controller = new Controller();
	
	if(isset($_GET['class']) and isset($_GET['gender']))
	{
		$class = $_GET['class'];
		
		$gender = $_GET['gender'];
		
		if($gender == 'Male')
			$genders = 'B';	
		else
			$genders = 'G';	
		
		$datas = $controller->getcustomdata("SELECT studentId, studentNumber, class, gender FROM students WHERE class = '$class' and gender = '$gender' ORDER BY studentId DESC LIMIT 1");
		
		if(count($datas) > 0)
		{
			foreach($datas as $data)
			{
				$std = $data->studentNumber;
				
				$explode = explode("/", $std);
				
				if(count($explode) == 2)
				{				
					$stdno = $explode[1];
				}
				else
				{
					$stdno = $explode[2];
				}
				
				$stdno = preg_split('/(?<=[A-Z])(?=[0-9]+)/i', $stdno);
				
				$stdno = $stdno[1];
				
				$stdno = $stdno+1;
				
				$student = "00".$stdno;
				
				if($stdno > 9)
				{
					$student = "0".$stdno;
				}
				
				echo $genders . $student;			
			}
		}
		else
		{
			echo $genders ."001";
		}
	}
	
	if(isset($_GET['parent']))
	{
		$did = $_GET['parent'];
		$datas = $controller->getindividual("county", "districtId", $did);
		
		foreach($datas as $data)
		{
			echo "<option value='". $data->countyId ."'>". $data->countyName ."</option>";			
		}
	}
	
	if(isset($_GET['sub']))
	{
		$sid = $_GET['sub'];
		$datas = $controller->getindividual("subjectpaper", "paperParent", $sid);
		
		if(count($datas) < 1)
		{
			echo "<option value='no'>Has no paper</option>";	
		}
		else
		{
			foreach($datas as $data)
			{
				echo "<option value='". $data->paperId ."'>Paper ". $data->paperTitle ."</option>";			
			}
		}
	}
	if(isset($_GET['clas']))
	{
		$classid = $_GET['clas'];
		$datas = $controller->getindividual("classes", "classLevel", $classid);
		
		foreach($datas as $data)
		{
			echo "<option value='". $data->id ."'>". $data->className ."</option>";			
		}
	}
	if(isset($_GET['subjec']))
	{
		$sublevel = $_GET['subjec'];
		$datas = $controller->getindividual("subject", "subjectLevel", $sublevel);
		
		foreach($datas as $data)
		{
			echo "<option value='". $data->id ."'>". $data->subjectTitle ."</option>";			
		}
	}
	
?>