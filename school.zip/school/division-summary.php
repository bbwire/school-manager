		<?php
		require_once ("inc/essentials.php");
		
		$class = "StudentsController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12" style="float:none">
              <div class="x_panel">
                  <div class="x_title no-print">
                    <h2>O Level Performance Summary </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
					if(isset($_GET['year']) and isset($_GET['term'])){
						
							$gterm = $_GET['term'];
							$gyear = $_GET['year'];
							
							$all_divisions = "SELECT * FROM marks WHERE year = '$gyear' AND term = '$gterm'";
							
							$divisiondatas = $controller->getcustomdata($all_divisions);
							
							if(count($divisiondatas) < 1){
								$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
								?>
								<div class="no-print">
								<hr>
								<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
								
								</div>
								<?php
								exit();
							}
						
							$all_classes = "SELECT * FROM classes WHERE classLevel = 'O Level'";
							
							$classdatas = $controller->getcustomdata($all_classes);
							
							
							if(count($classdatas) == 0){
								$controller->model->Alert("alert-danger", "Sorry, there are no records for this query");
								?>
								<div class="no-print">
								<hr>
								<a class="btn btn-primary no-print" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
								
								</div>
								<?php
								exit();
							}
							
							
							?>		
							<table class="report-table">
								<tr>
									<td>CLASS</td>
									<td>DIVISION 1</div>
									<td>DIVISION 2</td>
									<td>DIVISION 3</td>
									<td>DIVISION 4</td>
									<td>DIVISION 7</td>
									<td>DIVISION 9</td>
									<td>TOTAL</td>
								</tr>
							<?php
							?>
							<div class="no-print">
							<button class="btn btn-primary no-print" onClick="print();"><span class="fa fa-print"></span> Print Reports </button>
							<a class="btn btn-primary no-print pull-right" href="<?php echo basename($_SERVER['PHP_SELF']);?>" ><span class="fa fa-long-arrow-left"></span> Go back </a>
							<hr>
							</div>
							<?php
							foreach($classdatas as $cdata):
							
							
							$class = $cdata->id;
							
							$all_students = "SELECT * FROM students WHERE class = '$class'";
							
							$studentdatas = $controller->getcustomdata($all_students);
							
							$all_stds_num = count($studentdatas);
							
							$div1 = 0;
							$div2 = 0;
							$div3 = 0;
							$div4 = 0;
							$div7 = 0;
							$div9 = 0;
							$totl = 0;
							
							$posdata['positions'] = array();
							$position = array();
							$store['performsum'] = array();
							$psum = array();
							foreach($studentdatas as $data):
								
									$subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'O Level'");
									
									$store['performances'] = array();
									
									$subs['cores'] = array();
									
									$core = array();
									$performance = array();
									
									$ttlmrk = 0;
									$ttavrge = 0;
									$countavail = 0;
									$countst = 0;
									$td = null;
									foreach($subjectdatas as $subject):
										$countst++;
										$bottest = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, '');
										$botexam = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, '');
										$eottest = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, '');
										$eotexam = $controller->getTheScore("marks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, '');
										
										if($bottest == '' and $botexam == '' and $eottest == '' and $eotexam == '')
										{
											$average = '';
											$total = '';
										}
										elseif($bottest == '' and $botexam == '' and $eottest == '' and $eotexam != '')
										{
											$average = number_format(($eotexam*100)/70);
											$total = ($eotexam*100)/70;
											$countavail++;
										}
										elseif($bottest == '' and $botexam != '' and $eottest == '' and $eotexam != '')
										{
											$botexam = ($botexam*100)/70;
											$eotexam = ($eotexam*100)/70;
											$average = number_format(($eotexam+$botexam)/2);
											$total = ($eotexam+$botexam);
											$countavail++;
										}
										elseif($bottest != '' and $botexam != '' and $eottest == '' and $eotexam == '')
										{
											$average = number_format(($bottest+$botexam));
											$total = ($bottest+$botexam);
											$countavail++;
										}
										elseif($bottest == '' and $botexam == '' and $eottest != '' and $eotexam != '')
										{
											$average = number_format(($eottest+$eotexam));
											$total = ($eottest+$eotexam);
											$countavail++;
										}
										elseif($bottest != '' and $botexam != '' and $eottest == '' and $eotexam != '')
										{
											$botttl = ($bottest+$botexam);
											$eotttl = ($eotexam*100)/70;
											$average = number_format(($eotttl+$botttl)/2);
											$total = ($eotttl+$botttl);
											$countavail++;
										}
										elseif($bottest == '' and $botexam != '' and $eottest != '' and $eotexam != '')
										{
											$botttl = ($botexam*100)/70;
											$eotttl = ($eotexam+$eottest);
											$average = number_format(($eotttl+$botttl)/2);
											$total = ($eotttl+$botttl);
											$countavail++;
										}
										else
										{
											$average = number_format((($bottest+$botexam)+($eottest+$eotexam))/2);
											
											$total = (($bottest+$botexam)+($eottest+$eotexam));
											$countavail++;
										}
										
										if($average != '')
										{
											$grade = $controller->getGrade($average);
											$comment = $controller->getComment("grades", $average);
										}
										else
										{
											$grade = '';
											$comment = '';
											$initials = '';
										}
										
										if($grade == ''){
											$initials = '';
										}
										else
										{
											$ttavrge = $ttavrge+$average;
											$ttlmrk = $ttlmrk+$total;
											
											$initials = $controller->getInitials($class, $subject->id);
										}
										
										
										if($subject->subjectType != "Core")
										{
											if($grade != '')
											{
												$performance['subject'] = $subject->id;
												$performance['average'] = $average;
												$performance['grade'] = $grade;
												array_push($store['performances'], $performance);
											}
										}
										else
										{
											if($grade != '')
											{
												$core['subject'] = $subject->id;
												$core['average'] = $average;
												$core['grade'] = $grade;
												array_push($subs['cores'], $core);
											}
										}
										
									endforeach;
								
							
							$stored = $controller->getPerformance($store['performances'], $subs['cores']);
							
							$countrs = 0;
							foreach($stored as $performance):
							$avrgmrk = number_format($performance['averagemark'], 2);
							$position['avrgmrk'] = $avrgmrk;
							$position['student'] = $data->studentNumber;
							$position['result'] = $performance['result'];
							
							$results =$performance['result'];
							
							
							if($results == 1)
								$div1++;
							else if($results == 2)
								$div2++;
							else if($results == 3)
								$div3++;
							else if($results == 4)
								$div4++;
							else if($results == 7)
								$div7++;
							else
								$div9++;
							
							
							endforeach;
							
						endforeach;
						
						$totl = $div1+$div2+$div3+$div4+$div7+$div9;
						
						?>
							<tr>
								<td><?php echo $cdata->className;?></td>
								<td><?php echo $div1;?></td>
								<td><?php echo $div2;?></td>
								<td><?php echo $div3;?></td>
								<td><?php echo $div4;?></td>
								<td><?php echo $div7;?></td>
								<td><?php echo $div9;?></td>
								<td><?php echo $totl;?></td>
							</tr>
							<?php
						endforeach;
						?>
						</table>
						<?php
						
					}
					
					else{
					
					
					
					$mclass = '';
					$myear = '';
					$mterm = '';
					if(isset($_GET['year']) and isset($_GET['class']))
				  	{
					  $mclass = $_GET['class'];
					  $myear = $_GET['year'];
					  $mterm = $_GET['term'];
					  
					$sql = "SELECT * FROM students st WHERE st.class = '$mclass'";
					  
				  	}
                 	?>
                    <div class="info"></div>
                    <div class="col-lg-12 col-sm-12">
                    	<p class="text-muted font-13 m-b-30">
                            <div class="row">
                                <form action="" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>
                                    <div class="col-lg-2">
                                        <h4>Filter students</h4>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="text" id="year" name="year" value="<?php echo $myear;?>" placeholder="Select year" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                      <div class="item form-group">
                                            <?php
                                            $terms = array('Term 1', 'Term 2', 'Term 3');
                                            ?>
                                          <select id="term" class="form-control" name="term" required>
                                            <option value="">Select term</option>
                                            <?php
                                            foreach($terms as $term):
                                            ?>
                                                <option <?php if($term == $mterm) echo "Selected";?>><?php echo $term;?></option>                                
                                            <?php
                                            endforeach;
                                            ?>
                                          </select>
                                      </div>
                                    </div>
                                    
                                    <!---<div class="col-lg-2">
                                    	<?php
										$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'O Level'");
										?>
									  <select id="class" class="class form-control" name="class" required>
										<option value="">Select class</option>
										<?php
										foreach($classes as $class):
										?>
										
										<option value="<?php echo $class->id;?>" <?php if($class->id == $mclass) echo "Selected";?>><?php echo $class->className;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>---->
                                    
                                    <div class="col-lg-3">
                                    	<div class="btn-group">
                                    		<input type="submit" name="action" value="Filter students" class="btn btn-primary">
                                            <?php
											if(isset($_GET['year'])){
											?>
                                            <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger"><span class="fa fa-times"></span> Cancel filter</a>
											<?php
											}
											?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </p>
                    </div>
                    <!--<div class="col-lg-2 col-sm-12">
                    <p class="text-muted font-13 m-b-30">
                    	
                      <a href="?new" class="btn btn-success pull-right"><span class="fa fa-plus"></span> Add marks</a>
                      <div class="clearfix"></div>
                    </p>
                    </div>-->
                    <div class="clearfix"></div>
                    <hr>
                    <?php
					
					if(isset($_GET['year'])){
						
					?>
                    <form action="" method="post" name="form1" onSubmit="return delete_confirm();">
                    <table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
                      <thead>
                        <tr>
                          <!--<th><input type="checkbox" id="check-all" class="flat" title="Check all"></th>-->
                          <th>Year</th>
                          <th>Term</th>
                          <th>Student Name</th>
                          <th>Student Number</th>
                          <th>Operations</th>
                        </tr>
                      </thead>

                      <tbody>
					  <?php
					  
					  $datas = $controller->getcustomdata($sql);
					  
					  $count = 0;
					  foreach($datas as $data):
					  
					  	$count++;
					  ?>
                        <tr>
                          <!--<td><input type="checkbox" name="ids[]" value="<?php echo $data->marksId;?>" class="table_records flat "></td>-->
                          <td><?php echo $myear;?></td>
                          <td><?php echo $mterm;?></td>
                          <td><?php echo $data->fname. ' ' .$data->lname;?></td>
                          <td><?php echo $data->studentNumber;?></td>
                          <td><a href="?student=<?php echo $data->studentId;?>&year=<?php echo $myear;?>&term=<?php echo $mterm;?>&class=<?php echo $mclass;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Generate Report</a> </td>
                        </tr>
                        
                      <?php
					  endforeach;
					  ?>
                        
                      </tbody>
                    </table>
                	<div class="clearfix"></div>
                    <hr>
                    <a href="?all&year=<?php echo $myear;?>&term=<?php echo $mterm;?>&class=<?php echo $mclass;?>" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Generate All Reports</a>
					</form>
					<?php }?>
                    <?php }?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>