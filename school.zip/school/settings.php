		<?php
		require_once ("inc/essentials.php");
		
		$class = "Controller";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Settings </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    
                    <?php
						
						include 'database-backup.php';
						if(isset($_GET['backup'])){
							$controller->backupdatabase("dbschoolmanager", $tables=false, $backup_name=false);
						}
						
						if(isset($_GET['dropdb']))
						{
							dropdb("dbschoolmanager");
						}
						
						if(isset($_GET['droptable']))
						{
							if(isset($_POST['droptable'])){
								
								$table = htmlentities($_POST['table']);
								
								if($table != 'settings')
								{
									$controller->droptable($table);
								}
								else{
									$controller->model->Alert("alert-danger", "Table ". $table ." can not be droped. You will need technical support on this");
								}
							}
							
							?>
							<form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="table">Table name<span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="table" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" name="table" placeholder="Enter table name" required="required" type="text">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                             
                              <button id="droptable" type="submit" name="droptable" class="btn btn-success" onclick="return confirm('Are you sure you want to drop this table?"><i class="fa fa-check"></i> Drop table</button>
							  <a href="settings.php" class="btn btn-warning pull-right"><i class="fa fa-long-arrow-left"></i> Cancel</a>
                            </div>
                          </div>
                        </form>
							<?php
							
							exit();
						}
						
						if(isset($_GET['importtables']))
						{
							if(isset($_POST['importtable'])){
								$path = '';
								if(!empty($_FILES['sqltable']['name']) ){
									$pic = $_FILES['sqltable'];
									$pic_name = $pic['name'];
									$pic_name = htmlentities($pic_name);
									$pic_tmp = $pic['tmp_name'];
									
									$path = $_FILES['sqltable']['tmp_name'];
								}
								$controller->importdatabase($path);
							}
							
							?>
							<form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="table">Choose sql file<span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="tables" class="form-control col-md-7 col-xs-12" name="sqltable" type="file">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                             
                              <button id="importtable" type="submit" name="importtable" class="btn btn-success"><i class="fa fa-check"></i> Import table(s)</button>
							  <a href="settings.php" class="btn btn-warning pull-right"><i class="fa fa-long-arrow-left"></i> Cancel</a>
                            </div>
                          </div>
                        </form>
							<?php
							
							exit();
						}
						
						$datas = $controller->getdata("settings", "id", "ASC");
						
						foreach($datas as $data):
						
						if(isset($_POST['update']))
						{
							$controller->updatesettings($data->id);
						}
						
						?>
                        <form class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate method="post" enctype="multipart/form-data">

    
    					  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="title">Site Title<span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="title" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" value="<?php echo $data->siteTitle;?>" name="title" placeholder="Site Title" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="slogan">Slogan/Motto <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="slogan" class="form-control" name="slogan" placeholder="Slogan" value="<?php echo $data->siteSlogan;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="email">System Email <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="email" class="form-control" name="email" placeholder="Email" value="<?php echo $data->systemEmail;?>" required="required" type="email">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="phone">Telephone <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="phone" class="form-control" name="phone" placeholder="Phone" value="<?php echo $data->systemPhone;?>" required="required" type="text">
                            </div>
                          </div>
						  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="begin">Next term begins <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="begin" class="form-control" name="begin" placeholder="Next term begins" value="<?php echo $data->termBegin;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="end">Next term ends <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="end" class="form-control" name="end" placeholder="Next term ends" value="<?php echo $data->termEnd;?>" required="required" type="text">
                            </div>
                          </div>						  
						  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="scbanner">School banner <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="scbanner" class="form-control" name="scbanner" id="scbanner" type="file">
                            </div>
                          </div>						  
						  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="olbanner">O Level banner <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="olbanner" class="form-control" name="olbanner" id="olbanner" type="file">
                            </div>
                          </div>					  
						  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="albanner">A Level banner <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="albanner" class="form-control" name="albanner" id="albanner" type="file">
                            </div>
                          </div>
						  
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="version">Software Version <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="version" class="form-control" name="version" placeholder="Software version" value="<?php echo $data->latestVersion;?>" required="required" type="text">
                            </div>
                          </div>
                          <div class="item form-group">
                            <label class="control-label col-md-2 col-sm-2 col-xs-12" for="footer">Footer Text <span class="required">*</span>
                            </label>
                            <div class="col-md-8 col-sm-8 col-xs-12">
                              <input id="footer" class="form-control" name="footer" placeholder="Footer Text" value="<?php echo $data->footerText;?>" type="text">
                            </div>
                          </div>
                          
                          <div class="ln_solid"></div>
                          <div class="form-group">
                            <div class="col-md-8 col-md-offset-2">
                             
                              <button id="send" type="submit" name="update" class="btn btn-success"><i class="fa fa-check"></i> Save Changes</button>
                            </div>
                          </div>
                        </form>
						
						<hr>
						<h3>Other Settings</h3>
						<hr>
						<h4><i>--- Database ---</i><h4>
						<div class="database">
						<a href="?backup" class="btn btn-success"><span class="fa fa-download"></span> Backup database</a>
						<a data-toggle="modal" data-target="#confirm-drop" class="btn btn-warning"><span class="fa fa-trash"></span> Drop / Delete database</a>
						<a href="?droptable" class="btn btn-warning"><span class="fa fa-download"></span> Drop a table</a>
						<a href="?importtables" class="btn btn-warning"><span class="fa fa-download"></span> Import table(s)</a>
						
						<div class="modal fade" id="confirm-drop" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<b><i class="fa fa-info-circle"> </i> Confirm Database Deletion</b>
									</div>
									<div class="modal-body">
										Are you sure you want to delete the database?
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"> </i> Cancel</button>
										<a href="?dropdb" class="btn btn-success btn-ok"><i class="fa fa-check"> </i> OK</a>
									</div>
								</div>
							</div>
						</div>
						</div>
						
						<div class="nexterm">
							
						</div>
                        <?php
						endforeach;
						?>
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->

        <?php
		require_once ("inc/footer.php");
		?>