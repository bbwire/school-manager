		<?php
		require_once ("inc/essentials.php");
		
		$class = "StudentsController";
		
		require_once ("inc/head.php");
		?>

		<?php 
        require_once ("inc/sidebar.php");
        ?>

        <?php
		require_once ("inc/top.php");
		?>

        <!-- page content -->
        <div class="right_col" role="main">
          

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                  <div class="x_title">
                    <h2>Subject Performance </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <div class="info"></div>
                    <div class="col-lg-10 col-sm-12">
                    	<p class="text-muted font-13 m-b-30">
                            <div class="row">
								<?php
								
					
									$gyear = '';
									$gterm = '';
									$msubject = '';
									$mclass = '';
									if(isset($_GET['year']) and isset($_GET['term']) and isset($_GET['subject']) and isset($_GET['class']))
									{
										
										  $gyear = $_GET['year'];
										  $gterm = $_GET['term'];
										  $msubject = $_GET['subject'];
										  $mclass = $_GET['class'];
									}
								?>
                                <form action="" class="form-horizontal form-label-left" id="demo-form2" data-parsley-validate>
                                    <div class="col-lg-1">
                                        <h4>Filter</h4>
                                    </div>
                                    <div class="col-lg-2">
                                        <input type="text" id="year" name="year" value="<?php echo $gyear;?>" placeholder="Select year" class="form-control" required>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                      <div class="item form-group">
                                            <?php
                                            $terms = array('Term 1', 'Term 2', 'Term 3');
                                            ?>
                                          <select id="term" class="form-control" name="term" required>
                                            <option value="">Select term</option>
                                            <?php
                                            foreach($terms as $term):
                                            ?>
                                                <option <?php if($term == $gterm) echo "Selected";?>><?php echo $term;?></option>                                
                                            <?php
                                            endforeach;
                                            ?>
                                          </select>
                                      </div>
                                    </div>
									
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$classes = $controller->getcustomdata("SELECT * FROM classes WHERE classLevel = 'A Level'");
										?>
									  <select id="class" class="class form-control" name="class" required>
										<option value="">Select class</option>
										<?php
										foreach($classes as $class):
										?>
										
										<option value="<?php echo $class->id;?>" <?php if($class->id == $mclass) echo "Selected";?>><?php echo $class->className;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-2">
                                    	<?php
										$subjects = $controller->getcustomdata("SELECT * FROM subject WHERE subjectLevel = 'A Level'");
										?>
									  <select id="subject" class="subject form-control" name="subject" required>
										<option value="">Select student number</option>
										<?php
										foreach($subjects as $subject):
										?>
										
										<option value="<?php echo $subject->id;?>" <?php if($subject->id == $msubject) echo "Selected";?>><?php echo $subject->subjectTitle;?></option>
										
										<?php
										endforeach;
										?>
									  </select>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                    	<div class="btn-group">
                                    		<input type="submit" name="action" value="Filter marks" class="btn btn-primary">
                                            <?php
											if(isset($_GET['year'])){
											?>
                                            <a href="<?php echo basename($_SERVER['PHP_SELF']);?>" class="btn btn-danger"><span class="fa fa-times"></span> Cancel filter</a>
											<?php
											}
											?>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </p>
                    </div>
                    <div class="col-lg-2 col-sm-12">
                    </div>
                    <div class="clearfix"></div>
                    <hr>
                    <?php
					
					
					if(isset($_GET['year']) and isset($_GET['term']) and isset($_GET['subject']) and isset($_GET['class']))
					{
						  
						  $subjectdatas = $controller->getcustomdata("SELECT * FROM subject WHERE id = '". $msubject ."'");
									
							$store['subjectperforms'] = array();
							
							$performance = array();
							$ttlmrk = 0;
							$ttavrge = 0;
							$countavail = 0;
							foreach($subjectdatas as $subject):
							
								$query = "SELECT * FROM students WHERE class = '". $mclass ."'";
							
								$updatedatas = $controller->getcustomdata($query);
								
								foreach($updatedatas as $data):
								
									$bottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Test", $gyear, $gterm, '');
									$botexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "BOT Exam", $gyear, $gterm, '');
									$eottest = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Test", $gyear, $gterm, '');
									$eotexam = $controller->getTheScore("amarks", $data->studentNumber, $subject->id, "EOT Exam", $gyear, $gterm, '');
									
									if($bottest == '-' and $botexam == '-' and $eottest == '-' and $eotexam == '-')
									{
										$average = '-';
										$total = '-';
									}
									elseif($bottest == '-' and $botexam == '-' and $eottest == '-' and $eotexam != '-')
									{
										$average = number_format(($eotexam*100)/70);
										$total = ($eotexam*100)/70;
										$countavail++;
									}
									elseif($bottest == '-' and $botexam != '-' and $eottest == '-' and $eotexam != '-')
									{
										$botexam = ($botexam*100)/70;
										$eotexam = ($eotexam*100)/70;
										$average = number_format(($eotexam+$botexam)/2);
										$total = ($eotexam+$botexam);
										$countavail++;
									}
									elseif($bottest != '-' and $botexam != '-' and $eottest == '-' and $eotexam == '-')
									{
										$average = number_format(($bottest+$botexam));
										$total = ($bottest+$botexam);
										$countavail++;
									}
									elseif($bottest == '-' and $botexam == '-' and $eottest != '-' and $eotexam != '-')
									{
										$average = number_format(($eottest+$eotexam));
										$total = ($eottest+$eotexam);
										$countavail++;
									}
									elseif($bottest != '-' and $botexam != '-' and $eottest == '-' and $eotexam != '-')
									{
										$botttl = ($bottest+$botexam);
										$eotttl = ($eotexam*100)/70;
										$average = number_format(($eotttl+$botttl)/2);
										$total = ($eotttl+$botttl);
										$countavail++;
									}
									elseif($bottest == '-' and $botexam != '-' and $eottest != '-' and $eotexam != '-')
									{
										$botttl = ($botexam*100)/70;
										$eotttl = ($eotexam+$eottest);
										$average = number_format(($eotttl+$botttl)/2);
										$total = ($eotttl+$botttl);
										$countavail++;
									}
									else
									{
										$average = number_format((($bottest+$botexam)+($eottest+$eotexam))/2);
										
										$total = (($bottest+$botexam)+($eottest+$eotexam));
										$countavail++;
									}
									
									if($average != '-')
									{
										$performance['student'] = $data->fname. ' ' .$data->lname;
										$performance['average'] = $average;
										array_push($store['subjectperforms'], $performance);
									}
									
								endforeach;
								
							endforeach;
							
							$ppd = $controller->getSubjectPerformance($store['subjectperforms']);
							
							?>
							<table id="datatable-buttons" class="table table-striped table-bordered bulk_action">
							  <thead>
								<tr>
								  
								  <th>Position</th>
								  <th>Student</th>
								  <th>Average mark</th>
								  <!--<th>Operations</th>-->
								</tr>
							  </thead>

							  <tbody>
							<?php
							
							foreach($ppd as $pp){
								
								
								
								?>
								<tr>
								<td><?php echo $pp['position'];?></td>
								<td><?php echo $pp['student'];?></td>
								<td><?php echo $pp['average'];?></td>
								</tr>
								<?php
								
							}
							
							?>
								</tbody>
							</table>
							<?php
						}
						
				  	
                 	?>
                    
                    
                  </div>
                </div>
            </div>
            

          </div>
          <br />

        </div>
        <!-- /page content -->
        

        <?php
		require_once ("inc/footer.php");
		?>